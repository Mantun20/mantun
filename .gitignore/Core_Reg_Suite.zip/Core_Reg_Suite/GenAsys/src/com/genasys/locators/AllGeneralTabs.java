package com.genasys.locators;

import java.sql.Driver;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.genasys.api.Implementation;
import com.genasys.utils.WriteToExcel;
import com.genasys.webdriver.WillisWebdriver;

public class AllGeneralTabs extends Implementation
{
	WebDriver driver;
	WebDriverWait wait;
	private String clientName;
	private int row = 2;
	private int column = 1;
	private Implementation Implementation;
	private WriteToExcel writeExcel;
	private long start;
	WebElement FailSkip; 
	String firefoxProfilePath;
	String chrome;
	String InternetExplorer;
	String waitingTime;
	String browsername;
	String prevBrowserName;
	String senkeys;
	public int  flag = 0;
	int incr = 1;




	//constructor
	public AllGeneralTabs(WebDriver driver) {
		this.driver = driver;
		WillisWebdriver.clientName=clientName;
		WillisWebdriver.createWebDriverObject(browsername);
		driver=WillisWebdriver.getDriverObject();
		Implementation = PageFactory.initElements(driver, Implementation.class);
		prevBrowserName=browsername;
	}

	//Admin Module Login Page

	/*
    Page = Login page Admin
    Element = Enter Username
    Type = Text Field
	 */
	@FindBy(xpath = "//*[@id='ctl00_MainContent_txtUserName']")
	public static WebElement txt_UsernameAdmin;
	
	/*
    Page = Login page Admin
    Element = Enter Username
    Type = Text Field
	 */
	public static final By txt_UsernameAdmin1 = By.xpath("//*[@id='ctl00_MainContent_txtUserName']");

	/*
    Page = Login page Admin
    Element = Enter Password
    Type = Text Field
	 */
	public static final By txt_PasswordAdmi1 = By.xpath("//*[@id='ctl00_MainContent_txtPassword']");
	/*
    Page = Login page Admin
    Element = Login Button
    Type = Button
	 */
	public static final By btn_LoginAdmin1 = By.xpath("//*[@id='ctl00_MainContent_btnLogin']");

	/*
    Page = Sponsor Select page Admin
    Element = Sponsor Selection
    Type = Drop Down
	 */
	public static final By cmb_SelectSpoAdmin1 = By.xpath("//*[@id='ctl00_MainContent_ddlSponsors_ddlControl']");

	/*
    Page = Sponsor Select page Admin
    Element = Select Button
    Type = Button
	 */
	public static final By btn_SelectAponsorAdmin1 = By.xpath("//*[@id='ctl00_MainContent_btnSelect']");

	/*
	Page =Qutoe Summary screen
	Element = Accept Quote button
	Type = button
	*/
	public static final By btn_AcceptQuote =By.xpath("//input[@id='btnAcceptQuote' and @value='Accept Quote']");
	
	/*
	Page =Customer details page
	Element =Quote
	Type = link
	*/
	public static final By txt_quoteStatus =By.xpath("//div[@id='MainContent_pnlClaimSearchResults']//tr[2]/td[2]");
	
	/*
	Page =Qutoe Summary screen
	Element =Upload
	Type = Link
	*/
	public static final By link_Upload =By.xpath("//div[@id='divQuoteReferralInformationGrid']//a[text()='Upload']");
	
	/*
	Page =Qutoe Summary screen
	Element =Browse button
	Type = button
	*/
	public static final By btn_browse =By.xpath("//input[@id='quoteAction_attachmentItem_File']");
	
	/*
	Page =Qutoe Summary screen
	Element =upload
	Type = button
	*/
	public static final By btn_oploadPopup =By.xpath("//input[@id='btnUploadAdditionalInfo']");
	
	/*
    Page = Login page Admin
    Element = Enter Password
    Type = Text Field
	 */
	@FindBy(xpath = "//*[@id='ctl00_MainContent_txtPassword']")
	public static WebElement txt_PasswordAdmin;

	/*
    Page = Login page Admin
    Element = Login Button
    Type = Button
	 */
	@FindBy(xpath = "//*[@id='ctl00_MainContent_btnLogin']")
	public static WebElement btn_LoginAdmin;

	/*
    Page = Sponsor Select page Admin
    Element = Sponsor Selection
    Type = Drop Down
	 */
	@FindBy(xpath = "//*[@id='ctl00_MainContent_ddlSponsors_ddlControl']")
	public static WebElement cmb_SelectSpoAdmin;

	/*
    Page = Sponsor Select page Admin
    Element = Select Button
    Type = Button
	 */
	@FindBy(xpath = "//*[@id='ctl00_MainContent_btnSelect']")
	public static WebElement btn_SelectAponsorAdmin;

	/*
    Page = Login Page
    Element = Forgot Password link
    Type = Hyperlink
	 */
	@FindBy(xpath = "//*[@id='MainContent_btnForgottenYourPassword']")
	public static WebElement lnk_ForgotPassword;



	//Client Module Affinity Ops
	/*
    Page = Login Page Client
    Element = User name
    Type = Text Box
	 */
	@FindBy(xpath = "//input[@id='MainContent_txtUserName']")
	public static WebElement txt_UsernameClient;

	/*
    Page =  Login Page Client
    Element = Password 
    Type = Text Box
	 */
	@FindBy(xpath = "//*[@id='MainContent_txtPassword']")
	public static WebElement txt_PasswordClient;

	/*
    Page = Login Page Client
    Element = Login Button
    Type = Text Box
	 */
	@FindBy(xpath = "//*[@id='MainContent_btnLogin']")
	public static WebElement btn_LoginClient;


	/*
    Page = Sponsor selection page Client
    Element = Sponsor
    Type = Drop down
	 */
	@FindBy(xpath = "//*[@id='MainContent_ddlSponsors_ddlControl']")
	public static WebElement cmb_select_sponsorClient;

	/*
    Page = Sponsor selection page Client
    Element = Sponsor
    Type = Drop down
	 */
	@FindBy(xpath = "//*[@id='ddlSponsor_ddlControl']")
	public static WebElement cmb_directselectSponsor;

	/*
    Page = Sponsor selection page Client
    Element = Select Sponsor
    Type = Sponsor Button
	 */
	@FindBy(xpath = "//*[@id='MainContent_btnSelect']")
	public static WebElement btn_selectClient;

	/*
    Page = Change Password Page Client
    Element = Logout Button
    Type = Button
	 */
	@FindBy(xpath = "//*[@id='LogoutLink']")
	public static WebElement lnk_Logout;


	//All Tabs Client AND Admin modules
	/*
    Page = Home page
    Element = Quote 
    Type =Select Product
	 */
	public static final By Tab_Next=By.xpath("//a[contains(text(),'Next')]");

	/*
    Page = Home page
    Element = Click Quote Tab
    Type = Tab
	 */
	public static final By Tab_Quote=By.xpath("//a[@class='fNiv' and contains(text(), 'Quote')]");

	/*
	Page =View Policy Screen
    Element = Device modal info
    Type = text
	 */
	public static final By link_JyskTryghed=By.xpath("//h3[text()='Jysk Tryghed']");
	
	/*
	Page = Quote Response Screen
    Element = Next button after Premium is displayed
    Type = Button
	 */
	public static final By btn_nxtp=By.xpath("//input[@value='Next']");
	
	/*
    Page = Home page
    Element = Click Actions Tab
    Type = Tab
	 */
	public static final By Tab_Actions=By.xpath("//a[@class='fNiv' and contains(text(), 'Actions')]");

	/*
    Page = Home page
    Element = Click Reports Tab
    Type = Tab
	 */
	public static final By Tab_Reports=By.xpath("//a[@class='fNiv' and contains(text(), 'Reports')]");

	/*
    Page = Home page
    Element = Click Documents Tab
    Type = Tab
	 */
	public static final By Tab_Documents=By.xpath("//a[@class='fNiv' and contains(text(), 'Documents')]");

	/*
    Page = Home page
    Element = Click Policy Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_reportbuilder=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Report Builder Template Maintenance']");
	
	/*
	Page =Report Builder Maintance
    Element = New
    Type = button
	 */
	public static final By btn_new=By.xpath("//a[contains(text(),'New')]");

	/*
	Page =Report Builder Maintance
    Element = Report Name
    Type = Text
	 */
	public static final By txt_reportName=By.xpath("//input[@id='ctl00_MainContent_txtReportName']");
	

	/*
	Page =Report Builder Maintance
    Element = Report Path
    Type = Text
	 */
	public static final By txt_reportpath=By.xpath("//*[@id='ctl00_MainContent_txtReportPath']");
	
	/*
	Page =Report Builder Maintance
    Element = Country
    Type = Drop down
	 */
	public static final By dd_country=By.xpath("//select[@id='ctl00_MainContent_ddlCountry_ddlControl']");

	/*
	Page =Report Builder Maintance
    Element = Save
    Type = BUtton
	 */
	public static final By btn_saveReport=By.xpath("//a[contains(text(),'Save')]");
	
	/*
	Page =Report Builder Maintance
    Element = Report Name search
    Type = Text obx
	 */
	public static final By txt_reportNamesearch=By.xpath("//input[@id='ctl00_MainContent_txtSearch']");
	
	/*
	Page =Report Builder Maintance
    Element = Status
    Type = drop down
	 */
	public static final By dd_status=By.xpath("//select[@id='ctl00_MainContent_ddlStatus_ddlControl']");
	
	/*
	Page =Report Builder Maintance
    Element = Search
    Type = button
	 */
	public static final By btn_searchReport=By.xpath("//input[@id='ctl00_MainContent_btnSearch']");
	
	/*
	Page =Report Builder Maintance
    Element = report name
    Type = link
	 */
	public static final By link_reportname=By.xpath("//a[@id='ctl00_MainContent_gvReport_ctl02_lbReportName']");
	
	/*
	Page =Report Builder Maintance
    Element = report path
    Type = text
	 */
	public static final By txt_reportpathr=By.xpath("//table[@id='ctl00_MainContent_gvReport']//td[2]");
	
	/*
    Page = Home page
    Element = Click Documents Tab
    Type = Tab
	 */
	public static final By tab_secutiry=By.xpath("//a[@class='fNiv' and contains(text(), 'Security')]");
	
	/*
    Page = Home page
    Element = Click Policy Sub Menu
    Type = Sub Menu
	 */
	public static final By submenu_profilemain=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Profile Maintenance']");
	
	/*
    Page = Home page
    Element = Click Policy Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Report=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Report Viewer']");
	
	/*
	Page =View Report Screen
    Element = Report dropdown
    Type = dropdown
	 */
	public static final By dd_report=By.xpath("//select[@id='MainContent_ddlReport_ddlControl']");

	/*
	Page =View Reportpage 
    Element = Carrier ID Field
    Type = Drop down
	 */
	public static final By txt_CarrierID=By.xpath("//span[contains(text(),'Carrier ID')]");
	
	/*
	Page =View Reportpage 
    Element = Product
    Type = Drop dwon
	 */
	public static final By txt_product=By.xpath("//span[contains(text(),'Product')]");
	
	/*
	Page =View Reportpage 
    Element = Date from 
    Type = Text Box
	 */
	public static final By txt_datefrom=By.xpath("//span[contains(text(),'Date From')]");

	/*
	Page =View Reportpage 
    Element = Date To 
    Type = Text Box
	 */
	public static final By txt_dateto=By.xpath("//span[contains(text(),'Date To')]");
	
	/*
	Page =View Reportpage 
    Element = Cancelled Rang
    Type = drop down
	 */
	public static final By txt_cancelledRange=By.xpath("//span[contains(text(),'Cancelled Range')]");
	
	/*
	Page =View Reportpage 
    Element = Status
    Type = drop down
	 */
	public static final By txt_status=By.xpath("//span[contains(text(),'Status')]");
	
	/*
	Page =View Reportpage 
    Element = Start from
    Type = button
	 */
	public static final By txt_startfrom=By.xpath("//*[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl03_txtValue']");
	//ctl00_MainContent_wipReportViewer_ctl04_ctl03_txtValue
	/*
	Page =View Reportpage 
    Element =End Date
    Type = button
	 */
	public static final By txt_endDate=By.xpath("//*[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl05_txtValue']");
	
	
	/*
	Page =View Reportpage 
    Element =country
    Type = dropdown
	 */
	public static final By dd_countryreport=By.xpath("//*[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl07_ddValue']");
	
	/*
	Page =Customer details page
	Element =Quote
	Type = link
	*/
	public static final By dd_subgroup =By.xpath("//select[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl09_ddValue']");
	
	/*
	Page =Customer details page
	Element =Quote
	Type = link
	*/
	public static final By dd_carrier =By.xpath("//select[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl09_ddValue']");
	
	/*
	Page =View Reportpage 
    Element =product
    Type = drop down
	 */
	public static final By dd_productreport=By.xpath("//*[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl11_ddValue']");
	public static final By dd_productreportPL=By.xpath("//select[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl05_ddValue']");
	public static final By dd_productreportCBR=By.xpath("//select[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl13_ddValue']");
	
	/*
	Page =View Report Screen
    Element = View Report
    Type = Button
	 */
	public static final By btn_viewReport=By.xpath("//input[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl00']");
	
	/*
    Page = MTA
    Element = Policy Transactions
    Type = Click
	 */
	public static final By tab_PolicyTransaction =By.xpath ("//a[contains(text(),'Policy Transactions')]");

	/*
	Page =Customer details page
	Element =Quote
	Type = link
	*/
	public static final By txt_polTracnspendingMTA =By.xpath("//td[contains(text(),'Pending MTA')]");
	
	/*
	Page =Customer details page
	Element =Quote
	Type = link
	*/
	public static final By table_PolicyList =By.xpath("//div[@id='VisibleReportContentctl00_MainContent_wipReportViewer_ctl09']");
	
	/*
	Page =View Reportpage 
    Element =iFrame for report displayed
    Type = iFrame
	 */
	public static final By report_iframe=By.xpath("//iframe[@id='ctl00_MainContent_wipReportViewer_ctl04_ctl03_ctl01']");
	
	/*
	Page =View Reportpage 
    Element =product
    Type = drop down
	 */
	public static final By report_country=By.xpath("//span[text()='Australia']");
	
	/*
	Page =View Reportpage 
    Element = Export Report button
    Type = button
	 */
	public static final By btn_exportReport=By.xpath("//img[@id='ctl00_MainContent_wipReportViewer_ctl05_ctl04_ctl00_ButtonImg']");
	
	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_XML=By.xpath("//a[text()='XML file with report data']");

	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_CSV=By.xpath("//a[text()='CSV (comma delimited)']");

	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_pdf=By.xpath("//a[text()='PDF']");
	
	
	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_mhtml=By.xpath("//a[text()='MHTML (web archive)']");
	
	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_excel2003=By.xpath("//a[text()='Excel 2003']");
	
	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_excel=By.xpath("//a[text()='Excel']");
	
	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_tifffile=By.xpath("//a[text()='TIFF file']");
	
	
	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_word2003=By.xpath("//a[text()='Word 2003']");
	
	/*
	Page =View Reportpage 
    Element = Print Report
    Type = button
	 */
	public static final By btn_word=By.xpath("//a[text()='Word']");
	
	
	/*
	Page =View Report Screen
    Element = Report dropdown
    Type = dropdown
	 */
	public static final By dd_multicarriersalesreport=By.xpath("//select[@id='MainContent_ddlReport_ddlControl']");
	
	/*
	Page =Report Builder Maintance
    Element = aff Opps
    Type = link
	 */
	public static final By link_affopps=By.xpath("//table[@id='ctl00_MainContent_gvProfiles']//tr[2]/td[1]/a");
	
	/*
	Page =Report Builder Maintance
    Element = Multi carrier check box
    Type = check box
	 */
	public static final By chcbx_mulitcarrier=By.xpath("//*[contains(text(),'Multi')]//following::td[2]//input[@type='checkbox']");
	
	public static final By Tab_Reports1=By.xpath("//a[@class='fNiv' and contains(text(), 'Reports')]");
	
	/*
    Page = Home page
    Element = Click Payments Tab
    Type = Tab
	 */
	public static final By Tab_Payments=By.xpath("//a[@class='fNiv' and contains(text(), 'Payments')]");

	/*
    Page = Home page
    Element = Click Upload Tab
    Type = Tab
	 */
	public static final By Tab_Upload=By.xpath("//a[@class='fNiv' and contains(text(), 'Upload')]");

	/*
    Page = Home page
    Element = Click Interface Tab
    Type = Tab
	 */
	public static final By Tab_Interface=By.xpath("//a[@class='fNiv' and contains(text(), 'Interface')]");

	/*
    Page = Home page
    Element = Click Preferences Tab
    Type = Tab
	 */
	public static final By Tab_Preferences=By.xpath("//a[@class='fNiv' and contains(text(), 'Preferences')]");

	/*
    Page = Home page
    Element = Click Home Tab
    Type = Tab
	 */
	public static final By Tab_Home=By.xpath("//a[@class='fNiv' and contains(text(), 'Home')]");

	/*
    Page = Home page
    Element = Click StakeHolders Tab
    Type = Tab
	 */
	public static final By Tab_Stakeholders=By.xpath("//a[@class='fNiv' and contains(text(), 'Stakeholders')]");

	/*
    Page = HAdmin-Product page
    Element = Click Products Tab
    Type = Tab
	 */
	@FindBy(xpath = "//a[@class='fNiv' and contains(text(), 'Products')]")
	public static WebElement Tab_Products;

	/*
    Page = Admin-Product page
    Element = Edit button
    Type = Tab
	 */
	public static final By Product_EditButton=By.xpath("//div[@id='gridContent']/table/tbody/tr[2]/td[5]/div/a");
	public static final By Product_EditButton_ASTTBC2=By.xpath("//div[@id='gridContent']/table/tbody/tr[3]/td[5]/div/a");
	
	public static final By Product_EditButton_EnterCard=By.xpath("//div[@id='gridContent']/table/tbody/tr[2]/td[5]/div/a");

	/*
    Page = Admin-Product page
    Element = Policy Transaction Tab
    Type = Tab
	 */
	public static final By Product_Search_PolicyTransactionTab=By.xpath("//a[contains(text(),' Policy Transactions')]");

	/*
    Page = Admin-Product page
    Element = Policy Transaction Tab
    Type = Renewal Type
    Sub Type = Select
	 */
	public static final By PolicyTransaction_SelectRenewalType=By.xpath("//select[@id='ProductTemplatePolicyRenewalViewModel_RenewalTypeId']");
	
	public static final By PD_ClaimsTab=By.xpath("//a[contains(text(),' Claims')]");

	/*
    Page = Admin-Product page
    Element = Policy Transaction Tab
    Type = Renewal Type
    Sub Type = Select
	*/
	public static final By PolicyTransaction_SaveButton1=By.xpath("//input[@value='Save']");
	public static final By PolicyTransaction_SaveButton=By.xpath("//button[@id='btnSaveProduct']");

	/*
    Page = Home page
    Element = Click DataRef Tab
    Type = Tab
	 */
	public static final By Tab_DataRef=By.xpath("//a[@class='fNiv' and contains(text(), 'Data Ref.')]");

	/*
    Page = Home page
    Element = Click Security Tab
    Type = Tab
	 */
	public static final By Tab_Security=By.xpath("//a[@class='fNiv' and contains(text(), 'Security')]");

	/*
    Page = Home page
    Element = Copa Funeral
    Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'COPA Funeral')]")
	public static WebElement Tab_Products_Copa_Funeral;

	/*
    Page = Home page
    Element = Copa Funeral-Currency 
    Type = Text
	 */
	@FindBy(xpath = "//select[@id='CurrencyID']")
	public static WebElement Tab_Products_Copa_Funeral_Currency;



	//All Subtabs

	/*
    Page = Home page
    Element = Click Customer Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Customer=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Customer']");

	/*
    Page = Home page
    Element = Customer Sub Menu-Policy Ref
    Type = Policy Ref
	 */
	public static final By SubMenu_Customer_PolicyRef=By.xpath("//*[@id='MainContent_txtPolicyReference']");

	/*
    Page = Home page
    Element = Click Customer Sub Menu-Customer search page
    Type = Sub Menu
	 */
	public static final By SubMenu_Customer_SearchPage=By.xpath("//span[contains(text(),'Customer Search')]");

	/*
    Page = Home page
    Element = Click Policy Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Policy=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Plan' or ./text()='Policy']");

	public static final By SubMenu_Policy_SearchPage=By.xpath("//span[contains(text(),'Policy Search')]");

	/*
    Page = Home page
    Element = Click Claim Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Claim=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Claim ']");

	public static final By SubMenu_Claim_SearchPage=By.xpath("//span[contains(text(),'Claim Search')]");

	/*
    Page = Home page
    Element = Click Quote Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Quote=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Quote']");

	public static final By SubMenu_Quote_SearchPage=By.xpath("//span[contains(text(),'Quote Search')]");
	
	
	/*
    Page = Quote Search PAge
    Element = Quote Search
    Type = Text Field
	 */
	public static final By txt_Quotenumber2 =  By.xpath("//*[@id='MainContent_txtQuoteNumber']");
	
	/*
	Page =Quote Details Screen
    Element = Quote Referred Message
    Type = Text
	 */
	public static final By txt_QuoteReferred=By.xpath("//strong[text()='Quote Referred']");
	
	/*
	Page =Quote Details Screen
    Element = Generic Quote Referred Message
    Type = Text
	 */
	public static final By txt_genericQuoteREferralMessage=By.xpath("//div[text()='Quote is referred and this is a generic referral message.']");
	
	/*
	Page =Quote Details Screen
    Element = Total gross Premium value
    Type = Text
	 */
	public static final By txt_totalGrossPremiumvalue=By.xpath("//tr[@class='premiumRowHeight']/td[2]");
	
	/*
    Page = Quote response screen Finance Product
    Element = Next after premium displayed
    Type = button
	 */
	public static final By btn_next3=By.xpath("//a[@class='btn' and text()='Next']");
	
	/*
	Page = search result page
	Element =First Customer Link 
    Type = link
	 */
	public static final By link_cusSearchResult=By.xpath("//*[@id='resultsContainer']/table//tr[1]/td[1]/div/a");
	
	/*
	Page =Quote Details Screen
    Element = Save Quote button
    Type = Button
	 */
	public static final By btn_saveQuote=By.xpath("//input[@id='QuotePopupid' and @value='Save Quote']");

	/*
	Page =Quote Details Screen
    Element = Save Quote button
    Type = Button
	 */
	public static final By btn_saveQuoteafteraccrpt=By.xpath("//*[contains(text(),'Save Quote')]");
	/*
	Page =Quote Details Screen
    Element = yes button
    Type = Button
	 */
	public static final By btn_yes=By.xpath("//span[text()='Yes' and @class='ui-button-text']");
	//span[text()='Yes' and @class=ui-button-text']
	/*
	Page =Quote Details Screen
Element = Quote Number
    Type = tezxt
	 */
	public static final By txt_quoteNo=By.xpath("//table[@class='pageGrid']/tbody/tr/td[2]/div");

	
	/*
	Page =Cancel Policy Screen
    Element = okay in popup
    Type = Button
	 */
	public static final By btn_oksmall=By.xpath("//span[contains(text(),'Ok')]");
	
	/*
	Page = search result page
	Element = Quote Number
    Type = link
	 */
	public static final By link_quote=By.xpath("//*[@id='MainContent_gvQuote']//tr[2]/td[1]/a");
	
	/*
	Page =Qutoe Summary screen
	Element = Assign
	Type = Button
	*/
	public static final By btn_Assign =By.xpath("//button[@id='btnAssignUserToAction' and text()='Assign']");
	
	/*
	Page =View Quote Screen
	Element = Quote referral action table data
	Type = table data
	*/
	public static final By btn_BuyQuoteScreen =By.xpath("//a[@id='QuoteBuy' and contains(text(),'Buy')]");
	
	/*
    Page = Quote Search PAge
    Element = Quote Search
    Type = Text Field
	 */
	@FindBy(xpath = "//*[@id='MainContent_txtQuoteNumber']")
	public static WebElement txt_QuoteNumber;
	public static final By txt_Quotenumber1 =  By.xpath("//*[@id='MainContent_txtQuoteNumber']");
	
	

	/*
    Page = Home page
    Element = Click Order Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Order=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Order']");

	public static final By SubMenu_Order_SearchPage=By.xpath("//span[contains(text(),'Order Search')]");
	
	public static final By Order_Ref1=By.xpath("//*[@id='MainContent_txtOrderNumber']");

	/*
    Page = Home page
    Element = Policy Number link through the order search
    Type = Click
	 */
	public static final By lnk_PoiNumber= By.xpath("//div[@id='MainContent_pnlOrderSearchResults']//table/tbody/tr[2]/td[2]/a");

	/*
    Page = Home page
    Element = Click Report Viewer Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ReportViewer=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Report Viewer']");

	/*
    Page = Home page
    Element = Click Interface History Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_InterfaceHistory=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Interface History']");

	/*
    Page = Home page
    Element = Click Interface Outbound Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_InterfaceOutbound=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Interface Outbound']");

	/*
    Page = Home page
    Element = Click USER PREFERENCES Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_USERPREFERENCES=By.xpath("//ul[contains(@class,'submenu')]//a[contains(text(), 'User Preferences')]");

	/*
    Page = Home page
    Element = Click Change Password Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ChangePassword=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Change Password']");

	/*
    Page = Home page
    Element = Click Willis Office Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_WillisOfficeMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Willis Office Maintenance']");

	/*
    Page = Home page
    Element = Click Sponsor Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_SponsorMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Sponsor Maintenance']");

	/*
    Page = Home page
    Element = Click Carrier Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_CarrierMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Carrier Maintenance']");

	/*
    Page = Home page
    Element = Click GenASys Maintenance Page Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_GenASysMaintenancePage=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'GenASys Maintenance Page']");

	/*
    Page = Home page
    Element = Click Word Document Template Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_WordDocumentTemplateMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Word Document Template Maintenance']");

	/*
    Page = Home page
    Element = Click Report Builder Template Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ReportBuilderTemplateMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Report Builder Template Maintenance']");

	/*
    Page = Home page
    Element = Click Product Configuration Report Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ProductConfigurationReport=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Product Configuration Report']");

	/*
    Page = Home page
    Element = Click Missing Translations Report Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_MissingTranslationsReport=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Missing Translations Report']");

	/*
    Page = Home page
    Element = Click Payment File Report Configuration Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_PaymentFileReportConfiguration=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Payment File Report Configuration']");

	/*
    Page = Home page
    Element = Click Interface Template Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_InterfaceTemplateMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Interface Template Maintenance']");

	/*
    Page = Home page
    Element = Click Log Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Log=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Log']");

	/*
    Page = Home page
    Element = Click Interface Outward Schedule Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_InterfaceOutwardScheduleMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Interface Outward Schedule Maintenance']");

	/*
    Page = Home page
    Element = Click Schedule Log Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ScheduleLog=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Schedule Log']");

	/*
    Page = Home page
    Element = Click Policy/Plan TPI File Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_PolicyTPIFileMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[contains(text(),'Plan TPI File Maintenance') or contains(text(),'Policy TPI File Maintenance')]");

	/*
    Page = Home page
    Element = Click Policy Bulk Upload Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_PolicyBulkUploadMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[contains(text(),'Policy Bulk Upload Maintenance') or contains(text(),'Plan Bulk Upload Maintenance')]");

	/*
    Page = Home page
    Element = Click EXTERNALSYSTEMINTEGRATIONMAINTENANCE Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_EXTERNALSYSTEMINTEGRATIONMAINTENANCE=By.xpath("//ul[contains(@class,'submenu')]//a[contains(@href,'ExternalSystemMaintenance')]");

	/*
    Page = Home page
    Element = Click Manage External System Messaging Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ManageExternalSystemMessaging=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Manage External System Messaging']");

	/*
    Page = Home page
    Element = Click Region Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_Region=By.xpath("//ul[contains(@class,'submenu')]//a[contains(text(), 'Region (')]");

	/*
    Page = Home page
    Element = Click Region Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_RegionMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Region Maintenance']");

	/*
    Page = Home page
    Element = Click Statuses Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_StatusesMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Statuses Maintenance']");

	/*
    Page = Home page
    Element = Click Translation Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_TranslationMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Translation Maintenance']");

	/*
    Page = Home page
    Element = Click Cancellation Reason Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_CancellationReasonMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Cancellation Reason Maintenance']");

	/*
    Page = Home page
    Element = Click MTA Reason Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_MTAReasonMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'MTA Reason Maintenance']");

	/*
    Page = Home page
    Element = Click Country Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_CountryMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Country Maintenance']");

	/*
    Page = Home page
    Element = Click Look Up Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_LookUpMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Look Up Maintenance']");

	/*
    Page = Home page
    Element = Click Claims Reference Data Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ClaimsReferenceData=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Claims Reference Data']");

	/*
    Page = Home page
    Element = Click Action and Complaints Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ActionandComplaints=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Action and Complaints']");

	/*
    Page = Home page
    Element = Click Dropdown Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_DropdownMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[contains(@href,'MasterDropdowns') and contains(text(),'Dropdown Maintenance')]");

	/*
    Page = Home page
    Element = Click Local Dropdown Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_LocalDropdownMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Local Dropdown Maintenance']");

	/*
    Page = Home page
    Element = Click B2C Content Management Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_B2CContentManagement=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'B2C Content Management']");

	/*
    Page = Home page
    Element = Click Policy Reference Data Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_PolicyReferenceData=By.xpath("//ul[contains(@class,'submenu')]//a[contains(text(),'Plan Reference Data') or contains(text(),'Policy Reference Data')]");

	/*
    Page = Home page
    Element = Click Tax Reference Data Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_TaxReferenceData=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Tax Reference Data']");

	/*
    Page = Home page
    Element = Click User Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_UserMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'User Maintenance']");

	/*
    Page = Home page
    Element = Click Profile Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_ProfileMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Profile Maintenance']");

	/*
    Page = Home page
    Element = Click User Access Report Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_UserAccessReport=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'User Access Report']");

	/*
    Page = Home page
    Element = Click B2C User Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By SubMenu_B2CUserMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'B2C User Maintenance']");






	//Child Sub Menus
	/*
    Page = Home page
    Element = Click B2C User Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_B2CSALESCONFIGURATION=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'B2C SALES CONFIGURATION']");

	/*
    Page = Home page
    Element = Click B2C User Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_SPONSORB2CMAINTENANCEPAGE=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'SPONSOR B2C MAINTENANCE PAGE']");

	/*
    Page = Home page
    Element = Click Claim Additional Info Type Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ClaimAdditionalInfoTypeMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Claim Additional Info Type Maintenance']");

	/*
    Page = Home page
    Element = Click Claim Declined Reason Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ClaimDeclinedReasonMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Claim Declined Reason Maintenance']");

	/*
    Page = Home page
    Element = Click Claim cost type Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_Claimcosttype=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Claim cost type']");

	/*
    Page = Home page
    Element = Click Claim Party Responsible Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ClaimPartyResponsible=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Claim Party Responsible']");

	/*
    Page = Home page
    Element = Click Claim Payee Party Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ClaimPayeeParty=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Claim Payee Party']");

	/*
    Page = Home page
    Element = Click Complaint Reason Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ComplaintReasonMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Complaint Reason Maintenance']");

	/*
    Page = Home page
    Element = Click Numbering Code Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_NumberingCodeMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Numbering Code Maintenance']");

	/*
    Page = Home page
    Element = Click Action Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ActionMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Action Maintenance']");

	/*
    Page = Home page
    Element = Click Action List Status Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ActionListStatus=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Action List Status']");

	/*
    Page = Home page
    Element = Click Complaint Against Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_ComplaintAgainst=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Complaint Against']");

	/*
    Page = Home page
    Element = Click Customer Title Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_CustomerTitle=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Customer Title']");

	/*
    Page = Home page
    Element = Click Attachment Type Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_AttachmentTypeMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Attachment Type Maintenance']");

	/*
    Page = Home page
    Element = Click Quote Additional Info Type Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_QuoteAdditionalInfoTypeMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Quote Additional Info Type Maintenance']");

	/*
    Page = Home page
    Element = Click MTA Additional Info Type Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_MTAAdditionalInfoTypeMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'MTA Additional Info Type Maintenance']");

	/*
    Page = Home page
    Element = Click Renewal Additional Info Type Maintenance Sub Menu
    Type = Sub Menu
	 */
	public static final By Child_SubMenu_RenewalAdditionalInfoTypeMaintenance=By.xpath("//ul[contains(@class,'submenu')]//a[./text()= 'Renewal Additional Info Type Maintenance']");

	//****************Mantun-New Product Creation**********************************************************

	/*
    Page = Home page
    Element = Click New tabs
    Type = Button
	 */
	@FindBy(xpath = "//input[@id='btnNew']")
	public static WebElement Products_New;

	/*
    Page = Home page
    Element = Product Name
    Type = Text
	 */
	@FindBy(xpath = "//input[@data-val-required='Name is required']")
	public static WebElement Products_New_ProductName;

	/*
    Page = Home page
    Element = Country
    Type = Select
	 */
	@FindBy(xpath = "//select[@id='CountryID']")
	public static WebElement Products_New_Country;

	/*
    Page = Home page
    Element = Currency
    Type = Select
	 */
	@FindBy(xpath = "//select[@id='CurrencyID']")
	public static WebElement Products_New_Currency;

	/*
    Page = Home page
    Element = Product Category
    Type = Select
	 */
	@FindBy(xpath = "//select[@id='ProductCategoryID']")
	public static WebElement Products_New_ProductCategory;

	/*
    Page = Home page
    Element = Quoting Enable
    Type = Select
	 */
	@FindBy(xpath = "//div[@id='pnlProductDefinition']//tr[6]/td[2]/div/div/span[3]")
	public static WebElement Products_New_QuotintEnable;

	/*
    Page = Home page
    Element = Start Date
    Type = Text
	 */
	@FindBy(xpath = "//input[@data-val-required='Please enter a Start Date for the Product']")
	public static WebElement Products_New_StartDate;

	/*
    Page = Home page
    Element = Select Start Date
    Type = Select
	 */
	@FindBy(xpath = "//div[@id='ui-datepicker-div']/table/tbody/tr[3]/td[4]/a")
	public static WebElement Products_New_StartDateSelect;

	/*
    Page = Home page
    Element = End Date
    Type = Text
	 */
	@FindBy(xpath = "//input[@data-val-required='Please enter an End Date for the Product']")
	public static WebElement Products_New_EndDate;

	/*
    Page = Home page
    Element = Select End Date
    Type = Select
	 */
	@FindBy(xpath = "//div[@id='ui-datepicker-div']/table/tbody/tr[4]/td[4]/a")
	public static WebElement Products_New_EndDateSelect;

	/*
    Page = Home page
    Element = Carriers
    Type = Select
	 */
	@FindBy(xpath = "//select[@id='carrierDropdownId']")
	public static WebElement Products_New_Carriers;

	/*
    Page = Home page
    Element = Quote Group
    Type = Text
	 */
	@FindBy(xpath = "//input[@id='QuoteGroup']")
	public static WebElement Products_New_QuoteGroup;

	/*
    Page = Home page
    Element = Policy Term
    Type = Select
	 */
	@FindBy(xpath = "//input[@id='isContinuousCheckBox']")
	public static WebElement Products_New_PolicyTerm;

	/*
    Page = Home page
    Element = Descriptions
    Type = Text
	 */
	@FindBy(xpath = "//textarea[@id='Description']")
	public static WebElement Products_New_Descriptions;

	/*
    Page = Home page
    Element = Save Button
    Type = Click
	 */
	@FindBy(xpath = "//button[@id='btnSaveProduct']")
	public static WebElement Products_New_SaveBtn;

	/*
    Page = Home page
    Element = Next Button
    Type = Click
	 */
	@FindBy(xpath = "//button[@id='btnNextPage']")
	public static WebElement Products_New_NextBtn;

	/*
    Page = Home page
    Element = Save button -Overlay
    Type = Click
	 */
	@FindBy(xpath = "//span[contains(text(),'Save')]")
	public static WebElement Products_New_SaveButton;

	/*
    Page = Home page
    Element = Step -Ratings & Pricing Screen
    Type = Text
	 */
	@FindBy(xpath = "//legend[contains(text(),'Rating & Pricing')]")
	public static WebElement Products_RnR;

	/*
    Page = Ratings & Pricing Screen
    Element = Override
    Type = Select
	 */
	@FindBy(xpath = "//select[@id='RateOverride']")
	public static WebElement Products_RnR_Override;

	/*
    Page = Ratings & Pricing Screen
    Element = Upload doc
    Type = Click
	 */
	@FindBy(xpath = "//a[@id='opener2']")
	public static WebElement Products_RnR_UploadRatings;

	/*
   Page = Ratings & Pricing Screen
    Element = Browse..
    Type = Click
	 */
	@FindBy(xpath = "//input[@id='file']")
	public static WebElement Products_RnR_UploadRatings_file;

	/*
    Page = Ratings & Pricing Screen
     Element = Effective Date
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='releaseDate']")
	public static WebElement Products_RnR_UploadRatings_EffectiveDate;

	/*
     Page = Ratings & Pricing Screen
      Element = Switch on Global Functions
      Type = Click
	 */
	@FindBy(xpath = "//div[@id='divGlobalFunction']/div/div/span[3]")
	public static WebElement Products_RnR_UploadRatings_SwitchOn;

	/*
    Page = Ratings & Pricing Screen
    Element = Upload
    Type = Click
	 */
	@FindBy(xpath = "//input[@id='btnUpload']")
	public static WebElement Products_RnR_UploadRatings_Upload;

	/*
     Page = Home page
     Element = Step3 -Premium Payments Taxes,Charges & Discounts
     Type = Text
	 */
	@FindBy(xpath = "//legend[contains(text(),'Premium Payments Taxes,Charges & Discounts')]")
	public static WebElement Products_PremiumPaymentScreen;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Payment Due Date
     Type = Text
	 */
	@FindBy(xpath = "//table[@id='PremiumPaymentsConfig']//input[@id='PaymentsDueFromPolicyInception']")
	public static WebElement Products_PP_PaymentDue;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Payment Request-Switch On
     Type = Text
	 */
	@FindBy(xpath = "//*[@id='PremiumPaymentsConfig']/tbody/tr[4]/td[2]/div/div/span[3]")
	public static WebElement Products_PP_PaymentRequest_SwitchOn;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Payment Request
     Type = Text
	 */
	@FindBy(xpath = "//table[@id='PremiumPaymentsConfig']//input[@id='PaymentDaysToBeSentThroughTPI']")
	public static WebElement Products_PP_PaymentRequest;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Create Continuous Payment
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='ContinuousPaymentDaysBeforePaymentDueDate']")
	public static WebElement Products_PP_CCPayment;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Additional Charges
     Type = Click
	 */
	@FindBy(xpath = "//div[contains(text(),'Additional Charges')]")
	public static WebElement Products_PP_AdditionalCharges;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Additional Charges
     Sub Element = Add New
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='btnAddNewAdditionalProductCharge']")
	public static WebElement Products_PP_AdditionalCharges_AddNew;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Charge type
     Type = Select
	 */
	@FindBy(xpath = "//select[@id='newAdditionalChargeType']")
	public static WebElement Products_PP_ChargeType;
	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Value
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='newAdditionalChargeValue']")
	public static WebElement Products_PP_Value;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = TP Beneficiary
     Type = Select
	 */
	@FindBy(xpath = "//select[@id='newAdditionalChargeBeneficiary']")
	public static WebElement Products_PP_TPBeneficiary;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Validity Start Date
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='newAdditionalChargeStartDate']")
	public static WebElement Products_PP_StartDate;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Validity End Date
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='newAdditionalChargeEndDate']")
	public static WebElement Products_PP_EndDate;

	/*
     Page = Premium Payments Taxes,Charges & Discounts Screen
     Element = Validity End Date
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='btnSaveProductAdditionalAmountCharge']")
	public static WebElement Products_PP_SaveButton;

	/*
     Page = Policy Transactions
     Element = Step4 -Policy Transactions
     Type = Text
	 */
	@FindBy(xpath = "//legend[contains(text(),'Policy Transactions')]")
	public static WebElement Products_PolicyTransactionScreen;

	/*
     Page = Policy Transactions
     Element = Step4 -Policy Transactions-MTA Calculations
     Type = Text
	 */
	@FindBy(xpath = "//a[contains(text(),'Click here to upload MTA calculation')]")
	public static WebElement MTA_Calculations;

	/*
     Page = Claims
     Element = Step5 -Claims
     Type = Text
	 */
	@FindBy(xpath = "//legend[contains(text(),'Claims')]")
	public static WebElement Products_ClaimScreen;

	/*
     Page = Documents and Subjectivities
     Element = Step6 -Documents and Subjectivities
     Type = Text
	 */
	@FindBy(xpath = "//legend[contains(text(),'Documents and Subjectivities')]")
	public static WebElement Products_DocumentsScreen;

	/*
     Page = B2C Product Content Configuration
     Element = Step6 -B2C Product Content Configuration
     Type = Text
	 */
	@FindBy(xpath = "//legend[contains(text(),'B2C Product Content Configuration')]")
	public static WebElement Products_B2CScreen;

	/*
     Page = B2C Product Content Configuration
     Element = Submit
     Type = Click
	 */
	@FindBy(xpath = "//button[@id='btnNextPage']")
	public static WebElement Products_Submit;

	/*
     Page = Client-Quote
     Element = Group Insured
     Type = Select
	 */
	@FindBy(xpath = "//select[@id='GroupInsured']")
	public static WebElement Client_Quote_GrpInsured;

	/*
     Page = Client-Quote
     Element = Group Insured-Next
     Type = Click
	 */
	@FindBy(xpath = "//input[@name='Next']")
	public static WebElement Client_Quote_Next;

	/*
     Page = Client-Quote
     Element = Group Insured-Next button
     Type = Click
	 */
	@FindBy(xpath = "//input[@type='button']")
	public static WebElement Client_Quote_Nextbtn;

	/*
     Page = Client-Quote
     Element = Quote Summary-Customer
     Type = Click
	 */
	@FindBy(xpath = "//button[contains(text(),'Search')]")
	public static WebElement Client_Quote_Summary;

	/*
     Page = New Customer page
     Element = Enter CustPlanRelationShip
     Type = DropDown
	 */
	@FindBy(xpath = "//select[@id='CustomerCompany_CustomerRelation']")
	public static WebElement CusPlanRelationShip;

	/*
     Page = New Customer page
     Element = Enter Company ID
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_CompanyID']")
	public static WebElement CompanyID;

	/*
     Page = New Customer page
     Element = Enter Company Name
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_CompanyName']")
	public static WebElement CompanyName;

	/*
     Page = New Customer page
     Element = Enter Company Name
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_FirstName']")
	public static WebElement CompanyName1;

	/*
     Page = New Customer page
     Element = Enter Department
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_Department']")
	public static WebElement Department;

	/*
     Page = New Customer page
     Element = Enter Department
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_LastName']")
	public static WebElement Department1;

	/*
     Page = New Customer page
     Element = Enter Address
     Type = Text
	 */
	@FindBy(xpath = "//input[@name='CustomerCompany.Email']")
	public static WebElement EmailAddress;

	/*
     Page = New Customer page
     Element = Enter Address
     Type = Text
	 */
	@FindBy(xpath = "//tr//td//input[@name='Customer.Email']")
	public static WebElement EmailAddress1;

	/*
     Page = New Customer page
     Element = Enter Address-Default
     Type = Select
	 */
	@FindBy(xpath = "//input[@id='chkEmail3']")
	public static WebElement EmailAddress_Defualt;

	/*
     Page = New Customer page
     Element = Enter Address-Default
     Type = Select
	 */
	@FindBy(xpath = "//input[@id='chkEmail1']")
	public static WebElement EmailAddress_Defualt1;

	/*
     Page = New Customer page
     Element = New Address
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'New Address')]")
	public static WebElement NewAddress;

	/*
     Page = Home page
     Element = Click Search Tab
     Type = Tab
	 */
	@FindBy(xpath = "//a[@class='fNiv' and contains(text(), 'Search')]")
	public static WebElement Tab_Search;

	/*
     Page = Home page
     Element = Enter Policy Ref
     Type = Text
	 */
	@FindBy(xpath = "//*[@id='MainContent_txtPolicyReference']")
	public static WebElement Policy_Ref;
	
	@FindBy(xpath = "//*[@id='MainContent_txtQuoteNumber']")
	public static WebElement Quote_Text;
	
	public static final By Client_Quote=By.xpath("//a[contains(text(),'Quote')]");

	/*
     Page = Home page
     Element = Enter Policy External Ref
     Type = Text
	 */
	@FindBy(xpath = "//*[@id='MainContent_txtExternalReference']")
	public static WebElement Policy_ExternalRef;

	/*
     Page = Home page
     Element = Enter Order Ref
     Type = Text
	 */
	@FindBy(xpath = "//*[@id='MainContent_txtOrderNumber']")
	public static WebElement Order_Ref;

	/*
     Page = Home page
     Element = Enter Policy Ref-Search
     Type = Text
	 */
	@FindBy(xpath = "//*[@id='MainContent_btnSearch']")
	public static WebElement Policy_Ref_Search;

	/*
     Page = Home page
     Element = Customer Records
     Type = Text
	 */
	@FindBy(xpath = "//*[@id='MainContent_gvCustomer_lnkCustomerName_0']")
	public static WebElement Searchscreen_Customer_Records;

	/*
     Page = Home page
     Element = Policy Number
     Type = Click
	 */
	@FindBy(xpath = "//*[@id='MainContent_gvPolicy_lnkpolicynumber_0']")
	public static WebElement Policy_Number;
	
	@FindBy(xpath = "//table[@class='pageGrid']//tbody//tr[2]//td[1]//a")
	public static WebElement Client_QuoteHyperLink;

	/*
     Page = Policy Search Screen
     Element = Policy Status
     Type = Click
	 */
	@FindBy(xpath = "//table[@id='MainContent_gvPolicy']//tr[2]//td[2]")
	public static WebElement PolicySearchScreen_PolicyStatus;

	/*
     Page = Policy Search Screen
     Element = Expiry Date
     Type = Click
	 */
	@FindBy(xpath = "//table[@id='MainContent_gvPolicy']//tr[2]//td[5]")
	public static WebElement PolicySearchScreen_ExpiryDate;

	/*
     Page = Home page
     Element = Additional Amount Section
     Type = Text
	 */
	@FindBy(xpath = "//div[@id='body_holder']/div[5]/div[1]/table")
	public static WebElement Additional_Amount_Section;

	/*
     Page = Home page
     Element = Additional Amount Type
     Type = Text
	 */
	@FindBy(xpath = "//div[@id='body_holder']//div[5]//div[1]//tr[2]/td[1]")
	public static WebElement Additional_Amount_Type;

	/*
     Page = Home page
     Element = Additional Amount Type
     Type = Text
	 */
	@FindBy(xpath = "//a[contains(text(),'Policy Payment Schedule')]")
	public static WebElement Policy_Payment_Schedule;

	/*
     Page = KTA
     Element = UserName
     Type = Text
	 */
	@FindBy(xpath = "//input[@name='txtUserName']")
	public static WebElement KTA_UserName;

	/*
     Page = KTA
     Element = Logon
     Type = Click
	 */
	@FindBy(xpath = "//span[contains(text(),'Logon')]")
	public static WebElement KTA_LogOn;

	/*
     Page = KTA
     Element = Claims reference
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='0029C1BC984E488AA397D689A1FB2E93-inputEl']")
	public static WebElement KTA_LogOn_ClaimsRefn;

	/*
     Page = KTA
     Element = Claims reference-Search
     Type = Click
	 */
	@FindBy(xpath = "//span[@class='x-btn-icon-el']")
	public static WebElement KTA_LogOn_Search; 

	/*
     Page = KTA
     Element = Manual Validation
     Type = Click 
	 */
	@FindBy(xpath = "//div[@id='tableWorkQueue_NEXTACTIONDUE_0']")
	public static WebElement KTA_ManualValidation; 

	/*
     Page = Continuous-MTA
     Element = Product
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='txtProductName']")
	public static WebElement MTA_Product; 

	/*
     Page = Continuous-MTA
     Element = Product-Search
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='btnSearch']")
	public static WebElement MTA_Product_Search; 

	/*
     Page = Continuous-MTA
     Element = 1st Product
     Type = Click
	 */
	@FindBy(xpath = "//div[@id='gridContent']/table/tbody/tr[1]/td[1]/a")
	public static WebElement MTA_Product_Select; 

	/*
     Page = New Customer page
     Element = Enter First Name
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_FirstName']")
	public static WebElement MTA_FirstName;

	/*
     Page = New Customer page
     Element = Enter last Name
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_LastName']")
	public static WebElement MTA_LastName;

	/*
     Page = MTA
     Element = Policy Transactions
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Policy Transactions')]")
	public static WebElement MTA_Transaction;

	/*
     Page = Policy View Screen
     Element = Customer Details
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Customer Details')]")
	public static WebElement Policy_CustomerDetails;

	/*
     Page = Policy View Screen
     Element = Customer Details Screen-Comapny Screen by default
     Type = Text
	 */
	@FindBy(xpath = "//li[@class='ui-state-default ui-corner-top ui-tabs-active ui-state-active']//a")
	public static WebElement Policy_CustomerDetails_Company;

	/*
     Page = Policy View Screen
     Element = Gross Premium Value
     Type = Text
	 */
	@FindBy(xpath = "//table[@style='margin-left:5px']//tbody//tr[6]//td[2]//input")
	public static WebElement PolicyViewScreen_GrossPremiumValue;

	/*
     Page = Policy View Screen
     Element = Policy Term
     Type = Text
	 */
	@FindBy(xpath = "//td//tr[1]//td[2]//div//input")
	public static WebElement PolicyViewScreen_PolicyTerm;


	/*
     Page = Policy View Screen
     Element = Customer Details-First Name
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_FirstName']")
	public static WebElement Policy_CustomerDetails_FN;

	/*
     Page = Policy View Screen
     Element = Customer Details-Middle Name
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_MiddleName']")
	public static WebElement Policy_CustomerDetails_MN;

	/*
     Page = Policy View Screen
     Element = Customer Details-Email
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_Email1']")
	public static WebElement Policy_CustomerDetails_Email;

	/*
     Page = Policy View Screen
     Element = Customer Details-Mobile No
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='CM_MobileNumber']")
	public static WebElement Policy_CustomerDetails_Mobile;


	/*
     Page = Policy View Screen
     Element = Policy Document
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Policy Documents ')]")
	public static WebElement Policy_Document;

	/*
     Page = MTA
     Element = Policy View Screen-Create MTA
     Type = Click
	 */
	@FindBy(xpath = "//button[contains(text(),'Create MTA')]")
	public static WebElement MTA_CreateMTA;

	/*
     Page = Policy View Screen
     Element = Enter External Ref No
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='ExternalRef']")
	public static WebElement MTA_CreateMTA_RefNo;

	/*
     Page = Policy View Screen
     Element = Addition Premium
     Type = Select
	 */
	@FindBy(xpath = "//select[@id='ddlPremiumPaymentType']")
	public static WebElement MTA_CreateMTA_SelectAdditionalPremium;

	/*
     Page = Policy View Screen
     Element = Enter MSIDN
     Type = Text
	 */
	@FindBy(xpath = "//input[@id='MSISDN']")
	public static WebElement MTA_CreateMTA_MSIDN;


	/*
     Page = Policy View Screen
     Element = MTA Descriptions
     Type = Text
	 */
	@FindBy(xpath = "//*[@id='Description']")
	public static WebElement MTA_CreateMTA_MTADes;

	/*
     Page = Policy View Screen
     Element = Calculate button
     Type = Click
	 */
	@FindBy(xpath = "//*[@id='btnCalculate']")
	public static WebElement MTA_CreateMTA_Calculatebtn;

	/*
     Page = Customer View PAge
     Element = Net Premium
     Type = Text Box
	 */
	@FindBy(xpath = "//div[@id='divnet']/div[4]")
	public static WebElement MTA_Calculation_NetPremium;

	/*
     Page = Customer View PAge
     Element = Tax
     Type = Text Box
	 */
	@FindBy(xpath = "//div[@id='divtax']/div[4]")
	public static WebElement MTA_Calculation_Tax;

	/*
     Page = Customer View PAge
     Element = Gross Premium
     Type = Text Box
	 */
	@FindBy(xpath = "//input[@id='APRPValueString']")
	public static WebElement MTA_Calculation_GrossPremium;

	/*
     Page = Customer View PAge
     Element = Save Button
     Type = Text Box
	 */
	//@FindBy(xpath = "//*[@id='btnSave']")
	//public static WebElement MTA_Calculation_Savebtn;
	public static final By MTA_Calculation_Savebtn=By.xpath("//*[@id='btnSave']");

	/*
     Page = Customer View PAge
     Element = Yes Button-Pop up
     Type = Text Box
	 */
	@FindBy(xpath = "//div[@class='ui-dialog-buttonset']//span[contains(text(),'Yes')]")
	public static WebElement MTA_Calculation_Popup_Yesbtn;

	/*
     Page = Customer View PAge
     Element = Ok Button
     Type = Text Box
	 */
	@FindBy(xpath = "//span[contains(text(),'Yes')]")
	public static WebElement MTA_Calculation_OkBtn;

	/*
     Page = Customer View PAge
     Element = Type
     Type = Text Box
	 */
	@FindBy(xpath = "//*[@id='form1']/table/tbody/tr[1]/td[3]")
	public static WebElement MTA_Calculation_Type;

	/*
     Page = Customer View PAge
     Element = MTA referral Action
     Type = Text Box
	 */
	@FindBy(xpath = "//div[@id='divcalc']")
	public static WebElement MTA_Referellel_ActionBox;

	/*
     Page = Customer View PAge
     Element = MTA Referral Email
	 */
	@FindBy(xpath = "//span[contains(text(),'MTA Referral Additional Information Email')]")
	public static WebElement MTA_Referral_Email_Popup;

	/*
     Page = Customer View PAge
     Element = MTA referral Action
     Type = Box
	 */
	@FindBy(xpath = "//h3[contains(text(),'MTA Referral Action')]")
	public static WebElement MTA_Referellel_ActionBox1;

	/*
     Page = Client-Quote
     Element = SLA-Policy Details View Screen
     Type = Text
	 */
	@FindBy(xpath = "//div[contains(text(),'SLA')]")
	public static WebElement MTA_Referellel_Action_SLA;

	/*
     Page = -Policy View Screen
     Element = Assign Button
     Type = Click
	 */
	@FindBy(xpath = "//button[contains(text(),'Assign')]")
	public static WebElement MTA_Referral_Action_AssignBtn;

	/*
     Page = Client-Quote
     Element = Customer Screen-Create Customer
     Type = Text
	 */
	@FindBy(xpath = "//button[contains(text(),'Unassign')]")
	public static WebElement MTA_Referral_Action_UnAssignBtn;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Transactions-1st Link
     Type = Click
	 */
	@FindBy(xpath = "//table//tr[@class='gridRow'][1]//td[1]//div//a")
	public static WebElement MTA_PolicyTransaction_FirstLink;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Transactions-MTA Status
     Type = Click
	 */
	@FindBy(xpath = "//input[@value='Referred']")
	public static WebElement MTA_PolicyTransaction_MTA_Status;

	/*
     Page = MTA
     Element = Policy Transactions-MTA Reason
     Type = Click
	 */
	@FindBy(xpath = "//table//tbody//tr[8]//td[2]//div//input[@class='textbox']") 
	public static WebElement MTA_PolicyTransaction_MTA_Reason;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Transactions
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Policy Audit')]")
	public static WebElement MTA_Policy_Audit;

	/*
     Page = MTA-Policy View Screen
     Element = Policy 
     Type = Click
	 */
	@FindBy(xpath = "//a[@class='fNiv k-link k-header' and contains(text(),'Policies')]")
	public static WebElement MTA_PolicyTab;

	/*
     Page = MTA-Policy View Screen
     Element = Accept MTA
     Type = Click
	 */
	@FindBy(xpath = "//button[@id='btnAcceptMTA']")
	public static WebElement MTA_PolicyViewScreen_AcceptMTA;

	/*
     Page = MTA-Policy View Screen
     Element = Accept MTA-Net Premium
     Type = Click
	 */
	@FindBy(xpath = "//div//table//tr[7]//td[@style='width:200px']/input")
	public static WebElement MTA_AcceptMTA_NetPremium;


	/*
     Page = MTA-Policy View Screen
     Element = Transactions History Tab
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Transaction History')]")
	public static WebElement MTA_Transaction_History;

	/*
     Page = MTA-Policy View Screen
     Element = Transactions History Screen-Search From
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='MainContent_txtDateFrom']")
	public static WebElement MTA_Transaction_History_From;

	/*
     Page = MTA-Policy View Screen
     Element = Transactions History Screen-Search To
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='MainContent_txtDateTo']")
	public static WebElement MTA_Transaction_History_To;

	/*
     Page = MTA-Policy View Screen
     Element = Transactions History Screen-Search Button
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='MainContent_btnSearch']")
	public static WebElement MTA_Transaction_History_Search;

	/*
     Page = MTA-Policy View Screen
     Element = Transactions History Screen-Table Created
     Type = Click
	 */
	@FindBy(xpath = "//table[@id='MainContent_gvTransactionHistory']")
	public static WebElement MTA_Transaction_History_TableCreated;

	/*
     Page = MTA-Policy View Screen
     Element = Transactions History Screen-Customer Willis
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Customer:Willis')]")
	public static WebElement MTA_Transaction_HistoryScreen_CustomerWillis;

	/*
     Page = MTA-Policy View Screen
     Element = Transactions History Screen-Policies
     Type = Click
	 */
	@FindBy(xpath = "//span[contains(text(),'Policies')]")
	public static WebElement MTA_Transaction_HistoryScreen_Policies;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Document
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Policy Documents')]")
	public static WebElement MTA_Policy_Document;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Document-Download
     Type = Click
	 */
	@FindBy(xpath = "//button[@id='btnDownloadDocument']")
	public static WebElement MTA_Policy_Document_Download;
	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment Screen-Policies Attachment
     Type = Click
	 */
	@FindBy(xpath = "//a[contains(text(),'Policy Attachments ')]")
	public static WebElement MTA_PoliciesAttachment;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment screen-Attachment
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='btnSubmit']")
	public static WebElement MTA_PoliciesAttachment_AttachmentBtn;


	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment screen-Choose File
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='AttachmentItem_File']")
	public static WebElement MTA_AttachmentScreen_Choosefile;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment screen-Transaction
     Type = Click
	 */
	@FindBy(xpath = "//select[@id='AttachmentItem_TransactionId']")
	public static WebElement MTA_AttachmentScreen_Transaction;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment screen-Type
     Type = Click
	 */
	@FindBy(xpath = "//select[@id='AttachmentItem_TypeId']")
	public static WebElement MTA_AttachmentScreen_Type;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment screen-Date
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='txtdate']")
	public static WebElement MTA_AttachmentScreen_Date;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment screen-Save Button
     Type = Click
	 */
	@FindBy(xpath = "//input[@id='bottombtnSave-Click']")
	public static WebElement MTA_AttachmentScreen_SaveBtn;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Attachment screen-Type-After upload doc
     Type = Click
	 */
	@FindBy(xpath = "//table[@class='pageGridClaims']")
	public static WebElement MTA_AttachmentScreen_UploadedType;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Transaction Screen-Cancel
     Type = Click
	 */
	@FindBy(xpath = "//div[@class='container']//button[@class='btn cancel-mta']")
	public static WebElement MTA_PolicyTransactionscreen_Cancel;

	/*
     Page = MTA-Policy View Screen
     Element = Policy Transaction Screen-Continue
     Type = Click
	 */
	@FindBy(xpath = "//span[contains(text(),'Continue')]")
	public static WebElement MTA_PolicyTransactionscreen_Cancel_Continue;

	/*
 	Page = Quote Selection Screen
     Element = Inception date
     Type = date field
	 */
	public static final By date_inception=By.xpath("//*[@id='QuoteDetails_InceptionDate']");


	//****WebElement of Policy Extension******************* 

	//Client Module Affinity Ops
	/*
 	    Page = Login Page Client
 	    Element = User name
 	    Type = Text Box
	 */
	public static final By txt_UsernameClient1=By.xpath("//input[@id='MainContent_txtUserName']");


	/*
 	    Page =  Login Page Client
 	    Element = Password 
 	    Type = Text Box
	 */
	public static final By txt_PasswordClient1=By.xpath("//*[@id='MainContent_txtPassword']");

	/*
 	    Page = Login Page Client
 	    Element = Login Button
 	    Type = Text Box
	 */
	public static final By btn_LoginClient1=By.xpath("//*[@id='MainContent_btnLogin']");

	/*
 	    Page = Sponsor selection page Client
 	    Element = Sponsor
 	    Type = Drop down
	 */
	@FindBy(xpath = "//*[@id='MainContent_ddlSponsors_ddlControl']")
	public static final By cmb_select_sponsorClient1=By.xpath("//*[@id='MainContent_ddlSponsors_ddlControl']");

	/*
 	    Page = Sponsor selection page Client
 	    Element = Select Sponsor
 	    Type = Sponsor Button
	 */
	public static final By btn_selectClient1=By.xpath("//*[@id='MainContent_btnSelect']");

	/*
		Page = Quote Screen
		Element = Product -  3 F�rs�kring
		Type = Product
	 */
	public static final By link_3forsakring=By.xpath("//h3[text()='3 F�rs�kring']");

	/*
		Page = Quote Details Screen
		Element = First payment due date
		Type = Date field
	 */
	public static final By txt_firstpaymentduedate=By.xpath("//input[@id='FirstPaymentDueDate']");

	/*
		Page = Quote Details Screen
		Element = First PURCHASEDATE date
		Type = Date field
	 */
	public static final By txt_purchasedate=By.xpath("//input[@id='PURCHASEDATE']");

	/*
		Page = Quote Details Screen
		Element = First Devaice Make date
		Type = Text field
	 */
	public static final By txt_devicemake=By.xpath("//input[@id='DEVICEMAKE']");

	/*
		Page = Quote Details Screen
		Element = First Devaice Modal date
		Type = text field
	 */
	public static final By txt_devicemodal=By.xpath("//input[@id='DEVICEMODEL']");

	/*
		Page = Quote Details Screen
		Element = First Devaice Modal date
		Type = Text field
	 */
	public static final By txt_devicespecifixcation=By.xpath("//input[@id='DEVICESPECIFICATION']");

	/*
		Page = Quote Details Screen
		Element = First Devaice Modal date
		Type = text field
	 */
	public static final By txt_imeinumber=By.xpath("//input[@id='IMEIOLD']");

	/*
	     Page = Quote response screen
	     Element = Policy expiry date
	     Type = date field
	 */
	public static final By date_expiry=By.xpath("//*[@id='ExpiryDate']");

	/*
	    Page = Quote response screen Finance Product
	    Element = Next
	    Type = button
	 */
	public static final By btn_next=By.xpath("//input[@id='btnNext']");


	/*
	    Page = Quote response screen Finance Product
	    Element = Next after premium displayed
	    Type = button
	 */
	public static final By btn_next1=By.xpath("//input[@value='Next']");

	/*
	    Page = Quote response screen Finance Product
	    Element = Total Gross Premium
	    Type = Text
	 */
	public static final By txt_totalGrossPremium=By.xpath("//td[contains(text(),'Total Gross Premium:')]");

	/*
	    Page = Quote response screen Finance Product
	    Element = Search
	    Type = Text box
	 */
	public static final By txt_search=By.xpath("//*[@id='SearchTerm']");

	/*
	    Page = Quote response screen Finance Product
	    Element = Search result first link
	    Type = Link
	 */
	public static final By lnk_customerSearch=By.xpath("//*[@id='resultsContainer']//a");

	/*
	    Page = Quote response screen Finance Product
	    Element = Search button
	    Type = button
	 */
	public static final By btn_search=By.xpath("//button[contains(text(),'Search')]");
	
	/*
    Page = Home page
    Element = Enter Search
    Type = Button
	 */
	@FindBy(xpath = "//*[@id='MainContent_btnSearch']")
	public static WebElement btn_Search;
	public static final By btn_search2 = By.xpath("//*[@id='MainContent_btnSearch']");

	/*
	    Page = Customer Details Page
	    Element = Create Policy button
	    Type = button
	 */
	public static final By btn_createPolicy=By.xpath("//a[contains(text(),'Create Policy')]");

	/*
	    Page = Confirmation Screen
	    Element = Policy Number
	    Type = text field
	 */
	public static final By txt_policyNumber=By.xpath("//input[@name='PolicyNumber']");

	/*
	    Page = Quote response screen Finance Product
	    Element = Dealer Name
	    Type = text field
	 */
	public static final By txt_dealerNamefact=By.xpath("//input[@name='[1].Questions[DealerName].Response.Value']");

	/*
	    Page = Quote response screen Finance Product
	    Element = Product Name
	    Type = drop down
	 */
	public static final By dd_productNamefact=By.xpath("//select[@name='[1].Questions[ProductName].Response.Value']");

	/*
		Page = Create MTA screen
	    Element = External Reference number 
	    Type = Text box
	 */
	public static final By txt_ExternalRef=By.xpath("//input[@id='ExternalRef']");

	/*
		Page = Quote Details Screen
		Element = External refernce number
		Type = text field
	 */
	public static final By txt_externalref=By.xpath("//input[@id='txtPolicyExternalRef']");


	/*
		Page = Quote Details Screen
		Element =Next 
		Type = button
	 */
	public static final By btn_next2=By.xpath("//input[@type='submit' and @value='Next']");

	/*
	     Page = Home page
	     Element = Click Search Tab
	     Type = Tab
	 */
	public static final By Tab_Search1=By.xpath("//a[@class='fNiv' and contains(text(), 'Search')]");

	/*
	     Page = Home page
	     Element = Enter Policy Ref
	     Type = Text
	 */
	public static final By txt_policyRef=By.xpath("//*[@id='MainContent_txtPolicyReference']");

	/*
	     Page = Home page
	     Element = Enter Policy Ref-Search
	     Type = Text
	 */
	public static final By Policy_Ref_Search1=By.xpath("//*[@id='MainContent_btnSearch']");
	
	public static final By link_ordernumber=By.xpath("//table[@id='MainContent_gvOrder']//tr[2]//td[2]/a");

	/*
	Page =Search Result Screen
    Element = Status
    Type = text
	 */
	public static final By txt_ClientpolicyStatus=By.xpath("//*[@id='MainContent_gvPolicy']/tbody/tr[2]/td[2]");

	/*
	     Page = Home page
	     Element = Policy Number
	     Type = Click
	 */
	public static final By lnk_Policy_Number=By.xpath("//*[@id='MainContent_gvPolicy_lnkpolicynumber_0']");

	/*
		Page =View Reportpage 
	    Element =iFrame for report displayed
	    Type = iFrame
	 */
	public static final By tab_policyRenwal=By.xpath("//a[text()='Policy Renewal']");

	/*
		Page =View Reportpage 
	    Element =Renewal Quote status
	    Type = Text
	 */
	public static final By txt_statusRenewalQuote=By.xpath("//div[@id='QuotePolicyRenewal']//td[3]");
	
	/*
	Page =View Reportpage 
    Element =Renewal quote nunmber
    Type = text
	 */
	public static final By txt_renewalQuotenumber=By.xpath("//div[@id='QuotePolicyRenewal']//td[2]");

	/*
	     Page = MTA
	     Element = Policy View Screen-Create MTA
	     Type = Click
	 */
	public static final By btn_createMTA=By.xpath("//button[contains(text(),'Create MTA')]");
	public static final By btn_createMTAdisabled=By.xpath("//input[@value='Create MTA']");

	/*
	Page =Customer details page
	Element =Quote
	Type = link
	*/
	public static final By txt_VinMTACAT =By.xpath("//input[@id='MachineInformation_0__VIN']");
	
	/*
    Page = Create MTA
    Element = MTA effective date
    Type = Date field
	 */
	public static final By dt_MTAeffectivedate=By.xpath("//*[@id='EffectiveDateString']");
	
	/*
	Page = Quote Selection Screen
    Element = APRPValueString
    Type = Text box
	 */
	public static final By txt_APRPValueString=By.xpath("//input[@id='APRPValueString']");
	
	/*
	Page =View Reportpage 
    Element =Declaration Check box
    Type = Check box
	 */
	public static final By btn_acceptdeclaration=By.xpath("//input[@id='AcceptDecleration']");
	
	/*
		Page = Create MTA screen
		Element =Expiry date
		Type = text 
	 */
	public static final By txt_expirydate=By.xpath("//input[@id='ExpiryDateString']");

	/*
		Page = Create MTA screen
		Element =Expiry date
		Type = text 
	 */
	public static final By txt_expirydateviewpolicy=By.xpath("//input[@id='txtExpiryDate']");

	/*
	Page =Policy Transaction Screen
    Element =MTA
    Type = text 
	 */
	public static final By txt_mtaStatus=By.xpath("//table[@class='pageGrid']/tbody/tr[1]/td[3]");

	/*
    Page = Policy View Screen
    Element = Calculate button
    Type = Click
	 */
	public static final By MTA_CreateMTA_Calculatebtn1 = By.xpath("//*[@id='btnCalculate']");

	/*
    Page = Customer View PAge
    Element = Save Button
    Type = Text Box
	 */
	public static final By btn_save = By.xpath("//*[@id='btnSave']");


	/*
    Page = MTA-Policy View Screen
    Element = Policy Transactions-1st Link
    Type = Click
	 */
	public static final By MTA_PolicyTransaction = By.xpath("//a[contains(text(),'Policy Transactions')]");

	/*
    Page = Quote Selection Selection screen
    Element = financing product
    Type = Text
	 */
	public static final By product_factoring=By.xpath("//div[text()[contains(.,'John Deere farm machinery factoring insurance')]]");

	/*
    Page = Quote response screen Finance Product
    Element = Model Number
    Type = text box
	 */
	public static final By dd_modelNumberfact=By.xpath("//input[@name='[1].Questions[ModelNumber].Response.Value']");

	/*
    Page = Quote response screen Finance Product
    Element = Pin Number
    Type = text box
	 */
	public static final By txt_pinNumberfact=By.xpath("//input[@name='[1].Questions[PinNumber].Response.Value']");

	/*
    Page = Quote response screen Finance Product
    Element = Insured Amount
    Type = text box
	 */
	public static final By txt_InsuredAmountfact=By.xpath("//input[@name='[1].Questions[InsuredAmount1].Response.Value']");

	/*
    Page = Quote response screen Finance Product
    Element = equipment information
    Type = text box
	 */
	public static final By txt_locofMachinefact=By.xpath("//input[@name='[1].Questions[LocofMachine].Response.Value']");

	/*
    Page = Quote response screen Finance Product
    Element = PRA Rate
    Type = drop down
	 */
	public static final By dd_parRatefact=By.xpath("//select[@name='[1].Questions[PARRate].Response.Value']");

	/*
    Page = Quote response screen Finance Product
    Element = Driver Liability1
    Type = drop down
	 */
	public static final By dd_driverLiabilityfact=By.xpath("//select[@name='[1].Questions[DriverLiability1].Response.Value']");

	/*
    Page = Quote response screen Finance Product
    Element = TPL amount
    Type = drop down
	 */
	public static final By dd_tplAmountfact=By.xpath("//select[@name='[1].Questions[TPLAmount].Response.Value']");

	/*
    Page = Quote response screen Finance Product
    Element = TPL amount response 100000
    Type = drop down
	 */
	public static final By dd_tplAmount100000fact=By.xpath("//select[@name='[1].Questions[TPLAmount].Options[100,000].Questions[TPLRate1].Response.Value']");

	/*
	Page =View Policy Screen
    Element = Policy Cancel
    Type = Tab
	 */
	public static final By tb_cancelPolicy=By.xpath("//a[contains(text(),'Cancel Policy')]");

	/*
	Page =Cancel Policy Screen
    Element = Policy Cancel
    Type = drop down
	 */
	public static final By dd_reasonID=By.xpath("//select[@id='ReasonID']");

	/*
	Page =Cancel Policy Screen
    Element = Party ID
    Type = drop down
	 */
	public static final By dd_party=By.xpath("//select[@id='Party']");

	/*
	Page =Cancel Policy Screen
    Element = Voluntary or Forced
    Type = drop down
	 */
	public static final By dd_VoluntaryorForced=By.xpath("//select[@id='Type']");

	/*
	Page =Policy payment screen
    Element = payment
    Type = text
	 */
	public static final By dd_coolingoff=By.xpath("//*[@id='CancellationRefundTypeID']	");


	/*
	Page =Policy payment screen
    Element = Cancellation date
    Type = text
	 */
	public static final By txt_cancellingdate=By.xpath("//*[@id='txtdate']");

	/*
	Page =Cancel Policy Screen
    Element = Calculate refund
    Type = Button
	 */
	public static final By btn_calculaterefund=By.xpath("//input[@value='Calculate Refund']");
	
	/*
	Page =cancellation policy
    Element = Cancellation date must be between inception date and expiry date
    Type = text
	 */
	public static final By txt_cancellationerror=By.xpath("//li[contains(text(),'Cancellation date must be between inception date and expiry date')]");

	/*
	Page =Cancel Policy Screen
    Element = Save button
    Type = Button
	 */
	public static final By btn_saveCancel=By.xpath("//input[@value='Save']");

	/*
	Page =Cancel Policy Screen
    Element = okay in popup
    Type = Button
	 */
	public static final By btn_ok=By.xpath("//span[contains(text(),'OK')]");
	
	public static final By tab_Policy_Audit = By.xpath("//a[contains(text(),'Policy Audit')]");
	

	/*
	Page =Cancel Policy Screen
    Element = Other in popup
    Type = Button
	 */
	public static final By btn_other=By.xpath("//span[contains(text(),'Other') and @class='ui-button-text']");
	
	/*
	Page =Policy Audit screen
    Element = Status
    Type = text
	 */
	public static final By txt_cancellationother=By.xpath("//*[text()='Cancellation - Other']");
	
	/*
    Page = Home page
    Element = Additional Amount Type
    Type = Text
	 */
	@FindBy(xpath = "//a[contains(text(),'Policy Payment Schedule')]")
	//public static WebElement Policy_Payment_Schedule;
	public static final By link_Policy_Payment_Schedule = By.xpath("//a[contains(text(),'Policy Payment Schedule')]");
	
	/*
	Page =Policy payment screen
    Element = payment
    Type = text
	 */
	public static final By txt_cancellationotherpayment=By.xpath("//table[@class='pageGrid']//tr[1]/td[2]");
	
	/*
	Page =Policy payment screen
    Element = Select Cancellation reason
    Type = text
	 */
	public static final By txt_selectCancellationReason=By.xpath("//li[text()='Please select a Cancellation Reason.']");
	
	
	/*
	Page =Policy Audit screen
    Element =POlicy  Status
    Type = text
	 */
	public static final By txt_policyStatus=By.xpath("//*[@id='body_holder']/table/tbody/tr[1]/td[4]");

	/*
	Page =Policy payment screen
    Element = Select Cancellation reason
    Type = text
	 */
	public static final By txt_awaitingCancellation=By.xpath("//*[@id='body_holder']/div[1]/div/div/div[3]");

	/*
	Page =Policy payment screen
    Element = Select Cancellation reason
    Type = text
	 */
	public static final By btn_SaveQuote=By.xpath("//input[@id='QuotePopupid']");

	/*
    Page = Login Page Client
    Element = Login Button
    Type = Text Box
     */
    public static final By firstPay = By.id("FirstPaymentDueDate");
    
    public static final By pURCHASEDATE = By.id("PURCHASEDATE");
    
    public static final By dEVICEMAKE = By.id("DEVICEMAKE");
    public static final By dEVICEMAKEST = By.id("INSUREDOBJECTDESCRIPTION");
    
    public static final By dEVICEMODEL = By.id("DEVICEMODEL");
    
    public static final By dEVICESPECIFICATION = By.id("DEVICESPECIFICATION");
    
    public static final By policyTermid = By.id("POLICYTERM");
    
    public static final By pRODUCTid = By.id("PRODUCTID");

    public static final By btnNext = By.id("btnNext");
    
    public static final By nextBt = By.xpath("//input[@type='button' and @value='Next']");
    
    public static final By searchTxt = By.id("SearchTerm");
    
    public static final By btnSearch = By.xpath("//button[@type='submit']");
    
    public static final By searchResult = By.xpath("//div[@id='resultsContainer']//td/div/a");
    
    public static final By btnCreatePolicy = By.xpath("//a[text()='Create Policy']");
    
    public static final By txtExtRef = By.id("txtPolicyExternalRef");
    
    public static final By btNext = By.xpath("//input[@type='submit' and @value='Next']");
    
    public static final By policyNumber = By.id("PolicyNumber");
    
    public static final By expDate = By.id("ExpiryDate");
	



}






