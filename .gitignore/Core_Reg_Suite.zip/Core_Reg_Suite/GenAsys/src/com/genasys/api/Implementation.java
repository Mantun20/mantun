package com.genasys.api;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.genasys.api.Implementation;
import com.genasys.utils.DataSheetRead;
import com.genasys.utils.NextGenUtilities;

public class Implementation{

	//private static String jobLocation, jobCategory;
	WebDriver driver;
	
	public void Implementation(WebDriver driver){
		this.driver = driver;
	}
	
	public String [] getToken(String string){
		String a[] = string.split("/");		
		return a;	

	} 
	public boolean isobjPresent(WebElement obj){
		try{
		if(obj.isDisplayed()||obj.isEnabled()||obj.isSelected())
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	    return false;
	} 
	
	public void waitThread(int milliseconds){
	       try {
	              Thread.sleep(milliseconds);
	       } catch (InterruptedException e) {
	              // TODO Auto-generated catch block
	              e.printStackTrace();
	       }
	}

	
	/* Get the latest file from a specific directory*/
	@SuppressWarnings("unused")
	protected File getLatestFilefromDir(String dirPath){
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) { 
	        return null;
	    }
	
	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    return lastModifiedFile;
	}
	

	public void acceptNavigation(WebDriver driver){
		//handle alert pop up
	    WebDriverWait wait = new WebDriverWait(driver, 60);
	    wait.until(ExpectedConditions.alertIsPresent());
	    Alert alert = driver.switchTo().alert();
	    alert.accept(); 
	}
	
	public boolean isobjSelect(WebElement obj){
		try{
		if(obj.isDisplayed()||obj.isEnabled()||obj.isSelected())
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	    return false;
	}
	
	public String getPlacementName()
	{
	String HourStamp = new SimpleDateFormat("HH").format(Calendar.getInstance().getTime());
	String MinuteStamp = new SimpleDateFormat("mm").format(Calendar.getInstance().getTime());
	String SecondStamp = new SimpleDateFormat("ss").format(Calendar.getInstance().getTime());
	int CurrentTimeSeconds = Integer.parseInt(HourStamp)*3600 + Integer.parseInt(MinuteStamp)*60 + Integer.parseInt(SecondStamp);
	int difftime = 86400 - CurrentTimeSeconds;
    String DateStamp = new SimpleDateFormat("yy-MMM-dd").format(Calendar.getInstance().getTime());
	String placement_name1= DateStamp + " " + difftime+"Willis";
	return placement_name1;
	}
	
	public boolean isobjDisplayed_Warning(WebElement obj,String StepDescription, String passmsg,String warnmsg){
		try{
		if(obj.isDisplayed()){
			NextGenUtilities.appendPass(StepDescription,passmsg);
			return true;
		}
		else{
			NextGenUtilities.appendWarning(warnmsg);
			return false;
		  }
		}
		catch(NoSuchElementException exception){
			NextGenUtilities.appendWarning(warnmsg);
			return false;
		}
	
	}
		
	public boolean isobjDisplayedWait(WebElement obj,int t,String StepDescription, String PassMessage, String FailMessage)
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, (long)t);
		
		WebElement we = wait.until(ExpectedConditions.visibilityOf(obj));
		if(we.isDisplayed())
		{
			NextGenUtilities.appendPass(StepDescription,PassMessage);
			return true;
		}
		else
		{
			NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			return false;
		}
		}
		catch(NoSuchElementException exception)
		{
			return false;
		}
		
	}
	
	public boolean isobjDisplayed(WebElement obj){
		try{
		if(obj.isDisplayed())
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	    return false;
	}
	
	public Implementation launchClientURL1(WebDriver driver, String clientName, String browsername) {
		
		if(NextGenUtilities.failStep==0){
			NextGenUtilities.failStep=0;
			NextGenUtilities.excelLog="Failed Steps :\n";
			NextGenUtilities.testFailed = "Passed";
		}
		NextGenUtilities.appendTestCaseHeader("Home Page UI Validation" + " (" + clientName + ")");
		String url; // = "http://" + clientName;
			url = "http://" + clientName;
			try
			{
				driver.get(url);
				if(!driver.getTitle().contains("Jobs"))
				{
					NextGenUtilities.logFailure(driver,"Launch the URL",url + " - URL is not available");
				}else				{
					NextGenUtilities.appendPass("Launch URL","URL Loaded Successfully : " + driver.getTitle());
				}
			}
			catch(Exception e)
			{
				NextGenUtilities.logFailure(driver,"Launch the URL",url + " URL is not available");
			}
		
		return PageFactory.initElements(driver, Implementation.class);
	}

	
	public static Implementation navigateTo(WebDriver driver, String url) {
		driver.navigate().to(url);
		return PageFactory.initElements(driver, Implementation.class);
	}
	
	
	public void BrowserBack(WebDriver driver){
		try{
			driver.navigate().back();
	 	}catch(Exception e){
	 		NextGenUtilities.logFailure(driver,"Click on Browser Back button","Cannot perform the Backward navigation in Browser");
		}
	}
	
	public boolean verifyObjectPresent(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
			try{
				if(isobjPresent(Obj)){
					NextGenUtilities.appendPass(StepDescription,PassMessage);
				return true;
				}else{
					NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
					return false;
				}
			}catch(NoSuchElementException exception){
				NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
				exception.printStackTrace();
			
			}
			return false;
	}
	public boolean SkipTest(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
		if(isobjPresent(Obj)){
			NextGenUtilities.appendPass(StepDescription,PassMessage);
		return true;
		}else{
			NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			Obj.click();
			return false;
		}
	}
	
	public boolean verifyObjectNotPresent(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
		try{
			if(isobjPresent(Obj)){
				NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
				//Obj.click();
				return true;
				//NextGenUtilities.appendPass("The Object is clicked-" + Obj);
			}else{
				NextGenUtilities.appendPass(StepDescription, PassMessage);	
			  return false;
			}
		}catch(NoSuchElementException exception){
		 return false;
		}
		
	}
	
	public boolean verifyPartialObjectPresent(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
		try{
			if(isobjPresent(Obj)){
				NextGenUtilities.appendPass(StepDescription,PassMessage);
			    return true;
			}			
		}catch(NoSuchElementException exception){
		  //NextGenUtilities.logFailure(driver,"Search By Location label is not present in HomePage");			
			exception.printStackTrace();
			return false;
		}
		return false;
}
	
	
	public boolean EnterTextFeild(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage,String Value){
		try{
 			if(isobjDisplayed(Obj)){
				NextGenUtilities.appendPass(StepDescription,PassMessage);
				Obj.clear();
				Obj.sendKeys(Value);
				return true;
			}else{
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				((JavascriptExecutor) jse).executeScript("arguments[0].type ='D:\fbbe.jpg';",Obj);

				NextGenUtilities.logFailure(driver,StepDescription,FailMessage);
			return false;
			}
		}catch(Exception exception){
	          exception.printStackTrace();
			if(exception.getMessage().contains("Element is not currently visible")){
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				 executor.executeScript("document.getElementByTagName('job_input_text').value = '"+Value+"';");

				return true;
			}else{
			NextGenUtilities.logFailure(driver,StepDescription,FailMessage);
			return false;
			}
		}
	}
	

	public boolean ClickFeild(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
		try{
			if(isobjPresent(Obj)){
				NextGenUtilities.appendPass(StepDescription, PassMessage);
              System.out.println("done");

     	   ((JavascriptExecutor)driver).executeScript("arguments[0].click();", Obj); 
			return true;
				
			}else
				NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			
			return false;
		}catch(NoSuchElementException exception){
			NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			return false;
		}
	}
	
	
	public boolean mouseClickFeild(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
		try{
			if(isobjPresent(Obj)){
				NextGenUtilities.appendPass(StepDescription, PassMessage);
              System.out.println("done");

     	   //((JavascriptExecutor)driver).executeScript("arguments[0].click();", Obj); 
  		    DesiredCapabilities d = DesiredCapabilities.internetExplorer();
  		    d.setCapability("nativeEvents", true);
  		    Locatable hoverItem = (Locatable) Obj;

  		    Mouse mouse = ((HasInputDevices) driver).getMouse();
  		    //clickItem.getCordinates(clickItem).click(); 
  		    mouse.mouseMove(hoverItem.getCoordinates());
  		    mouse.click(hoverItem.getCoordinates());
  		    
  		   d.setCapability("nativeEvents", false);
			return true;
				
			}else
				NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			
			return false;
		}catch(NoSuchElementException exception){
			NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			return false;
		}
	}
	
	public boolean DoubleClick(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
		try{
			if(isobjPresent(Obj)){
				NextGenUtilities.appendPass(StepDescription, PassMessage);
              System.out.println("done");

     	              Actions actions=new Actions(driver);
	                  actions.moveToElement(Obj).doubleClick().perform();
	           return true;
			}else
				NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			
			return false;
		}catch(NoSuchElementException exception){
			NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
			return false;
		}
	}
	
public Implementation launchClientURL(WebDriver driver, String clientName, String browsername) {
		
		if(NextGenUtilities.failStep==0){
			NextGenUtilities.failStep=0;
			NextGenUtilities.excelLog="Failed Steps :\n";
			NextGenUtilities.testFailed = "Passed";
		}
		String url; // = "http://" + clientName;
		
		
			url = "http://"+clientName;
			try{
				driver.get(url);
				if(browsername.equalsIgnoreCase("chrome")){
					Thread.sleep(5000);
					
					}
			
					System.out.println("URL found : " + driver.getTitle());
				}catch(Exception e){
				e.printStackTrace();
				//NextGenUtilities.failStep=0;
				NextGenUtilities.logFailure(driver,"Launch URl",url + " URL is not available");
				Assert.fail(driver.getTitle());
			}
		
		
		return PageFactory.initElements(driver, Implementation.class);
	}
public boolean MouseOver(WebDriver driver,WebElement Obj,String StepDescription, String PassMessage, String FailMessage){
    try{
           if(isobjPresent(Obj)){
                  NextGenUtilities.appendPass(StepDescription, PassMessage);
                  
                  Actions actions=new Actions(driver);
                  actions.moveToElement(Obj).perform();
           return true;
           }else{
                  NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
                  return false;
           }
    }catch(NoSuchElementException exception){
           //NextGenUtilities.logFailure(driver,"Search By Location label is not present in HomePage");
           NextGenUtilities.logFailure(driver,StepDescription, FailMessage);
           exception.printStackTrace();
    
    }
    return false;
}


public void CloseDriver(WebDriver driver){
	driver.close();
}
public static Properties loadPropertyFile(String fileName) throws IOException{
	FileInputStream fis = new FileInputStream
("C:\\Automation_Suite\\Core_Reg_Suite\\GenAsys\\src\\Data_Repository\\"+fileName+".properties");
	Properties pObj = new Properties();
	pObj.load(fis);
	return pObj;
}
	
public void test() throws InterruptedException, IOException {
	
	//Write file path to sendKeys.txt file
	BufferedWriter out = null;
	try  
	{
	    FileWriter fstream = new FileWriter("sendKeys.txt", false); //true tells to append data.
	    out = new BufferedWriter(fstream);
	//enter the text to be sent to system through VBS file
	    out.write("C:\\Users\\Kodagantime\\Downloads\\V2.0_V2016_ASTTBC_2.3 (ASTTBC CGL).xlsx");
	}
	catch (IOException e)
	{
	    System.err.println("Error: " + e.getMessage());
	}
	finally
	{
	    if(out != null) {
	        out.close();
	    }
	}
	

	String script = "C:\\Automation_Suite\\Core_Reg_Suite\\GenAsys\\SendKeys.vbs";
	// search for real path:
	String executable = "C:\\Windows\\System32\\wscript.exe"; 
	String cmdArr [] = {executable, script};
	try {
		Runtime.getRuntime().exec(cmdArr);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


public static void switchControlToLatestWindow(WebDriver driver){
	    Iterator<String> browsers = driver.getWindowHandles().iterator();
	    while(browsers.hasNext()){
	        driver.switchTo().window(browsers.next());
	    }
	    
	}

public void test(String UploadFile) throws InterruptedException, IOException {
	
	//Write file path to sendKeys.txt file
	BufferedWriter out = null;
	try  
	{
	    FileWriter fstream = new FileWriter("sendKeys.txt", false); //true tells to append data.
	    out = new BufferedWriter(fstream);
	//enter the text to be sent to system through VBS file
	    //"C:\\WillisQA1.5\\willis\\data\\docstore\\General.doc"
	    out.write(UploadFile);
	}
	catch (IOException e)
	{
	    System.err.println("Error: " + e.getMessage());
	}
	finally
	{
	    if(out != null) {
	        out.close();
	    }
	}
	
	
	
	
	String script = "C:\\Automation_Suite\\Core_Reg_Suite\\GenAsys\\SendKeys.vbs";
	// search for real path:
	String executable = "C:\\Windows\\System32\\wscript.exe"; 
	String cmdArr [] = {executable, script};
	try {
		Runtime.getRuntime().exec(cmdArr);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}



	public void upload() throws InterruptedException {

		String script = "C:Automation_Suite\\GenAsysQA1\\willis\\Uploads.vbs";
		// search for real path:
		String executable = "C:\\Windows\\System32\\wscript.exe"; 
		String cmdArr [] = {executable, script};
		try {
			Runtime.getRuntime().exec(cmdArr);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public boolean selectDropdown(WebDriver driver,WebElement element,String StepDescription,String PassMessage,String FailMessage,String DropDownVALUE)
	{
		try
		{
			if(isobjDisplayed(element))
			{
				NextGenUtilities.appendPass(StepDescription,PassMessage);
				Select dropdown=new Select(element);
				dropdown.selectByVisibleText(DropDownVALUE);
				return true;
			}
			else
			{
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				((JavascriptExecutor) jse).executeScript("arguments[0].type ='D:\fbbe.jpg';",element);

				NextGenUtilities.logFailure(driver,StepDescription,FailMessage);
				return false;
			}
			
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			if(exception.getMessage().contains("Element is not currently visible")){
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("document.getElementByTagName('job_input_text').value = '"+DropDownVALUE+"';");

			return true;
			}else
			{
				NextGenUtilities.logFailure(driver,StepDescription,FailMessage);
				return false;
			}
		}
		
	}

	public boolean selectDropdownIndex(WebDriver driver,WebElement element,String StepDescription,String PassMessage,String FailMessage,int DropDownValIndex)
	{
		try
		{
			if(isobjDisplayed(element))
			{
				NextGenUtilities.appendPass(StepDescription,PassMessage);
				Select dropdown=new Select(element);
				dropdown.selectByIndex(DropDownValIndex);
				return true;
			}
			else
			{
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				((JavascriptExecutor) jse).executeScript("arguments[0].type ='D:\fbbe.jpg';",element);

				NextGenUtilities.logFailure(driver,StepDescription,FailMessage);
				return false;
			}
			
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			if(exception.getMessage().contains("Element is not currently visible")){
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("document.getElementByTagName('job_input_text').value = '"+DropDownValIndex+"';");

			return true;
			}else
			{
				NextGenUtilities.logFailure(driver,StepDescription,FailMessage);
				return false;
			}
		}
	}
	
	public void writeData(String pathOfFile, String sheetName, int rowNum, int cellNum, String value) throws InvalidFormatException, IOException{
        FileInputStream fis = new FileInputStream("C:\\Automation_Suite\\Core_Reg_Suite\\GenAsys\\data\\docstore\\CWPCAT20FutureSate.xlsx");
        Workbook wb = WorkbookFactory.create(fis);
        wb.getSheet(sheetName).getRow(rowNum).createCell(cellNum).setCellValue(value);
        FileOutputStream fos = new FileOutputStream("C:\\Automation_Suite\\Core_Reg_Suite\\GenAsys\\data\\docstore\\CWPCAT20FutureSate.xlsx"); 
        wb.write(fos);
    } 
	
	

	
	
	
	


	
	
}
