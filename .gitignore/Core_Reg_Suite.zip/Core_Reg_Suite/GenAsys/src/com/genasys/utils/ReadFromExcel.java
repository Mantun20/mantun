package com.genasys.utils;
import java.io.File;
import java.io.IOException;
import java.util.Locale;

import org.apache.log4j.Logger;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;


public class ReadFromExcel {
	static final Logger logger = Logger.getLogger(ReadFromExcel.class);
	
	public Workbook workbook;
	
	public Sheet sheet;
	public ReadFromExcel(String fileName){
		
		File file=new File(fileName);                          
		WorkbookSettings workbookSettings=new WorkbookSettings();  
		workbookSettings.setLocale(new Locale("en","EN"));  
        try{
			workbook=Workbook.getWorkbook(file,workbookSettings);
		}catch (BiffException e) {
			logger.info("read Excel : "+e);
		}catch (IOException e) {
			logger.info("read Excel : "+e);
		}   
         
  	}
	
	public void setSheet(String sheetName){
		sheet = workbook.getSheet(sheetName);
	}
	
	public Cell[] getCell(int col){
		return sheet.getColumn(col);
	}
	
	public String getCellValue(String cellAddress){
		return sheet.getCell(cellAddress).getContents().trim();
	}
	
	public void close(){
		try{
			workbook.close();
		}catch(Exception e){
			logger.info("read Excel : "+e);
		}
	}
}
