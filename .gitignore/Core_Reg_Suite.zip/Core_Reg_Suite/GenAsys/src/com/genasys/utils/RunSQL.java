package com.genasys.utils;

import java.io.FileInputStream;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class RunSQL {
	/**
	 * @param args
	 */

	public void dbRunQuery(String Query)
    {
        try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Properties DBproperty = new Properties();
            FileInputStream in = new FileInputStream("src/Data_repository/SQLDB.properties");
            DBproperty.load(in);
           
            //GBIPS-I-DB540D
            String url = "jdbc:sqlserver://"+DBproperty.getProperty("DB_Server")+";databaseName="+DBproperty.getProperty("DB_Name")+";integratedSecurity=true;";
            Connection con = DriverManager.getConnection(url);
            Statement s1 = con.createStatement();
            s1.executeQuery(Query);
            con.close();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
}
	
    public String detSingleResult(String Query)
 {
     try
     {
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
         Properties DBproperty = new Properties();
         FileInputStream in = new FileInputStream("src/Data_repository/SQLDB.properties");
         DBproperty.load(in);
         System.out.println("inside detSingleResult");
         //GBIPS-I-DB540D
         String url = "jdbc:sqlserver://"+DBproperty.getProperty("DB_Server")+";databaseName="+DBproperty.getProperty("DB_Name")+";integratedSecurity=true;";
         Connection con = DriverManager.getConnection(url);
         Statement s1 = con.createStatement();
         ResultSet rs = s1.executeQuery(Query);
         rs.next();
         String result = rs.getString("CarrierID");
         System.out.println("hi " + result);
         con.close();
         return result;
     } catch (Exception e)
     {
         e.printStackTrace();
         return "";
     }
}

	
	public void dbGetResultSetBack(String Query)
    {
        try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println();
            Properties DBproperty = new Properties();
            System.out.println(DBproperty.getProperty("SQLDB.DB_Name"));
            //GBIPS-I-DB540D
            //String url = "jdbc:microsoft:sqlserver://localhost:1433"+";databaseName=GPP_QA";
            //String url = "jdbc:microsoft:sqlserver:GBIPS-I-DB540D"+";databaseName=GPP_QA";
            String url = "jdbc:sqlserver://GBIPS-I-DB540D"+";databaseName=GPP_QA;integratedSecurity=true;";
            Connection con = DriverManager.getConnection(url);
            Statement s1 = con.createStatement();
            ResultSet rs = s1.executeQuery("select * from Placement where WorkerID = 5045");
            String[] result = new String[2];
            rs.next();
            System.out.println(rs.getString(10));
           // System.out.println(rs.getString(1));
            //System.out.println(result[1]);
 /*          if(rs!=null){
                while (rs.next()){
                    for(int i = 1; i <result.length ;i++)
                    {
                        for(int j = 1; j <rs.findColumn("PlacementName");j++)
                        {
                            result[j]=rs.getString(i);
                        System.out.println(result[j]);
                    }
                    }
                }
            }
*/           
 /*          if(rs!=null){
               while (rs.next()){
                   for(int i = 1; i <result.length ;i++)
                   {
                       for(int j = 1; j <rs.findColumn("PlacementName");j++)
                       {
                    	   rs.next();
                           result[j]=rs.getString(i);
                       System.out.println(result[j]);
                   }
                   }
               }
           }
 */          
            //String result = new result[20];

        } catch (Exception e)
        {
            e.printStackTrace();
        }
}

}
