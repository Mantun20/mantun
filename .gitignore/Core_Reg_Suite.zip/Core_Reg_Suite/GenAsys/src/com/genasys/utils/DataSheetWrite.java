package com.genasys.utils;


import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Color;
import org.apache.poi.hssf.util.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset; 
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartUtilities; 
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;

import com.genasys.webdriver.WillisWebdriver;

import java.awt.Font;
import java.awt.Paint;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import jxl.biff.FontRecord;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.Orientation;
import jxl.format.Pattern;
import jxl.format.VerticalAlignment;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;
import jxl.write.Formula;
import jxl.write.Label;
import jxl.write.NumberFormat;
import jxl.write.WritableCell;
import jxl.write.WritableCellFeatures;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableHyperlink;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;


public class DataSheetWrite {
	static final Logger logger = Logger.getLogger(DataSheetRead.class);
	
	public Workbook workbook;
	
	public Sheet sheet;
	
	public DataSheetWrite(){
        try{
        Properties PCproperty = new Properties();
        FileInputStream in;

		in = new FileInputStream("src/Data_repository/PC_Path.properties");   
        PCproperty.load(in);
        String DatafileName = PCproperty.getProperty("pc_sheet_path");
        in.close();
       
		File file=new File(DatafileName);                          
		WorkbookSettings workbookSettings=new WorkbookSettings();  
		workbookSettings.setLocale(new Locale("en","EN"));  
			workbook=Workbook.getWorkbook(file,workbookSettings);
        }catch (Exception e){
        	
        }
        
  	}
	
	public void writeCellString(String sheetName, String RowName, String ColumnName, String CellValue){
		try{
		System.out.println("T1");
		
		Properties PCproperty = new Properties();
        FileInputStream in = new FileInputStream("src/Data_repository/PC_Path.properties");        
        PCproperty.load(in);
        String DatafileName = PCproperty.getProperty("pc_sheet_path");
        in.close();
        
		
		System.out.println(workbook.getNumberOfSheets());
		//sheet = workbook.getSheet(1);
		sheet = workbook.getSheet(sheetName);
		System.out.println(sheet.getName());
		int row = 0, column =0;
		//****Get Row Number
		System.out.println("T1");
		for(int i=0; i< sheet.getRows(); i++)
		{
			if(sheet.getCell(0, i).getContents().equals(RowName)){
				row = i;
				break;
			}
		}
		//System.out.println("XStep3 " + row);
		
		System.out.println("row: " + row);
		//****Get Column Number
		for(int i=0; i< sheet.getColumns(); i++)
		{
			if(sheet.getCell(i, 0).getContents().equals(ColumnName)){
				column = i;
			}
		}
		System.out.println("column: " + column);
		
		//Write response text lines to excel
		String inputFileName  = DatafileName;
	    FileInputStream hssffile = new FileInputStream(new File(inputFileName));
	    HSSFWorkbook Hssfworkbook = new HSSFWorkbook(hssffile);	    
	    HSSFSheet Hssfsheet = Hssfworkbook.getSheet(sheetName);
	    
	    System.out.println("test");
	    
	    
	    Iterator<Row> rowIterator = Hssfsheet.iterator();
	    Row Wrow = null;
	    Cell cell = null;
	    Iterator<Cell> cellIterator;
	    
	    System.out.println("test");
	    
	    int i = 0;
	    while(i <= row) {
	    Wrow = rowIterator.next();
	    i++;
	    }
	    
	    i = 0;
	    
	    cellIterator = Wrow.cellIterator();
	    System.out.println("test");
	    while(i < column) {
	    	System.out.println(i + " i");
	    	System.out.println(cell.getStringCellValue());
	        cell = cellIterator.next();
	        //switch(cell.getCellType()) {
	        //case Cell.CELL_TYPE_STRING:
	        //      ar.add(cell.getStringCellValue());
	        //    break;   
	        //case Cell.CELL_TYPE_BLANK:
	        //break;
	        i++;
	        }
	    
	    
	    System.out.println("test");
	    System.out.println("Cell Column: " + cell.getColumnIndex());
	    //cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("hi");
	    
	    hssffile.close();
	    //Hssfworkbook.close();
		//return sheet.getCell(column, row).getContents();
		
		}catch(Exception e){
			logger.info("read Excel : "+e);
			workbook.close();
		}
	}
	
}
