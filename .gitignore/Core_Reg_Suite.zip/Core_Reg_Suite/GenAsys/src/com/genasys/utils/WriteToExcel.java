	package com.genasys.utils;
	
	
	import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Color;
import org.apache.poi.hssf.util.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset; 
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartUtilities; 
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;

import com.genasys.webdriver.WillisWebdriver;

import java.awt.Font;
import java.awt.Paint;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import jxl.biff.FontRecord;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.Orientation;
import jxl.format.Pattern;
import jxl.format.VerticalAlignment;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Formula;
import jxl.write.Label;
import jxl.write.NumberFormat;
import jxl.write.WritableCell;
import jxl.write.WritableCellFeatures;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableHyperlink;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
	
	public class WriteToExcel {
		static final Logger logger = Logger.getLogger(WriteToExcel.class);
		private File file;
		private WorkbookSettings ws;
		private WritableWorkbook workbook;
		public ArrayList<String> ar = new ArrayList<String>();
		public ArrayList<String> Header = new ArrayList<String>();
		public ArrayList<String> HeaderLabel = new ArrayList<String>(); 
		public WritableSheet sheet,metricsSheet;
		WritableCellFormat cellFormat,cellbold,cellBorder_metricsSheet;
		String detailedReport = "Detailed Report";
		String report = "Suite Summary";
		public String chartFileName;
		private WritableCellFormat font,font1;
		public int Passed = 0;
		public int Failed = 0;
		public static int durationColumn;
		public int browserNameColumn;
		
		public WriteToExcel(String fileName){
			file=new File(fileName); 
			chartFileName=fileName;
	        ws=new WorkbookSettings();  
	        ws.setLocale(new Locale("en","EN"));  
	        try{
	        	workbook=Workbook.createWorkbook(file, ws);
	        	metricsSheet = workbook.createSheet(report, 0);
				sheet = workbook.createSheet(detailedReport, 1);
	        }catch(Exception e){
				logger.info("write Excel : "+e);
			}   
	  	}
		
		public static int getdurationColumn(){
			return durationColumn;
		}

		public void readheader(){
			
			try {
				String inputFileName  = WillisWebdriver.getInputDomainPath();
			    FileInputStream file = new FileInputStream(new File(inputFileName));
			    HSSFWorkbook workbook = new HSSFWorkbook(file);
			    HSSFSheet sheet = workbook.getSheetAt(3);
			    Iterator<Row> rowIterator = sheet.iterator();
			    while(rowIterator.hasNext()) {
			    Row row = rowIterator.next();
			        Iterator<Cell> cellIterator = row.cellIterator();
			        while(cellIterator.hasNext()) {
			            Cell cell = cellIterator.next();
			            switch(cell.getCellType()) {
			            case Cell.CELL_TYPE_STRING:
			                    ar.add(cell.getStringCellValue());
			                    break;   
			            case Cell.CELL_TYPE_BLANK:
			            break;
			            }
			        }
			        System.out.println("");
			    }
			    file.close();
			   
			    Header.add("Test Scenario");
			    Header.add("Status");
			    Header.add("Execution Summary");
			    Header.add("Info Error/Warning Message");
			    Header.add("Duration (HMS.ms)");
			    //Header.add("Remarks");
			    
			}catch(Exception e){
				
			}
			
		}
		public void header(){
			try {
				
			    String[] HeaderLabel = new String[]{"HomePage","","","L2 page - Location Search Results","","","L2 page - Category Search Results","","","Job Location Subcription Confirmation","","","Job Category Subcription Confirmation","","","Search Without Keyword","","","Search With Keyword","","","L3 Verification with E-Mail Notification","",""};
			    WritableFont font10pt = new WritableFont(WritableFont.TAHOMA,10);
			    WritableFont fontboldpt = new WritableFont(WritableFont.TAHOMA,10,WritableFont.BOLD);
			    font1 = new WritableCellFormat(fontboldpt);
			    font = new WritableCellFormat(font10pt);
			    cellFormat = new WritableCellFormat(font);
			    cellFormat.setAlignment(Alignment.CENTRE);
			    cellFormat.setOrientation(Orientation.HORIZONTAL);
			    cellFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
			    cellFormat.setBorder(Border.ALL, BorderLineStyle.THIN,Colour.BLACK);
			    cellFormat.setShrinkToFit(true);
			    cellFormat.setWrap(true);
			    cellFormat.setBackground(Colour.CORAL);
			    
			    cellbold = new WritableCellFormat(font1);
			    cellbold.setAlignment(Alignment.CENTRE);
			    cellbold.setOrientation(Orientation.HORIZONTAL);
			    cellbold.setVerticalAlignment(VerticalAlignment.CENTRE);
			    cellbold.setBorder(Border.ALL, BorderLineStyle.THIN,Colour.BLACK);
			    cellbold.setShrinkToFit(true);
			    cellbold.setWrap(true);
			    cellbold.setBackground(Colour.AQUA);
			    
			    System.out.println(Header.size());
			
			    for(int j=0;j<Header.size();j++){
				    Label label;
				    label = new Label(j,0,Header.get(j), cellFormat);
				    sheet.addCell(label);
			    }
			    
			    for(int i=0;i<ar.size();i++){
				    Label label;
				  
				    label = new Label(0,i+1,ar.get(i), cellbold);
				  
				    sheet.addCell(label);
			    }
			
		    }catch(Exception e){
				logger.info("write Excel : "+e);
			}
		}
		
		public void generateReportSheet(String suiteTime,String Browser,String Environment,String ip){
			//Report Sheet 
			try{
				WritableFont writableFont = new WritableFont(WritableFont.TAHOMA, 10);			
				int heightInPoints = 26*20;
				WritableFont writablelabel = new WritableFont(WritableFont.TAHOMA, 10,WritableFont.BOLD);
				WritableCellFormat writableCellFormat = new WritableCellFormat(writableFont);
				WritableCellFormat datafont_Percentage = new WritableCellFormat(writableFont,new NumberFormat("00.00%"));			
			    writableCellFormat.setAlignment(Alignment.LEFT);	    
			    WritableCellFormat labelfont = new WritableCellFormat(writablelabel);
			    WritableCellFormat datafont = new WritableCellFormat(writableFont);
			    WritableCellFormat header = new WritableCellFormat(writablelabel);
			    header.setAlignment(Alignment.CENTRE);
			    header.setBorder(Border.ALL, BorderLineStyle.THICK,Colour.BLACK);
			    header.setBackground(Colour.GREY_25_PERCENT);
			    labelfont.setAlignment(Alignment.LEFT);
			    labelfont.setShrinkToFit(false);
			    labelfont.setBackground(Colour.AQUA);
			    labelfont.setBorder(Border.ALL, BorderLineStyle.THIN,Colour.BLACK);
			    datafont.setAlignment(Alignment.CENTRE);
			    datafont.setShrinkToFit(false);
			    datafont.setBackground(Colour.ICE_BLUE);
			    datafont.setBorder(Border.ALL, BorderLineStyle.THIN,Colour.BLACK);
			    datafont_Percentage.setAlignment(Alignment.CENTRE);
			    datafont_Percentage.setShrinkToFit(false);
			    datafont_Percentage.setBackground(Colour.ICE_BLUE);
			    datafont_Percentage.setBorder(Border.ALL, BorderLineStyle.THIN,Colour.BLACK);
			    metricsSheet.addCell(new Label(0,6,"", labelfont));
			    metricsSheet.addCell(new Label(0,7,"", labelfont));
			    metricsSheet.addCell(new Label(0,1,"GenASys Automation Regression Test Report", header));
			    metricsSheet.mergeCells(0,1 ,1, 1);
				String formulaTotal = "B5+B6";  
				metricsSheet.addCell(new Label(0,2,"GenASys Test Client", labelfont));
				metricsSheet.addCell(new Label(1,2,WillisWebdriver.clientName, datafont));
				metricsSheet.addCell(new Label(0,3,"Total Tests", labelfont));
				metricsSheet.addCell(new Formula(1,3,formulaTotal,datafont));
				String formulaPassed = "COUNTIF('"+detailedReport+"'!B2:Y500,\"Passed\")";  
				metricsSheet.addCell(new Label(0,4,"Tests Passed", labelfont));
				metricsSheet.addCell(new Formula(1,4,formulaPassed,datafont));
				String formulaFailed = "COUNTIF('"+detailedReport+"'!B2:Y500,\"Failed\")";
				metricsSheet.addCell(new Label(0,5,"Tests Failed", labelfont));
				metricsSheet.addCell(new Formula(1,5,formulaFailed,datafont));
				String formulaPassPercentage = "(B5/B4)";
				metricsSheet.addCell(new Label(0,6,"Pass Percentage", labelfont));
				metricsSheet.addCell(new Formula(1,6,formulaPassPercentage,datafont_Percentage));
				String formulaFailPercentage = "(B6/B4)";
				metricsSheet.addCell(new Label(0,7,"Fail Percentage", labelfont));
				metricsSheet.addCell(new Formula(1,7,formulaFailPercentage,datafont_Percentage));
				metricsSheet.addCell(new Label(0,8,"Environment", labelfont));
				metricsSheet.addCell(new Label(1,8,Environment,datafont));
				String formulaSuiteTime = "CONCATENATE(TEXT(INT("+suiteTime+"/1000)/86400,\"hh:mm:ss\"),\".\","+suiteTime+"-(INT("+suiteTime+"/1000)*1000))";
				metricsSheet.addCell(new Label(0,9,"Suite Exec Time", labelfont));
				metricsSheet.addCell(new Formula(1,9,formulaSuiteTime,datafont));
				metricsSheet.setColumnView(0,20);
				metricsSheet.setColumnView(1,25);  

		}catch(Exception e){
				System.out.println("Excel Formula Error");
			}
		}
		
		private static WritableCellFormat getCellFormat(Colour colour, Pattern pattern) throws WriteException {
			    WritableFont cellFont = new WritableFont(WritableFont.TAHOMA, 10);
			    WritableCellFormat cellFormat = new WritableCellFormat(cellFont);
			    cellFormat.setBackground(colour, pattern);
			    cellFormat.setAlignment(Alignment.CENTRE);
			    cellFormat.setOrientation(Orientation.HORIZONTAL);
			    cellFormat.setBorder(Border.ALL, BorderLineStyle.THICK,Colour.BLACK);
			    cellFormat.setShrinkToFit(true);
			    cellFormat.setWrap(true);
			    return cellFormat;
		}

	public void pieChartReport() throws IOException{
      FileInputStream chart_file_input = new FileInputStream(new File(chartFileName));
      HSSFWorkbook my_workbook = new HSSFWorkbook(chart_file_input);
      HSSFSheet my_sheet = my_workbook.getSheetAt(0);
      DefaultPieDataset my_pie_chart_data = new DefaultPieDataset();
    Iterator<Row> rowIterator = my_sheet.iterator(); 
    String chart_label="SEOSite";
    try{
        for(int i=1;i<=sheet.getRows();i++){
         for(int j=1;j<=sheet.getColumns();j++){
        	 System.out.println(sheet.getCell(j,i).getContents());
        if(sheet.getCell(j,i).getContents().equals("Passed"))
        {
                   Passed++;
                 }
            else if(sheet.getCell(j,i).getContents().equals("Failed")){
                  Failed++;
            }
         }
        }
       // Passed++;
	}catch(Exception e){
    	System.out.println(e);
    }
    	
      my_pie_chart_data.setValue("No of Tests Failed",Failed);
      my_pie_chart_data.setValue("No of Tests Passed",Passed);
      
      JFreeChart myPieChart=ChartFactory.createPieChart("GenASys Automation Regeression Test Execution Piechart Report",my_pie_chart_data,true,true,false);
      int width=400;   
      int height=250;
      float quality=1;
      ByteArrayOutputStream chart_out = new ByteArrayOutputStream();          
      ChartUtilities.writeChartAsJPEG(chart_out,quality,myPieChart,width,height);
      InputStream feed_chart_to_excel=new ByteArrayInputStream(chart_out.toByteArray());
      byte[] bytes = IOUtils.toByteArray(feed_chart_to_excel);
      int my_picture_id = my_workbook.addPicture(bytes, org.apache.poi.ss.usermodel.Workbook.PICTURE_TYPE_JPEG);
      feed_chart_to_excel.close();
      chart_out.close();
      HSSFPatriarch drawing = my_sheet.createDrawingPatriarch();
      ClientAnchor my_anchor = new HSSFClientAnchor();
      my_anchor.setCol1(3);
      my_anchor.setRow1(2);
      HSSFPicture  my_picture = drawing.createPicture(my_anchor, my_picture_id);
      my_picture.resize();
      chart_file_input.close();               
      FileOutputStream out = new FileOutputStream(new File(chartFileName));
      my_workbook.write(out);
      out.close();              
		}

		public void add(int column, int row, String successCriteria, String failures,String clientHTMLFileLocation,String clientName,String execTime, String BrowserName){
			try{
				
				durationColumn = 4;
				browserNameColumn =5;
	        	sheet.addCell(new Label(durationColumn, row, execTime,font));  
	        	Label label;
				if(successCriteria.equals("Failed")){
					label = new Label(column, row, successCriteria, getCellFormat(Colour.RED, Pattern.GRAY_50));
				}
				else if (successCriteria.equals("Passed"))
					label = new Label(column, row, successCriteria, getCellFormat(Colour.GREEN, Pattern.GRAY_50));
				else
					label = new Label(column, row, successCriteria,font);
				sheet.addCell(label);
				WritableCellFeatures celllComment = new WritableCellFeatures(); 
				if(failures.length()>5000){
					celllComment.setComment("The comments are large you can view in the error/warning section or in the HTML file by clicking the sanpshot",5,7);
				}
				else{
				celllComment.setComment(failures,5,7);
				}
				if(NextGenUtilities.testFailed.contains("Fail"))
				label.setCellFeatures(celllComment);
			    WritableHyperlink hyperLinktoClientHTML =new WritableHyperlink(++column,row, new File(clientHTMLFileLocation,clientName.replaceAll("/", ".")+".html"));
		        sheet.addHyperlink(hyperLinktoClientHTML);
		        Label lblhyperlink=new Label(column,row,"Snapshot");   
			    sheet.addCell(lblhyperlink);
			    if(successCriteria.equals("Failed")){
			    sheet.addCell(new Label(++column, row,failures));}
		    }catch(Exception e){
		    	e.printStackTrace();
		    	System.out.println("");
		    	System.out.println("Exception in add cell");
				logger.info("write Excel : "+e);
			}
		}
		
		public void close(){
			try {
				workbook.write();
				workbook.close();
			}catch (WriteException e) {
				logger.info("write Excel : "+e);
			}catch (IOException e) {
				logger.info("write Excel : "+e);
			}
		}
		
	
	}