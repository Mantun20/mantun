package com.genasys.utils;

public class DomainList {
	private String domainName;
	private String status;
	private String location;
	private String clientmailid;
	private String listitem;
	private String tempurl;
	private String browsername;
	private String classname,product,businesstype,line,clientname,placementstatus,username,password;
	
	
	public String getClientName(){
		return clientname;  
	}
	public void setClientName(String clientname){  
		this.clientname = clientname;
	}
	public String getUserName(){
		return username;  
	}
	public void setUserName(String username){  
		this.username = username;
	}	
	public String getPassWord(){
			return password;  
		}
	public void setPassWord(String password){  
			this.password = password;
	}
	
	public String getPlacementStatus(){
		return placementstatus;
	}
	public void setPlacementStatus(String placementstatus){
		this.placementstatus = placementstatus;
	}
	    
	public String getDomainName(){
		return domainName;
	}
	public void setDomainName(String domainName){
		this.domainName = domainName;
	}
	public String getStatus(){
		return status;
	}
	
	public void setStatus(String status){
		this.status = status;
	}
	
	public void setLocation1(String location){
		this.location = location;
	}
	
	public String getLocation(){
		return location;
	}
	
	public void setClientID(String clientmailid){
		 this.clientmailid = clientmailid;
	}
	
	public void setBrowserName(String browsername){
		 this.browsername = browsername;
	}
	
	public String getClientID(){
		return clientmailid;
	}
	
	public String getBrowserName(){
		return browsername;
	}
	public void setlistitem(String listitem){
		 this.listitem = listitem;
	}
	
	public String getlistitem(){
		return listitem;
	}
	
	public void settempurl(String tempurl){
		 this.tempurl = tempurl;
	}
	
	public String gettempurl(){
		return tempurl;
	}

public String getClassName(){
		return classname;
}
public void setClassName(String classname){
		this.classname = classname;
	}
public String getLine(){
		return line;
}
public void setLine(String line){
		this.line = line;
}
public String getProduct(){
	return product;
}
public void setProduct(String product){
	this.product = product;
}
public String getBusinessType(){
	return businesstype;
}
public void setBusinessType(String businesstype){
	this.businesstype = businesstype;

   }
}




