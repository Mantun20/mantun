package com.genasys.utils;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.genasys.webdriver.WillisWebdriver;

public class NextGenUtilities {
	public static int failStep;
	public static String excelLog, htmlLog;
	public static String clientHTMLFileLocation;
	public static String testFailed;
	
	public static boolean isValidEmailAddress(final String email) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}
	
	public static void logFailure(WebDriver driver, String stepDescription, String ActualResult){
		testFailed = "Failed";
		excelLog=excelLog + (++failStep) + " . " + stepDescription+"\n";
		//NextGenUtilities.appendFail(stepDescription + "<br>Landed Page Title is : " + driver.getCurrentUrl() ,takeScreenshot(driver));
		//NextGenUtilities.appendFail(stepDescription + "<br>Landed Page Title is : " + driver.getCurrentUrl() ,takeScreenshot(driver));
		NextGenUtilities.appendFail(stepDescription,ActualResult,takeScreenshot(driver));
	}
	
	public static void writeExcel(WriteToExcel writeExcel,int row,int column,String clientName, String execTime, String BrowserName){
		try{
			//writeExcel.add(0, row,clientName);
			writeExcel.add(column, row,testFailed,excelLog,clientHTMLFileLocation,clientName,execTime,BrowserName);
		}catch(Exception e){
			//logger.info(clientName+"-> WriteToExcel : "+e);
		}finally{
			testFailed = "Passed";
			excelLog="Failed Steps :\n";  
		}
	}   
	
	public static String takeScreenshot(WebDriver driver) {
		String screenShotName = new SimpleDateFormat("dd-MMM-yy-HH-mm-ss").format(Calendar.getInstance().getTime());
		
		File screenShotFolder = WillisWebdriver.getScreenShotFolder();
		if (driver instanceof TakesScreenshot) {
			File tempFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			try{
				FileUtils.copyFile(tempFile, new File(screenShotFolder+"/" + screenShotName + ".jpg"));
			}catch (IOException e) {
				// TODO handle exception
			}
		}
		return screenShotFolder + "/" + screenShotName + ".jpg";
	}
	
	public static void writeToLog(String clientName){
		//htmlLog=htmlLog+"";
		htmlLog = htmlLog +"</table></body></html>";
		File clientLogHTMLFolder = WillisWebdriver.getClientLogHTMLFolder();
		
		try{
	        clientHTMLFileLocation = clientLogHTMLFolder.getName();
	        String clientHTMLFile = clientLogHTMLFolder + "//"+clientName.replaceAll("/", ".")+".html";
	        File file = new File(clientHTMLFile);
	        FileUtils.writeStringToFile(file, htmlLog, true);
	     }catch(IOException e){
	    	System.out.println("File creation error : " + e.getMessage());
		}finally{
			if(NextGenUtilities.testFailed.contains("Fail")){
				Reporter.log("Failed for client : " + clientName);
				Assert.fail("Some of test steps are failed - please look into html log");
			}
		}
		
	}
	
	public static String parseString(String string){
		System.out.println("Location String received: " + string);
		if(string.contains(",")){
			String[] stringArray = string.split(",");
			string = stringArray[0].trim();
		}
		
		if(string.contains(" "))
			string = string.replaceAll(" ", "-");
		
		if(string.contains("\\"))
			string = string.replaceAll("\\", "_");
		
		return string.trim();
	}

	
	public static void appendClientHeader(String clientName){
		htmlLog = "<html><body><font color=gold><h1>" + "</font></h1>";//<br>";
	}
	   
	public static void appendTestCaseHeader(String testCaseHeader){
		htmlLog = htmlLog + "<font color=blue>"+testCaseHeader+"</font><table border=\"2\" bordercolor=\"#000000\"><tr bgcolor = gray><th>Step#</th><th width = 500>Description</th><th width = 500>Actual Result</th><th> Step Status</th><th> Screen Shot</th></tr>";
	}
	public static void appendTestCaseSubTitle(String testCaseHeaderSubTitle){
		htmlLog = htmlLog + "<font color=maroon>"+testCaseHeaderSubTitle+"</font>";
	}
	
//	
//	public static void appendPass(String Step , String ExpectedResult , String Status){
//		//testFailed = "Passed";
//		htmlLog = htmlLog + "<br><font color=green><tr><td>" + failStep + ". " + Step +  ExpectedResult + Status+  "</font>";
//
//	}

	public static void appendPass(String stepDescription, String ActualResult){
		//testFailed = "Passed";
		failStep++;
		//htmlLog = htmlLog + "<br><font color=green>" + failStep + ". "  + stepDescription +   "</font>";
		htmlLog = htmlLog + "<tr><td>" +  failStep  + "</td><td  width = 400> " + stepDescription +  "</td><td><font color = green>" + ActualResult +  "</td><td><font color = green> Pass </td></tr></font>"; 
		
	} 
	
	public static void appendFail(String stepDescription,String ActualResult, String screenShot){
		htmlLog = htmlLog + "<tr><td>" + failStep + "</td><td width = 400>" +stepDescription + "- </td><td><font color = red>" + ActualResult +  "</td><td><font color = red> Fail </td><td><a href=" + screenShot + "> Click Here For Screen Shot </a></td></tr></font>";
	
	}
	
	public static void appendWarning(String stepDescription){
		htmlLog = htmlLog + "<font color=orange>" + failStep + ". " +stepDescription + "</font>";
	}
}
