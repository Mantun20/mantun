package com.genasys.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jxl.Cell;

import org.testng.ITestContext;
import org.testng.annotations.DataProvider;



public class DomainDataProvider {
	private static List<DomainList> domainList;
	public static String productionURL;
	private static boolean staging;
	
    @DataProvider(name="DomainListData")
    public static Iterator<Object[]> fileDomainDataProvider(ITestContext context) {
    	
    	//Get the input file path from the ITestContext
    	String domainsFilePath = context.getCurrentXmlTest().getParameter("domainsFilePath");
    	String environmentSheetName = context.getCurrentXmlTest().getParameter("environmentSheetName");
    	
    	String productionSheetName = context.getCurrentXmlTest().getParameter("domainsSheetName");
    	String stagingSheetName = context.getCurrentXmlTest().getParameter("stagingSheetName");
    	
    	ReadFromExcel readFromExcel=new ReadFromExcel(domainsFilePath);
    	
    	staging  = setEnvironmentDetails(readFromExcel,environmentSheetName);
    	
    	if(staging){
    		readFromExcel.setSheet(stagingSheetName);
    		productionURL = readFromExcel.getCellValue("E2");
    	}else{
    		readFromExcel.setSheet(productionSheetName);	
    	}

        //Get a list of String file content (line items) from the test file.
       // List<DomainList> domainList = getFileContentList(readFromExcel);
		domainList = getFileContentList(readFromExcel);
 
        //We will be returning an iterator of Object arrays so create that first.
        List<Object[]> domainListReturned = new ArrayList<Object[]>();
 
        //Populate our List of Object arrays with the file content.
        for (DomainList domainListItem : domainList)
        {
        	domainListReturned.add(new Object[] { domainListItem } );
        }
        //return the iterator - testng will initialize the test class and calls the 
        //test method with each of the content of this iterator.
        System.out.println("red file");
        return domainListReturned.iterator();
 
    }

    public static boolean setEnvironmentDetails(ReadFromExcel readFromExcel,String sheetName){
    	String selection=null;
    	try{
    		readFromExcel.setSheet(sheetName);
    		selection =  readFromExcel.getCellValue("B4");
    	}catch(Exception e){
    		readFromExcel.close();	
    	}
    	
    	if(selection.contains("Staging"))
    		return true;
    	else
    		return false;
     }
    
	public static List<DomainList> getFileContentList(ReadFromExcel readFromExcel){
		List<DomainList> domainList=new ArrayList<DomainList>();
		DomainList dl;
		
		try{
			Cell[] domain=readFromExcel.getCell(0);
			Cell[] status=readFromExcel.getCell(1);
			Cell[] clientMailID = readFromExcel.getCell(2);
			Cell[] browsername = readFromExcel.getCell(3);
			Cell[] classname = readFromExcel.getCell(4);
			Cell[] product = readFromExcel.getCell(5);
			Cell[] businesstype = readFromExcel.getCell(6);
			Cell[] line = readFromExcel.getCell(7);
			Cell[] clientname = readFromExcel.getCell(8);
			Cell[] placementstatus = readFromExcel.getCell(9);
			Cell[] username = readFromExcel.getCell(10);
			Cell[] password = readFromExcel.getCell(11);
			
			System.out.println("Domains Length : " + domain.length);
			for(int i=1;i<domain.length;i++){
				dl=new DomainList();  
		    
				dl.setDomainName(domain[i].getContents().trim());
				dl.setStatus(status[i].getContents().trim());
				dl.setClientID(clientMailID[i].getContents().trim());
				dl.setBrowserName(browsername[i].getContents().trim());
				dl.setClassName(classname[i].getContents().trim());
				dl.setProduct(product[i].getContents().trim());
				dl.setBusinessType(businesstype[i].getContents().trim());
				dl.setLine(line[i].getContents().trim());
				dl.setClientName(clientname[i].getContents().trim());
				dl.setPlacementStatus(placementstatus[i].getContents().trim());
				dl.setUserName(username[i].getContents().trim());
				dl.setPassWord(password[i].getContents().trim());
				if(status[i].getContents().trim().equals("true"))
					domainList.add(dl);
			}
			
		}catch(Exception e){
			readFromExcel.close();
		}
//		finally{
//			readFromExcel.close();
//		}
		return domainList;
	}
	
	public static int getDomainCount(){
		return domainList.size();
	}
		public static boolean isStaging(){
		return staging;
	}
	
	public static String getProductionURL(){
		return productionURL;
	}
}
