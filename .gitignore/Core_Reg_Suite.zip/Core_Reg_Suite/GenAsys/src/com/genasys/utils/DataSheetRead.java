package com.genasys.utils;
import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.Properties;

import org.apache.log4j.Logger;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;


public class DataSheetRead {
	static final Logger logger = Logger.getLogger(DataSheetRead.class);
	
	public Workbook workbook;
	
	public Sheet sheet;
	public DataSheetRead(String fileName){
		
		File file=new File(fileName);                          
		WorkbookSettings workbookSettings=new WorkbookSettings();  
		workbookSettings.setLocale(new Locale("en","EN"));  
        try{
			workbook=Workbook.getWorkbook(file,workbookSettings);
		}catch (BiffException e) {
			logger.info("read Excel : "+e);
		}catch (IOException e) {
			logger.info("read Excel : "+e);
		}   
         
  	}
	
	public String readCellString(String sheetName, String RowName, String ColumnName){
		try{
			
		System.out.println("Read started");
		sheet = workbook.getSheet(sheetName);
		int row = 0, column =0;
		//****Get Row Number
		for(int i=0; i< sheet.getRows(); i++)
		{
			if(sheet.getCell(0, i).getContents().equals(RowName)){
				row = i;
				break;
			}
		}
		System.out.println("XStep3 " + row);
		//****Get Column Number
		for(int i=0; i< sheet.getColumns(); i++)
		{
			if(sheet.getCell(i, 0).getContents().equals(ColumnName)){
				column = i;
				break;
			}
		}
		
		
		return sheet.getCell(column, row).getContents();
		
		}catch(Exception e){
			logger.info("read Excel : "+e);
			workbook.close();
			return "";
		}
	}
	
	
	public void insertlastStringRow(String sheetName, String RowName, String ColumnName){
		try{
		sheet = workbook.getSheet(sheetName);
		int row = 0, column =0;
		workbook.close();
	
		}catch(Exception e){
			logger.info("read Excel : "+e);
			workbook.close();
		}
	}
	
	
	public void setSheet(String sheetName){
		sheet = workbook.getSheet(sheetName);
	}
	
	public Cell[] getCell(int col){
		return sheet.getColumn(col);
	}
	
	public String getCellValue(String cellAddress){
		return sheet.getCell(cellAddress).getContents().trim();
	}
	
	public void close(){
		try{
			workbook.close();
		}catch(Exception e){
			logger.info("read Excel : "+e);
		}
	}
	
}
