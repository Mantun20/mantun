package com.genasys.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Flags;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.AndTerm;
import javax.mail.search.BodyTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.OrTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;

public class AccessGmail {

	private static String jobNote;
	private static Message[] msgs;
	private static SearchTerm st;
	private static Store store;
	private static Folder folder;
	//private static ArrayList<String> strList = new ArrayList<String>();
	private static boolean strList;

	public static void setJobNote(String jobNote) {
		AccessGmail.jobNote = jobNote;
	}

	public static String getJobNote() {
		return jobNote;
	}

	public static boolean emailSearch(String ClientMailId) throws IOException, MessagingException {
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class",
				"javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");

		Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(
								"tmptestwork@gmail.com", "login@123");
					}
				});

		try {
			store = session.getStore("imaps");
			store.connect("smtp.gmail.com","tmptestwork@gmail.com","login@123");
			folder = store.getFolder("INBOX");
			folder.open(Folder.READ_WRITE);
			FlagTerm ft = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
			st =new FromStringTerm(ClientMailId);	
			AndTerm st1 = new AndTerm(ft,st);
			msgs = folder.search(st1);
			System.out.println("Msg count :" + msgs.length);
		if (msgs.length ==1) {
			strList=true;
			Message mail = msgs[0];
			
			
			String line;
			StringBuffer buffer = new StringBuffer();
			StringBuffer buffer1 = new StringBuffer();
			BufferedReader reader;
			try {
				reader = new BufferedReader(new InputStreamReader(
						mail.getInputStream()));
				reader.readLine();
			} catch (Exception e) {
				e.printStackTrace();
			}
		

		}
		else
		{
			strList=false;
		}

		return strList;
		}
		catch (Exception e) {
			e.printStackTrace();
			strList=false;
			return strList;
		}

	}
}
