package com.genasys.scripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.DurationFormatUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.genasys.api.Implementation;
import com.genasys.locators.AllGeneralTabs;
import com.genasys.locators.MTALocators;
import com.genasys.utils.DomainList;
import com.genasys.utils.DataSheetRead;
import com.genasys.utils.NextGenUtilities;
import com.genasys.utils.WriteToExcel;
import com.genasys.webdriver.WillisWebdriver;
import com.genasys.pages.*;



public class TC14_MTAClient_MTA_Refearral_SimpleTax_Validataion extends Implementation
{
	public static MTALocators locators;
	private WebDriver driver;
	private String clientName;
	private int row = 14;
	private int column = 1;
	private Implementation Implementation;
	private WriteToExcel writeExcel;
	private AllGeneralTabs allGeneralTabsObj;
	private Client_MTA clientMTA;
	private long start;  
	String firefoxProfilePath;
	String chrome;
	String InternetExplorer;
	String waitingTime;
	String browsername;  
	String prevBrowserName;
	public int  flag = 0;
	int incr = 1;//Validation from test case 1st to 10th from Milestone 3

	@BeforeClass
	public void setupSelenium() throws UnknownHostException, MalformedURLException {
		waitingTime=WillisWebdriver.getWaitingTime();
		chrome=WillisWebdriver.getchrome();
		firefoxProfilePath=WillisWebdriver.getfirefoxProfilePath();
		InternetExplorer=WillisWebdriver.getInternetExplorer();
	}

	@BeforeMethod
	public void beforeTest(){
		start = Reporter.getCurrentTestResult().getStartMillis();
	}

	@AfterMethod
	public void afterTest(){
		long end = Reporter.getCurrentTestResult().getEndMillis();
		String execTime =DurationFormatUtils.formatDurationHMS((end-start));
		System.out.println("Total Test Execution time - millisec: " + execTime);
		System.out.println("Total Test Execution time - HMS: " + DurationFormatUtils.formatDurationHMS((end-start)));
		writeExcel = WillisWebdriver.getWriteExcel();
		NextGenUtilities.writeExcel(writeExcel,row,column,clientName,execTime,browsername);
	}

	@Test(dataProviderClass=com.genasys.utils.DomainDataProvider.class,dataProvider="DomainListData")
	public void testHomePage(DomainList domainListItem) {
		browsername = domainListItem.getBrowserName();
		clientName= domainListItem.getDomainName();
		WillisWebdriver.clientName=clientName;
		//WillisWebdriver.createWebDriverObject(browsername);
		driver=WillisWebdriver.getDriverObject();
		locators=PageFactory.initElements(driver, MTALocators.class);		
		Implementation = PageFactory.initElements(driver, Implementation.class);			
		allGeneralTabsObj=PageFactory.initElements(driver, AllGeneralTabs.class);
		clientMTA = PageFactory.initElements(driver, Client_MTA.class);
		prevBrowserName=browsername;
		NextGenUtilities.htmlLog = "";
		NextGenUtilities.failStep=0;
		NextGenUtilities.excelLog="";
		NextGenUtilities.appendClientHeader(clientName.toUpperCase());
		NextGenUtilities.appendTestCaseHeader("TC14_MTAClient_MTA_Refearral_SimpleTax_Validataion");

		try
		{

			Properties name = loadPropertyFile("PC_Path");
			String pc_sheet_path =  name.getProperty("pc_sheet_path");
			String pc_sheet_name =  "Product";
			DataSheetRead DataWorkBook = null;
			String StartDate = ""; 
			String SearchDateFrom = "";
			String SearchDateTo = "";
			String Transaction = "";
			String Type = "";

			try{
				DataWorkBook = new DataSheetRead(pc_sheet_path);
				StartDate = DataWorkBook.readCellString(pc_sheet_name, "Product_Creation", "StratDate");
				SearchDateFrom = DataWorkBook.readCellString(pc_sheet_name, "MTA_Client", "SearchDateFrom");
				SearchDateTo = DataWorkBook.readCellString(pc_sheet_name, "MTA_Client", "SearchDateTo");
				Transaction = DataWorkBook.readCellString(pc_sheet_name, "MTA_Client", "Transaction");
				Type = DataWorkBook.readCellString(pc_sheet_name, "MTA_Client", "Type");


			}catch(Exception e){
				e.printStackTrace();
				System.out.println("***********Exception while reading Data sheet*********");
			}finally{
				DataWorkBook.close();
			}

			//Launch the browser as well application
			Implementation.launchClientURL(driver, clientName, browsername);

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

			//Call the MTA Application Keyword 
			clientMTA.keyToLoginApplicationPage();

			//Call the Create Policy For MTA Keyword 
			clientMTA.keyToCreatePolicyForMTAPage();

			//Call the Search Policy Keyword 
			clientMTA.keyToSearchPolicyPage();

			//Call the Create MTA Keyword 
			clientMTA.keyToCreateMTAPage();

			//Call the MTA Referral Action Keyword
			clientMTA.keyToMTAReferralActionPage();

			//Call the Accept MTA Page Keyword
			clientMTA.keyToAcceptMTAPage();

			//*****************Policy Transaction History Screen Validation********************************

			//Click on Transaction History Tab
			Thread.sleep(6000); 
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Transaction_History, "Click on Transaction History Tab in policy view screen", "Able to click on Transaction History Tab button in policy view screen", "Unbale to click on Transaction History Tab button in policy view screen");

			//Select Search Date From
			Implementation.EnterTextFeild(driver, AllGeneralTabs.MTA_Transaction_History_From, "Select Search Date From Transaction History screen", "User able to Select Search Date From Transaction History screen", "Unable to Select Search Date From Transaction History screen",SearchDateFrom);

			//Select Search Date To
			Implementation.EnterTextFeild(driver, AllGeneralTabs.MTA_Transaction_History_To, "Select Search Date To Transaction History screen", "Able to Select Search Date To Transaction History screen", "Unbale to Select Search Date To Transaction History screen",SearchDateTo);

			//Click on Search Button
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Transaction_History_Search, "Click on Search button in Transaction History screen", "Able to click on Search button in Transaction History screen", "Unbale to click on Search button in Transaction History screen");

			//Verify the Transaction History table created
			if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Transaction_History_TableCreated)){
				NextGenUtilities.logFailure(driver, "Verify the Transaction History table created", "Transaction History table created in Transaction History screen");
			}else{

				NextGenUtilities.appendPass("Verify Transaction History table created in Transaction History screen", "Transaction History table is not created in Transaction History screen");
			}

			//Click on Customer Willis in Transaction History
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Transaction_HistoryScreen_CustomerWillis, "Click on Customer Willis", "Able to click on Customer Willis in Transaction History scren", "Unable to click on PCustomer Willis in Transaction History scren");

			//Click on Policies
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Transaction_HistoryScreen_Policies, "Click on Policies Drop Down", "Able to click on Policies drop down in Transaction History scren", "Unable to click on Policies drop down in Transaction History scren");

			//****************Policy Attachment Screen Validation***********************************

			//Click on policy attachment
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_PoliciesAttachment, "Click on Policy Attachment Tab", "Able to click on Policy Attachment Tab", "Unable to click on Policy Attachment Tab");

			//Click on attachment file button 
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_PoliciesAttachment_AttachmentBtn, "Click on Attachment Button", "Able to click on Attachment Button Policy Attachment screen", "Unable to click on Attachment Button Policy Attachment screen");

			//Click on choose file button
			Implementation.test("C:\\Automation_Suite\\BU_Reg_Suite\\GenAsys\\data\\docstore\\CWPCAT20FutureSate.xls"); 
			
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_AttachmentScreen_Choosefile, "Click on choose file button", "Able to click on choose file button", "Unable to click on choose file button");

			//Select the transaction 
			Thread.sleep(5000);
			Select transaction= new Select(AllGeneralTabs.MTA_AttachmentScreen_Transaction);
			transaction.selectByVisibleText(Transaction);

			//Select the type 
			Thread.sleep(5000);
			Select type = new Select(AllGeneralTabs.MTA_AttachmentScreen_Type);
			type.selectByVisibleText(Type);

			//Select Date
			Implementation.EnterTextFeild(driver, AllGeneralTabs.MTA_AttachmentScreen_Date, "Select date", "Able to select date in policy attachment scren", "Unable to select date in policy attachment scren",StartDate);

			//Click on Save button
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_AttachmentScreen_SaveBtn, "Click on save button", "Able to click in save butto in policy attachment scren", "Unable to click in save butto in policy attachment scren");

			//Verify the table creation after uploading the doc
			Thread.sleep(8000); 
			if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_AttachmentScreen_UploadedType)){
				NextGenUtilities.appendPass("Verify the table creation after upload the doc", "User able to see table is created in policy attachment screen after upload the doc");
			}else{
				NextGenUtilities.logFailure(driver,"Verify the table creation after upload the doc", "Table is not created in policy attachment screen after upload the doc");
			}

		} 
		catch(Exception e)
		{
			e.printStackTrace();

		}
		finally{
			NextGenUtilities.writeToLog(clientName);
		}  
	}
}