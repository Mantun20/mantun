package com.genasys.webdriver;

import java.io.File;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import jxl.write.Formula;

import org.apache.commons.lang3.time.DurationFormatUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
//import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.testng.xml.XmlSuite;

import com.genasys.api.Implementation;
import com.genasys.utils.DomainDataProvider;
import com.genasys.utils.DomainList;
import com.genasys.utils.ReadFromExcel;
import com.genasys.utils.WriteToExcel;

public class WillisWebdriver{
	//public static String clientHeader;
	private static String waitingTime,browser,chrome,firefoxProfilePath,InternetExplorer;
	public static String testLogHTMLLocation,testLogHTMLFolderName,testLogScreenShotFolderName,testLogFileName,ip;
	public static File testlogFolder,clientLogHTMLFolder,screenShotFolder;
	public static WriteToExcel writeExcel;
	private static WebDriver driver;
	static String domainsFilePath;
	boolean staging;
	long start;
	String timeStamp;
	static String Env;
	public static String clientName="";
	  
	@BeforeSuite
	public void beforeSuite(ITestContext context) throws UnknownHostException, MalformedURLException{
		start = Reporter.getCurrentTestResult().getStartMillis();
		System.out.println("Test Suite Started....");
    	waitingTime = context.getCurrentXmlTest().getParameter("waitingTime");
    	firefoxProfilePath = context.getCurrentXmlTest().getParameter("firefoxProfilePath");
    	System.out.println(firefoxProfilePath);
    	domainsFilePath = context.getCurrentXmlTest().getParameter("domainsFilePath");
    	String environmentSheetName = context.getCurrentXmlTest().getParameter("environmentSheetName");
    	ReadFromExcel readFromExcel=new ReadFromExcel(domainsFilePath);
    	staging  = setEnvironmentDetails(readFromExcel,environmentSheetName);
    	setBrowserDetails(readFromExcel,environmentSheetName);
    	testLogHTMLLocation = context.getCurrentXmlTest().getParameter("testReportHTMLLogPath");
    	testLogHTMLFolderName = context.getCurrentXmlTest().getParameter("testReportHTMLFolderName");
    	testLogScreenShotFolderName = context.getCurrentXmlTest().getParameter("testReportScreenShotFolderName");
    	InternetExplorer = context.getCurrentXmlTest().getParameter("ieDriver");
    	chrome = context.getCurrentXmlTest().getParameter("chromeDriver");
    	timeStamp = new SimpleDateFormat("dd-MMM-yy-HH-mm").format(Calendar.getInstance().getTime());
		testLogFileName="GenASysSuiteRun"+timeStamp;
		if(staging){
			testLogHTMLLocation = testLogHTMLLocation.concat("//").concat("STAGING").concat("//").concat(testLogFileName);
			
    	}else{
    		testLogHTMLLocation = testLogHTMLLocation.concat("//").concat("PRODUCTION").concat("//").concat(testLogFileName);
    	}	
		
		try{
			testlogFolder = new File(testLogHTMLLocation);
			testlogFolder.mkdir();

			clientLogHTMLFolder = new File(testlogFolder.getAbsolutePath().concat("//").concat(testLogHTMLFolderName));
			clientLogHTMLFolder.mkdir();
						
		    screenShotFolder = new File(clientLogHTMLFolder.getAbsolutePath().concat("//").concat(testLogScreenShotFolderName));
		    screenShotFolder.mkdir();
		    
			writeExcel=new WriteToExcel(testlogFolder.getAbsolutePath().concat("//").concat("GenASysSuiteReport_"+timeStamp+".xls"));
			writeExcel.readheader();
			writeExcel.header();	
		}catch(Exception e){
			Reporter.log("Log Files Error : "+e);
		}finally{

		}
	}
	
	@AfterSuite
	public void afterSuite() throws Exception{
		int row=2;
		String execTime,formula;
		Formula milliSecToHMS;
		long end = Reporter.getCurrentTestResult().getEndMillis();
		String totalTime = DurationFormatUtils.formatDuration((end-start), "HH:mm:ss,SSS");
		System.out.println("Total Suite Execution time(HMS): " + totalTime);
		writeExcel.generateReportSheet(String.valueOf((end-start)),browser,Env,ip);
		writeExcel.close(); 
		writeExcel.pieChartReport();
		driver.quit();
		XmlSuite suite = new XmlSuite();
		suite.setName("GenASys Suite");
	}
	//Create WebDriver Browser instance
	public static void createWebDriverObject(String browser){
		try{
			if(browser.contains("firefox")){
				System.out.println("into the condition");
				try{
				File profileDir = new File(firefoxProfilePath);
				FirefoxProfile firefoxProfile = new FirefoxProfile(profileDir);
				driver = new FirefoxDriver(firefoxProfile);}
				catch(Exception e){
					System.out.println("FireFox issue"+e);
				}
			}else if(browser.contains("chrome")){
				System.setProperty("webdriver.chrome.driver",chrome);
				driver = new ChromeDriver();
				
			}
			else if(browser.contains("ie")){
				System.setProperty("webdriver.ie.driver", InternetExplorer);
				DesiredCapabilities capabilitiesIE = DesiredCapabilities.internetExplorer();
				capabilitiesIE.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				driver = new InternetExplorerDriver(capabilitiesIE);		
			}	
			
			driver.manage().timeouts().pageLoadTimeout(180, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(Long.parseLong(waitingTime), TimeUnit.SECONDS);
			driver.manage().window().maximize();
			System.out.println("Driver Object is ready");
			}catch(Exception e){
			System.out.println(e);
			}
		}	
	public static WebDriver getDriverObject(){
		return driver;
	}
	
	public static String getInputDomainPath(){
		return domainsFilePath;
	}
	
	public static String getTestLogHTMLLocation(){
		return testLogHTMLLocation;
	}
	
	public static String getWaitingTime(){
		return waitingTime;
	}
	
	public static String getfirefoxProfilePath(){
		return firefoxProfilePath;
	}
	
	public static String getchrome(){
		return chrome;
	}
	
	public static String getInternetExplorer(){
		return InternetExplorer;
	}
	
	public static File getTestlogFolder(){
		return testlogFolder;
	}
	
	public static File getClientLogHTMLFolder(){
		return clientLogHTMLFolder;
	}
	
	public static File getScreenShotFolder(){
		return screenShotFolder;
	}
	
	public static WriteToExcel getWriteExcel(){
		return writeExcel;
	}
	
	public static boolean setEnvironmentDetails(ReadFromExcel readFromExcel,String sheetName){
    	String selection=null;
    	try{
    		readFromExcel.setSheet(sheetName);
    		selection =  readFromExcel.getCellValue("B4");
    		Env=readFromExcel.getCellValue("B4");
    	}catch(Exception e){
    		readFromExcel.close();	
    	}
    	
    	if(selection.contains("Staging"))
    		return true;
    	else
    		return false;
     }
	
	public static void setBrowserDetails(ReadFromExcel readFromExcel,String sheetName){
    	
    	try{
    		readFromExcel.setSheet(sheetName);
    		browser=readFromExcel.getCellValue("B5");
    	}catch(Exception e){
    		readFromExcel.close();	
    	}
     }
}
