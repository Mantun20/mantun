package com.genasys.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import net.sf.saxon.instruct.NextMatch;

import org.apache.commons.lang3.time.DurationFormatUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jfree.data.time.Second;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.genasys.api.Implementation;
import com.genasys.locators.AllGeneralTabs;
import com.genasys.locators.GenB2CSales;
import com.genasys.locators.MTALocators;
import com.genasys.utils.DataSheetRead;
import com.genasys.utils.DomainList;
import com.genasys.utils.NextGenUtilities;
import com.genasys.utils.WriteToExcel;
import com.genasys.webdriver.WillisWebdriver;

public class Client_MTA extends Implementation 
{
	public static MTALocators locators;
	private WebDriver driver;
	private String clientName;
	private int row = 1;
	private int column = 1;
	private Implementation Implementation;
	private WriteToExcel writeExcel;
	private AllGeneralTabs allGeneralTabsObj;
	private long start;  
	String firefoxProfilePath;
	public String policyNumberFact;
	String chrome;
	String InternetExplorer;
	String waitingTime;
	String browsername;  
	String prevBrowserName;
	public String policyNumberCAT;
	public int  flag = 0;
	int incr = 1;



	//constructor
	public Client_MTA(WebDriver driver) {
		this.driver = driver;
		WillisWebdriver.clientName=clientName;
		WillisWebdriver.createWebDriverObject(browsername);
		driver=WillisWebdriver.getDriverObject();
		locators=PageFactory.initElements(driver, MTALocators.class);		
		Implementation = PageFactory.initElements(driver, Implementation.class);			
		allGeneralTabsObj=PageFactory.initElements(driver, AllGeneralTabs.class);
		prevBrowserName=browsername;
	}

	//*************************************Client Login For MTA***********************************************

	public void keyToLoginApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "DropDownValue");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Launch the browser as well application
		//Implementation.launchClientURL(driver, clientName, browsername);

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}

	public void keyToLoginAdminApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginAdminApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name =  "SelfServiceCancellation";
		DataSheetRead DataWorkBook = null;
		String AdminUrl = "";
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			AdminUrl = DataWorkBook.readCellString(pc_sheet_name, "Admin_Access", "BaseUrl");
			Username = DataWorkBook.readCellString(pc_sheet_name, "Admin_Access", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name, "Admin_Access", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name, "Admin_Access", "SponsorName");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Launch the browser as well application

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Launch the application
		driver.get(AdminUrl); 
		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameAdmin,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordAdmin,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginAdmin,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_SelectSpoAdmin);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_SelectAponsorAdmin,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}

	public void loginB2CSalesClient_Product_ASTTBCInsurancePackageRenewal() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginAdminApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name =  "SelfServiceCancellation";
		DataSheetRead DataWorkBook = null;
		String clientappUrl = "";
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			clientappUrl = DataWorkBook.readCellString(pc_sheet_name, "Client_Access", "BaseUrl");
			Username = DataWorkBook.readCellString(pc_sheet_name, "Client_Access", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name, "Client_Access", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name, "Client_Access", "SponsorName");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Launch the browser as well application
		driver.get(clientappUrl);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		System.out.println("Username ISSSS "+Username);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify Username is entered", "User able to Enter Username", "Unable to Enter Username", Username);

		//Enter Password in Login Page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify Password is entered", "User able to Enter Password", "Unable to Enter Password", Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify login button is clicke", "User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		System.out.println("Value is "+Sponsordropdownvalue);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on Select button
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient, "Verify sponsor is selected", "System is able to select Sponsor", "System is not able to select sponsor");
		Thread.sleep(4000);
	}

	//*****************Create Policy for MTA Validation*********************
	public void keyToCreatePolicyForMTAPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToMAPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "Product";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Product="";
		String ExpiryDate = ""; 
		String DeviceModel = "";
		String CoverLevel = "";
		String CompanyID ="";
		String CompanyName ="";
		String Department ="";
		String Addresstype ="";
		String AddressLine1 ="";
		String City ="";
		String Zipcode ="";
		String Country ="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "Username");
			ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "ExpiryDate");
			DeviceModel = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "DeviceModel");
			CoverLevel = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "CoverLevel");
			CompanyID = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "CompanyID");
			CompanyName = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "ComapnyName");
			Department = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "DepartMent");
			Addresstype = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "AddressType");
			AddressLine1 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "AddressLine1");
			City = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "City");
			Zipcode = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "ZipCode");
			Country = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "MTA_Client", "Country");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Select a Product, input is given by Excel
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='MTA Referral']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select start date 
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Enter Device Model No
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_Device, "Verify the Device field", "User able to Enter the device name", "Unable to enter the device name", DeviceModel);

		//Enter Cover Level
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_CoverLevel, "Verify the Cover Level field", "User able to Enter the Cover Level as expected", "Unable to enter the Cover Level", CoverLevel);

		//Click on next button
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_Next, "Click on Next Button In Quote details screen", "User able to click on next button in quote details", "Next button is not clickable in Quote details screen");

		//Click on next button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button In Quote details screen", "User able to click on next button in quote details", "Next button is not clickable in Quote details screen");

		//Click on create customer button
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_CreateCustomer, "Click on Next Button In Quote details screen", "User able to click on next button in quote details", "Next button is not clickable in Quote details screen");

		//Input customer Identifier
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_Quote_Company, "Click on Company", "Able to click on company", "Not able to click on company");

		//Input company ID
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyID, "Verify CustIdentifier is entered", "CustIdentifier is entered", "Not able to Input CustIdentifier", CompanyID);

		//Input Company Name
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyName, "Verify FirstName is entered", "FirstName is entered", "Not able to Input FirstName", CompanyName);

		//Input Department
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Department, "Verify FamilyName is entered", "FamilyName is entered", "FamilyName is NOT entered", Department);
		AllGeneralTabs.Department.sendKeys(Keys.TAB);

		//Input EmailAddress1
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.EmailAddress, "Verify EmailAddress1 is entered", "Email Address1 is entered", "Email Address1 is NOT entered", Username);

		//Select the default check
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, AllGeneralTabs.EmailAddress_Defualt, "Verify default check box is present", "User able to select default check box", "User not able to select default check box");

		//Click on Next Button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(GenCustCreation.nextCButton), "Verify Next button is clicked", "Next button is clicked successfully", "Next button is NOT enabled/Clicked");

		//Click on new address
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.NewAddress, "Verify New address tab", "Usr able to click on new address tab", "New address tab is not clickable");

		//Select Address Type
		Select AddressTypeDD=new Select(driver.findElement(GenCustCreation.AddressType1));
		AddressTypeDD.selectByVisibleText(Addresstype);

		//Enter Address Line1
		Thread.sleep(3000); 
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.AddressLine11), "Enter address line 1", "Address Line 1 is entered", "Address line 1 is not entered as expected", AddressLine1);

		//Enter City
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.City1), "Enter city", "User able to enter city name", "Uanble to enter city in text field area", City);

		//Enter ZIP Code
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.ZIPCode1), "Enter zip code", "User able to enter zipcode in text field area", "Uanble to enter zipcode in text field area", Zipcode);

		//  		//Enter Country
		//  		Select CountryDD=new Select(driver.findElement(GenCustCreation.Country1));
		//  		CountryDD.selectByVisibleText(Country);

		//Click Address Save Button
		Implementation.ClickFeild(driver,driver.findElement(GenCustCreation.AddressSaveButton1), "Address Save Button is clicke", "Address Save button is clicke", "Address Save button is NOT Enabled/Clicked");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on create policy button", "Able to click create policy button", "Unable to click on create policy button");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on create policy button", "Able to click create policy button", "Unable to click on create policy button");

		//  			//Select Yes Button
		//  			Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_CreatePolicy_Yes1), "Select yes button", "Able to select yes button", "Unable to select yse button");
		//
		//  			//Click on Create Policy
		//  			Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on next button", "Able to click on next button", "Unable to click on next button");
		//
		//  			//Click on Create Policy
		//  			Implementation.ClickFeild(driver,driver.findElement(MTALocators.btn_createPolicy1),"Click on Next Button", "Able to click on next button in summary", "Unable to click next button in summary");

		Thread.sleep(7000);

		//Fetch Policy/Plan number
		String planNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+planNumber);

	}


	public void keyToSearchPolicyPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToSearchPolicyPage*******************");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	

		//Fetch Policy/Plan number
		String policyNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		//String policyNumber="144683";
		System.out.println("Plan/Plocy number is created "+policyNumber);

		//Mouse over on search tab
		Thread.sleep(5000);
		Implementation.MouseOver(driver, AllGeneralTabs.Tab_Search, "Verify mouse over on search tab", "Able to mouse over on search tab", "Unable to mouse over on search tab");

		//Click on Policy
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.SubMenu_Policy), "Verify Click on policy", "Clicked on policy Tab", "Unable to Click on policy Tab");

		//Enter Policy Refn
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Policy_Ref, "Enter policy in ref text box", "Enter policy number into text box area", "Unable to Enter policy number into text box area",policyNumber);

		//Click on search button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.Policy_Ref_Search, "Click on search button", "Able to click on search button", "Unable to click on search button");

		//Click on search policy number
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.Policy_Number, "Click on hyperlink of the policy number", "Able to click on search policy number", "Unable to click on search policy number");

	}

	public void keyToSearchOrderPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToSearchPolicyPage*******************");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	

		//Fetch the Order ID
		Thread.sleep(5000);
		String orderID=driver.findElement(GenB2CSales.txt_OrderID).getAttribute("value");
		System.out.println("orderID"+orderID);

		//Mouse over on search tab
		Thread.sleep(5000);
		Implementation.MouseOver(driver, AllGeneralTabs.Tab_Search, "Verify mouse over on search tab", "Able to mouse over on search tab", "Unable to mouse over on search tab");

		//Click on Policy
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.SubMenu_Order), "Verify Click on policy", "Clicked on policy Tab", "Unable to Click on policy Tab");

		//Enter Policy Refn
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Order_Ref, "Enter policy in ref text box", "Enter policy number into text box area", "Unable to Enter policy number into text box area",orderID);

		//Click on search button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.Policy_Ref_Search, "Click on search button", "Able to click on search button", "Unable to click on search button");

		//Click on search policy number
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.lnk_PoiNumber), "Click on hyperlink of the policy number", "Able to click on search policy number in order search page", "Unable to click on search policy number in order search page");

	}

	public void keyToSearchQuotePage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToSearchQuotePage*******************");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	

		//Mouse over on search tab
		Thread.sleep(5000);
		Implementation.MouseOver(driver, AllGeneralTabs.Tab_Search, "Verify mouse over on search tab", "Able to mouse over on search tab", "Unable to mouse over on search tab");

		//Click on QUOTE Tab
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Client_Quote), "Click on quote tab", "Clicked on quote tab", "Unable to Click on quote tab");


	}


	public void keyToCreateMTAPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateMTAPage*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path"); 
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String RefNumber = "";


		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			RefNumber = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "RefNumber");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Create MTA button
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_CreateMTA, "Verify the Create MTA in policy view section", "Able to click on Create MTA in policy view section", "Unable to click on Create MTA in policy view section");

		//Enter Ref Number
		Implementation.EnterTextFeild(driver, AllGeneralTabs.MTA_CreateMTA_RefNo, "Enter External Ref number no", "Able to enter the ref num in External Ref number field", "User not able to enter the ref num in External Ref number field", RefNumber);

		//Enter MSIDN Number
		Implementation.EnterTextFeild(driver, AllGeneralTabs.MTA_CreateMTA_MSIDN, "Enter MSIDN No", "Able to enter the MSIDN num in MSIDN number field", "User not able to enter the ref num in External Ref number field", RefNumber);
		AllGeneralTabs.MTA_CreateMTA_MSIDN.sendKeys(Keys.TAB);

		//Click on Calculate button
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_CreateMTA_Calculatebtn, "Click on calculate button in Policy View Screen", "User able to click on calculate button", "User not able to click on calculate button Policy View Screen");
		Thread.sleep(5000);

	}


	public void keyToCreateMTAforCATPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateMTAforCATPageSS*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path"); 
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA =  "Product";
		DataSheetRead DataWorkBook = null;
		String effectiveDate = "";
		String additionalPremium = "";
		String Premium = "";


		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			effectiveDate = DataWorkBook.readCellString(pc_sheet_name_MTA, "MTA_Complex", "effectiveDate");
			additionalPremium = DataWorkBook.readCellString(pc_sheet_name_MTA, "MTA_Complex", "SelectPremiumDD");
			Premium = DataWorkBook.readCellString(pc_sheet_name_MTA, "MTA_Complex", "Premium");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Create MTA button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_CreateMTA, "Verify the Create MTA in policy view section", "Able to click on Create MTA in policy view section", "Unable to click on Create MTA in policy view section");

		//Enter Effective Date
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_EffectiveMTADate, "Enter effective date", "User able to enter effective date", "Unable to enter effective date", effectiveDate);

		//Select Additional premium
		Thread.sleep(5000);
		Select premium = new Select(AllGeneralTabs.MTA_CreateMTA_SelectAdditionalPremium);
		premium.selectByVisibleText(additionalPremium);

		//Enter MSIDN Number
		Implementation.EnterTextFeild(driver, AllGeneralTabs.MTA_Calculation_GrossPremium, "Enter additioanl premium amount", "Able to enter additional premium amount", "Unable to enter additional premium", Premium);
		AllGeneralTabs.MTA_Calculation_GrossPremium.sendKeys(Keys.TAB);

		Thread.sleep(3000);
		//Click on save button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.MTA_Calculation_Savebtn), "Verify the save button is cliackable", "User able to click on save button", "Save button is not clickable");
		Thread.sleep(8000);

	}

	public void keyToMTAReferralActionPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToMTAReferralActionPage*******************");

		//*****************MTA Referral Action Validation********************************
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Verify the MTA Referral Action Box
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referellel_ActionBox)){
			NextGenUtilities.appendPass("Verify the MTA Referellel action box", "User able to see MTA referellel action box is craeted after clicking on calculate button");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the MTA Referellel action box", "MTA referellel action box is not craeted after clicking on calculate button");
		}

		//Click on save button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.MTA_Calculation_Savebtn), "Verify the save button is cliackable", "User able to click on save button", "Save button is not clickable");

		//Verify the Email pop up
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referral_Email_Popup)){
			NextGenUtilities.appendPass("Verify the MTA Referral Email", "User able to see MTA Referral Email Pop up");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the MTA Referellel action box", "User not seeing MTA Referral Email Pop up");
		}

		//Click on yes button
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Calculation_OkBtn, "Click on Yes Button on MTA Email Popup", "Able to click on Yes button on overlay", "Unbale to click on Yes button on overlay");

		//Verify MTA Referral Action 
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referellel_ActionBox1)){
			NextGenUtilities.appendPass("Verify the MTA Referral Action", "User able to see MTA referral action box as referred");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the MTA Referral Action", "User not able to see MTA referral action box as referred");
		}

		//Verify the SLA 
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referellel_Action_SLA)){
			NextGenUtilities.appendPass("Verify the SLA in MTA Referral Action Box", "User able to see SLA in MTA referral action box");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the SLA in MTA Referral Action Box", "User not seeing SLA in MTA referral action box");
		}

		//Verify and Click Assign button
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referral_Action_AssignBtn)){
			NextGenUtilities.appendPass("Verify the Assign Button", "Assign button is getting displayed in MTA Referral Action Box");
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Referral_Action_AssignBtn, "Click on Assign Button in MTA Referral Action Box", "Able to click on Assign button in MTA Referral Action Box", "Unbale to click on Assign Button inMTA Referral Action Box");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Assign Button in MTA Referral Action Box", "Assign button is not getting displayed in MTA Referral Action Box");
		}

		//Verify the Un-assign button in MTA Action field 
		Thread.sleep(5000); 
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referral_Action_UnAssignBtn)){
			NextGenUtilities.appendPass("Verify the Un-Assign Button in MTA Referral Action Box", "Un-Assign button is getting displayed in MTA Referral Action Box after assigning the task");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Un-Assign Button in MTA Referral Action Box", "Un-Assign button is not getting displayed in MTA Referral Action Box after assigning the task");
		}

	} 


	public void keyToAcceptMTAPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToAcceptMTAPage*******************");

		//*****************Policy Transaction Screen -Accept MTA Validation******************************

		//Click on Policy Transaction
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Transaction, "Click on Policy Transaction Tab", "User able to click on policy transaction tab ", "policy transaction tab is not clickable");

		//Click on Hyper link
		Thread.sleep(5000); 
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_PolicyTransaction_FirstLink, "Click on hyperlink", "User able to click on Hyperlink under policy transaction", "Hyperlink is not clickable under policy transaction");

		//Verify the MTA Status
		Thread.sleep(5000); 
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_PolicyTransaction_MTA_Status)){
			NextGenUtilities.appendPass("Verify the MTA Status", "User seeing MTA Status as Referred in Policy Transactions");
		}else{ 
			NextGenUtilities.logFailure(driver, "Verify the MTA Status", "MTA Status is not Referred in Policy Transactions");
		}

		//Verify the MTA Reason
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_PolicyTransaction_MTA_Reason)){
			NextGenUtilities.appendPass("Verify the MTA Reason", "User can see MTA Reason in Policy Transactions");
		}else{ 
			NextGenUtilities.logFailure(driver, "Verify the MTA Reason", "User can not see MTA Reason in Policy Transactions");
		}

		//Click on Policy Tab
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_PolicyTab, "Enter Policy Tab", "User able to click on policy tab ", "polic tab is not clickable");

		//Click on Assign Button
		//Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Referral_Action_AssignBtn, "Click on Assign Button in MTA Referral Action Box", "Able to click on Assign button in MTA Referral Action Box", "Unbale to click on Assign Button inMTA Referral Action Box");

		//Click on Accept MTA 
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_PolicyViewScreen_AcceptMTA, "Click on Accept MTA button in policy view screen", "Able to click on Accept MTA button in policy view screen", "Unbale to click on Accept MTA button in policy view screen");

		//Verify the MTA Referral Action-Closed
		//		Thread.sleep(5000); 
		//		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referellel_ActionBox1)){
		//			NextGenUtilities.logFailure(driver, "Verify the MTA Referral Action-Closed", "User not able to see MTA referral action box is closed after accepting the MTA");
		//		}else{
		//
		//			NextGenUtilities.appendPass("Verify the MTA Referral Action-Closed", "User able to see MTA referral action box is closed after accepting the MTA");
		//		}

		//Verify the Net Premium updated with Additional Premium/Return Premium (AP/RP)
		String netPremium=AllGeneralTabs.MTA_AcceptMTA_NetPremium.getAttribute("value");
		System.out.println("Plan/Plocy number is created "+netPremium);

	}

	public void keyToDeclineMTAPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToDeclineMTAPage*******************");

		//*****************Policy Transaction Screen -Decline MTA Validation******************************
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	

		//Click on Decline MTA
		Implementation.ClickFeild(driver, MTALocators.MTA_Declinebtn, "Click on Decline MTA button", "Decline MTA button is clickable in Policy view screen", "Decline MTA button is not clickable in Policy view screen");

		//Verify the Decline MTA pop up
		if(Implementation.isobjDisplayed(MTALocators.MTA_Decline_Popup)){
			NextGenUtilities.appendPass("Verify the Decline MTA pop up", "Decline MTA pop up is getting dispalyed after clicking on DEcline MTA button in policy view screen");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Decline MTA pop up", "Decline MTA pop up is not dispalyed after clicking on DEcline MTA button in policy view screen"); 
		}

		//Verify the Cancel button on Decline MTA pop up
		if(Implementation.isobjDisplayed(MTALocators.MTA_Decline_Popup_Cancelbtn)){
			NextGenUtilities.appendPass("Verify the Cancel button on Decline MTA pop up", "Cancel button is displayed on Decline MTA pop up");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Cancel button on Decline MTA pop up", "Cancel button is not displayed on Decline MTA pop up"); 
		}

		//Verify the OK button on Decline MTA pop up
		if(Implementation.isobjDisplayed(MTALocators.MTA_Decline_Popup_Oklbtn)){
			NextGenUtilities.appendPass("Verify the OK button on Decline MTA pop up", "OK button is displayed on Decline MTA pop up");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the OK button on Decline MTA pop up", "OK button is not displayed on Decline MTA pop up"); 
		}

		//Click on Cancel button on Decline MTA pop up
		Implementation.ClickFeild(driver, MTALocators.MTA_Decline_Popup_Cancelbtn, "Click on Cancel Button on Decline MTA popup", "Cancel Button is clickable on Decline MTA popup", "Cancel Button is not clickable on Decline MTA popup");

		//Verify the Decline MTA pop up is navigating to policy view screen after cancel
		if(Implementation.isobjDisplayed(MTALocators.MTA_Declinebtn)){
			NextGenUtilities.appendPass("Verify the Decline MTA pop up is navigating to policy view screen after cancel", "Decline MTA pop up is navigating to policy view screen after click on cancel");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Decline MTA pop up is navigating to policy view screen after cancel", "Decline MTA pop up is not navigating to policy view screen after click on cancel"); 
		}

		//Click on Decline MTA
		Implementation.ClickFeild(driver, MTALocators.MTA_Declinebtn, "Click on Decline MTA button", "Decline MTA button is clickable in Policy view screen", "Decline MTA button is not clickable in Policy view screen");

		//Click on OK button on Decline MTA pop up
		Implementation.ClickFeild(driver, MTALocators.MTA_Decline_Popup_Oklbtn, "Click on OK Button on Decline MTA popup", "OK Button is clickable on Decline MTA popup", "OK Button is not clickable on Decline MTA popup");

		//Click on Policy Transaction
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Transaction, "Enter Policy Transaction", "User able to click on policy transaction tab ", "policy transaction tab is not clickable");

		//Click on Hyper link
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_PolicyTransaction_FirstLink, "Click on hyperlink", "User able to click on Hyperlink under policy transaction", "Hyperlink is not clickable under policy transaction");

		//Verify the MTA Status updated as DEclined
		if(Implementation.isobjDisplayed(MTALocators.MTA_Status_Declined)){
			NextGenUtilities.appendPass("Verify the MTA Status updated as Declined", "MTA Status updated as Declined after Decline MTA");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the MTA Status updated as DEclined", "MTA Status is not updated as Declined after Decline MTA"); 
		}

	}


	public void keyToPolicyCancelPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToPolicyCancelPage*******************");

		//*****************Policy Cancel Screen -Error Message Validation******************************

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String CancellationReason = "";
		String Forced = "";
		String PartyCancelling = "";
		String StartDate = ""; 


		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			CancellationReason = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "CancellationReason");
			Forced = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "Forced");
			PartyCancelling = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "PartyCancelling");
			StartDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Client", "SearchDateFrom");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Policy Tab
		Implementation.ClickFeild(driver, MTALocators.PolicyCancel_Tab, "Click on Policy Tab in Policy View Page", "Able to Click on Policy Tab in Policy View Page", "Unable to click on Policy Tab in Policy View Page");

		//Select Cancellation Reason
		Thread.sleep(5000); 
		Select dropdown1 = new Select(MTALocators.PolicyCancelScreen_SelectCancelReason);
		dropdown1.selectByVisibleText(CancellationReason);

		//Select Voluntary or Forced
		Thread.sleep(5000); 
		Select dropdown21 = new Select(MTALocators.PolicyCancelScreen_SelectForced);
		dropdown21.selectByVisibleText(Forced);

		//Select Party Cancelling Policy
		Thread.sleep(5000); 
		Select dropdown22 = new Select(MTALocators.PolicyCancelScreen_SelectParty);
		dropdown22.selectByVisibleText(PartyCancelling);

		//Select Cancellation Date 
		// 		Thread.sleep(5000); 
		//  	Implementation.EnterTextFeild(driver, MTALocators.PolicyCancelScreen_CancellationDate, "Select Cancelling Date", "Able to select the cancelling date in policy cancel screen", "Unable to select the cancelling date in policy cancel screen", StartDate);
		//  	MTALocators.PolicyCancelScreen_CancellationDate.sendKeys(Keys.TAB); 

		//Click on Save Button
		Implementation.ClickFeild(driver, MTALocators.PolicyCancelScreen_Save, "Click on Save Button in policy cancel screen", "Able to click on Save Button in policy cancel screen", "Unable to click on Save Button in policy cancel screen");

		//Click on Continue Button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, MTALocators.PolicyCancelScreen_OKbtn, "Click on Continue Button in policy cancel screen pop up", "Able to click on Continue Button in policy cancel screen pop up", "Unable to click on Continue Button in policy cancel screen pop up");

		//Verify the Policy Cancellation Error Message-"Policy cannot be cancelled if there is an MTA request pending for it." 
		if(Implementation.isobjDisplayed(MTALocators.PolicyCancelScreen_OKbtn_ErrorMsg)){
			NextGenUtilities.appendPass("Verify the Policy Cancellation Error Message in policy cancel screen", "System is throwing Policy Cancellation Error Message in policy cancel screen-" + MTALocators.PolicyCancelScreen_OKbtn_ErrorMsg.getText());
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Policy Cancellation Error Message in policy cancel screen", "System is not throwing Policy Cancellation Error Message in policy cancel screen- "+ MTALocators.PolicyCancelScreen_OKbtn_ErrorMsg.getText()); 
		}

	}


	//*************************************Client Login For MTA***********************************************

	public void keyToLoginApplicationMTAComplexPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginApplicationMTAComplexPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "DropDownValue");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}

	public void keyToLoginApplication_VolvoChile() throws InterruptedException, IOException{

		System.out.println("******Started Keyword - keyToLoginApplication_VolvoChile*******");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "BulkUpload";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "Bulk_Upload_Volvo", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "Bulk_Upload_Volvo", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "Bulk_Upload_Volvo", "DropDownValue");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}

	//*****************Create Policy for MTA Complex Validation*********************
	public void keyToCreatePolicyMTAComplexPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreatePolicyMTAComplexPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String ProducName = "";
		String ExpiryDate = "";
		String BusinessDes = "";
		String InterestedParty = "";
		String State = "";
		String LiabilityLimit = "";
		String Category ="";
		String Year ="";
		String Make ="";
		String Model ="";
		String SerialNo ="";
		String PinNo ="";
		String SumInsured ="";
		String RoadUsed ="";
		String GPSTracking ="";
		String Username = "";
		String CompanyID ="";
		String CompanyName ="";
		String Department ="";
		String Addresstype ="";
		String AddressLine1 ="";
		String City ="";
		String Zipcode ="";
		String Country =""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			ProducName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ProducName");
			ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ExpiryDate");
			BusinessDes = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "BusinessDes");
			InterestedParty = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "InterestedParty");
			State = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "State");
			LiabilityLimit = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "LiabilityLimit");
			Category = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Category");
			Year = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Year");
			Make = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Make");
			Model = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Model");
			SerialNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SerialNo");
			PinNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "PinNo");
			SumInsured = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SumInsured");
			RoadUsed = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "RoadUsed");
			GPSTracking = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "GPSTracking");
			Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Username");
			CompanyID = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "CompanyID");
			CompanyName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ComapnyName");
			Department = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "DepartMent");
			Addresstype = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressType");
			AddressLine1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressLine1");
			City = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "City");
			Zipcode = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ZipCode");
			Country = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Country");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Select a Product, input is given by Excel
		Thread.sleep(9000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='"+ProducName+"']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select start date 
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Business Description
		Select Business = new Select(MTALocators.MTAComplex_Quote_Business);
		Business.selectByVisibleText(BusinessDes);

		//Enter Interested Party
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_InterestedParty, "Enter Interested Party", "Able to Enter Interested Party", "Unable to Enter Interested Party", InterestedParty);

		//Select State
		Select state = new Select(MTALocators.MTAComplex_Quote_State);
		state.selectByVisibleText(State);

		//Select 3rd Party Liability Limit
		Select liability = new Select(MTALocators.MTAComplex_Quote_TPLLimit); 
		liability.selectByVisibleText(LiabilityLimit);  

		//Select Category
		Select category = new Select(MTALocators.MTAComplex_Quote_Category);
		category.selectByVisibleText(Category);

		//Enter Year
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Year, "Enter Year", "Able to Enter Year", "Unable to Enter Year", Year);

		//Enter Make
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Make, "Enter Make", "Able to Enter Make", "Unable to Enter Make", Make);

		//Enter Model
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Model, "Enter Model", "Able to Enter Model", "Unable to Enter Model", Model);

		//Enter Serial No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Serial, "Enter serial Number", "ABLE TO Enter Serial Number", "Unable to Enter Serial Number", SerialNo);

		//Enter Pin No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Pin, "Enter Pin Number", "Able to Enter Pin Number", "Unable to Enter Pin Number", PinNo);

		//Enter Sum Insured
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_SumInsured, "Enter Sum Insured", "Able to Enter Sum Insured", "Unable to Enter Sum Insured", SumInsured);

		//Select Reg Road Used
		Select roadused = new Select(MTALocators.MTAComplex_Quote_RegRoadUsed);
		roadused.selectByVisibleText(RoadUsed);

		//Select GPS Tracking
		Select gps = new Select(MTALocators.MTAComplex_Quote_GPSTracking);
		gps.selectByVisibleText(GPSTracking);

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextButton), "Click on Next Button", "Able to Click on Next Button", "Unable to Click on Next Button");

		//Click on Next Button in Quote Summary page
		Thread.sleep(3000); 
		Implementation.DoubleClick(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button in Quote Summary page", "Able to Click on Next Button in Quote Summary page", "Unable to Click on Next Button in Quote Summary page");

		//Create Customer
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_Quote_CreateCustomer, "Click on Create customer", "Able to click on create customer button in custimer screen", "Not able to click on create customer screen");

		// 			//Input customer Identifier
		// 	 		Thread.sleep(9000);
		//  		Implementation.ClickFeild(driver, MTALocators.MTAComplex_Quote_Company, "Click on Company", "Able to click on company", "Not able to click on company");
		//  			 
		//  		//Input customer Identifier
		// 	 		Thread.sleep(5000); 
		//  		Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyID, "Verify CustIdentifier is entered", "CustIdentifier is entered", "Not able to Input CustIdentifier", CompanyID);

		//Input First Name
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyName1, "Verify FirstName is entered", "FirstName is entered", "Not able to Input FirstName", CompanyName);

		//Input Family Name
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Department1, "Verify FamilyName is entered", "FamilyName is entered", "FamilyName is NOT entered", Department);
		AllGeneralTabs.Department1.sendKeys(Keys.TAB);

		//Input EmailAddress1
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.EmailAddress1, "Verify EmailAddress1 is entered", "Email address1 is entered", "Email address1 is not entered", Username);
		AllGeneralTabs.EmailAddress1.sendKeys(Keys.TAB);

		//Select the default check
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.EmailAddress_Defualt1, "Verify default check box is present", "User able to select default check box", "User not able to select default check box");

		//  		//Enter Mob No
		//  		Thread.sleep(5000);
		//  		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Mob, "Enter Mob No", "Able to Enter Mob No", "Unable to Enter Mob No", PinNo);
		//  			
		//Click on Next Button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(GenCustCreation.nextCButton), "Verify Next button is clicked", "Next button is clicked successfully", "Next button is NOT enabled/Clicked");

		//Click on new address
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.NewAddress, "Verify New address tab", "Usr able to click on new address tab", "New address tab is not clickable");

		//Select Address Type
		Thread.sleep(5000);
		Select AddressTypeDD=new Select(GenCustCreation.AddressType);
		AddressTypeDD.selectByVisibleText(Addresstype);

		//Enter Address Line1
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, GenCustCreation.AddressLine1, "Verify AddressLine1 is entered", "Address Line1 is entered", "Address Line1 is NOT entered", AddressLine1);

		//Enter City
		Implementation.EnterTextFeild(driver, GenCustCreation.City, "Verify City is Entered", "City is Entered", "City is NOT entered", City);

		//Enter ZIP Code
		Implementation.EnterTextFeild(driver, GenCustCreation.ZIPCode, "Verify ZIPCode is entered", "ZIPCode is Entered", "ZIPCode is NOT Entered", Zipcode);

		//Enter Country
		Select CountryDD=new Select(GenCustCreation.Country);
		CountryDD.selectByVisibleText(Country);

		//Click Address Save Button
		Implementation.ClickFeild(driver, GenCustCreation.AddressSaveButton, "Verify Address Save Button is clicke", "Address Save button is clicke", "Address Save button is NOT Enabled/Clicked");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on Create Policy button", "Able to click", "Unable to click");

		//Select Yes Button
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_CreatePolicy_Yes, "Select Yes Button", "Able to select yes button", "Unable to select yse button");


		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click", "Unable to click");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click next button in summary", "Unable to click next button in summary");

		//Click on Create Policy Button
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on craete policy Button", "Able to click on create policy button in policy summary screen", "Unable to click create policy in policy summary page");

		//Fetch Policy/Plan number
		String planNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+planNumber);

	}


	public void keyToCT_Subtotals_Taxes_Charges_NetPremium_Value_Displayed() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCT_Subtotals_Taxes_Charges_NetPremium_Value_Displayed*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String ProducName = "";
		String ExpiryDate = "";
		String BusinessDes = "";
		String InterestedParty = "";
		String State = "";
		String LiabilityLimit = "";
		String Category ="";
		String Year ="";
		String Make ="";
		String Model ="";
		String SerialNo ="";
		String PinNo ="";
		String SumInsured ="";
		String RoadUsed ="";
		String GPSTracking ="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			ProducName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ProducName");
			ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ExpiryDate");
			BusinessDes = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "BusinessDes");
			InterestedParty = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "InterestedParty");
			State = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "State");
			LiabilityLimit = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "LiabilityLimit");
			Category = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Category");
			Year = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Year");
			Make = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Make");
			Model = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Model");
			SerialNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SerialNo");
			PinNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "PinNo");
			SumInsured = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SumInsured");
			RoadUsed = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "RoadUsed");
			GPSTracking = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "GPSTracking");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Select a Product, input is given by Excel
		Thread.sleep(9000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='"+ProducName+"']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select start date 
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Business Description
		Select Business = new Select(MTALocators.MTAComplex_Quote_Business);
		Business.selectByVisibleText(BusinessDes);

		//Enter Interested Party
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_InterestedParty, "Enter Interested Party", "Able to Enter Interested Party", "Unable to Enter Interested Party", InterestedParty);

		//Select State
		Select state = new Select(MTALocators.MTAComplex_Quote_State);
		state.selectByVisibleText(State);

		//Select 3rd Party Liability Limit
		Select liability = new Select(MTALocators.MTAComplex_Quote_TPLLimit); 
		liability.selectByVisibleText(LiabilityLimit);  

		//Select Category
		Select category = new Select(MTALocators.MTAComplex_Quote_Category);
		category.selectByVisibleText(Category);

		//Enter Year
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Year, "Enter Year", "Able to Enter Year", "Unable to Enter Year", Year);

		//Enter Make
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Make, "Enter Make", "Able to Enter Make", "Unable to Enter Make", Make);

		//Enter Model
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Model, "Enter Model", "Able to Enter Model", "Unable to Enter Model", Model);

		//Enter Serial No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Serial, "Enter serial Number", "ABLE TO Enter Serial Number", "Unable to Enter Serial Number", SerialNo);

		//Enter Pin No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Pin, "Enter Pin Number", "Able to Enter Pin Number", "Unable to Enter Pin Number", PinNo);

		//Enter Sum Insured
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_SumInsured, "Enter Sum Insured", "Able to Enter Sum Insured", "Unable to Enter Sum Insured", SumInsured);

		//Select Reg Road Used
		Select roadused = new Select(MTALocators.MTAComplex_Quote_RegRoadUsed);
		roadused.selectByVisibleText(RoadUsed);

		//Select GPS Tracking
		Select gps = new Select(MTALocators.MTAComplex_Quote_GPSTracking);
		gps.selectByVisibleText(GPSTracking);

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextButton), "Click on Next Button", "Able to Click on Next Button", "Unable to Click on Next Button");

		//Click on Next Button in Quote Summary page
		Thread.sleep(3000); 
		Implementation.DoubleClick(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button in Quote Summary page", "Able to Click on Next Button in Quote Summary page", "Unable to Click on Next Button in Quote Summary page");


	}



	public void keyToCreateNewQuoteB2CSalesPage_LJ_AtheneInvestment() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateNewQuoteB2CSalesPage_LJ_AtheneInvestment*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "Product";
		DataSheetRead DataWorkBook = null;
		String SubDivision = "";
		String ProductClass = "";
		String TIPLAN = "";


		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			SubDivision = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "ComplexTax_MS4", "SubDivision");
			ProductClass = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "ComplexTax_MS4", "ProductClass");
			TIPLAN = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "ComplexTax_MS4", "TIPLAN");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on Product tab
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_products), "Clikc on the Product Tab", "User able to create the product tab", "User unable to click on the product tab");
		System.out.println("Product tab is clicked");

		//click on the Get quote for a particular product
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_AIA_Insurance_GetaQuote), "Click on the Required product", "User able to click on the particular Product", "User unable to click on the particular product");


		//Select Value from the drop down "Are you a Member in good standing with the ASTTBC?*"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_QuoteDetails_SubDivision),"Select the sub division value from drop down", "User able to Select the sub division value from drop down", "User unable to Select the sub division value from drop down", SubDivision);

		//Select value from the drop down Have you previously purchased Professional Liability insurance to cover your ASTTBC related professional practice you are currently applying for?
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_QuoteDetails_ProductClass), "Select the product class value from drop down", "User able to Select the product class value from drop down", "User not able to Select the product class value from drop down", ProductClass);

		//Select Value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_QuoteDetails_Tiplan), "Select the TIPLAN value from drop down", "User abel to Select the TIPLAN value from drop down", "User unabel to Select the TIPLAN value from drop down",TIPLAN);

		//click on the Get a Quote Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");

		//Click on save button
		Thread.sleep(5000); 
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Save_QuoteBtn), "Click on save quote button", "User able to Click on save quote button in B2C", "User not able to Click on save quote button in B2C");


		//Click on close the pop up 
		Thread.sleep(5000); 
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2C_Closed_Popup), "Click on closed symbol", "User able to Click on closed symbol in B2C", "User not able to Click on closed symbol in B2C");

	}




	public void keyToCreateMTAComplexTaxPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateMTAPage*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path"); 
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String MTAEffectiveDate = "";
		String QuoteType = "";
		String Activities1 = "";
		String Activities2 = "";
		String Activities3 = "";
		String Activities4 = "";
		String Activities5 = "";
		String Activities6 = "";
		String Activities7 = "";
		String Activities8 = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			MTAEffectiveDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "MTAEffectiveDate");
			QuoteType = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "QuoteType");
			Activities1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities1");
			Activities2 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities2");
			Activities3 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities3");
			Activities4 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities4");
			Activities5 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities5");
			Activities6 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities6");
			Activities7 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities7");
			Activities8 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities8");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Create MTA button
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_CreateMTA, "Verify the Create MTA in policy view section", "Able to click on Create MTA in policy view section", "Unable to click on Create MTA in policy view section");

		//Enter MTA Effective Date
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_EffectiveMTADate, "Select MTA Effective Date", "able to select MTA Effective Date", "Unable to select MTA Effective Date", MTAEffectiveDate);

		//Select Quote Type
		Select quotetype=new Select(MTALocators.MTAComplex_CreateMTA_QuoteType);
		quotetype.selectByVisibleText(QuoteType);

		//Select Activities1 
		Select act1=new Select(MTALocators.MTAComplex_CreateMTA_Activities1);
		act1.selectByVisibleText(Activities1);

		//Select Activities1 
		Select act2=new Select(MTALocators.MTAComplex_CreateMTA_Activities2);
		act2.selectByVisibleText(Activities2);

		//Select Activities1 
		Select act3=new Select(MTALocators.MTAComplex_CreateMTA_Activities3);
		act3.selectByVisibleText(Activities3);

		//Select Activities1 
		Select act4=new Select(MTALocators.MTAComplex_CreateMTA_Activities4);
		act4.selectByVisibleText(Activities4);

		//Select Activities1 
		Select act5=new Select(MTALocators.MTAComplex_CreateMTA_Activities5);
		act5.selectByVisibleText(Activities5);

		//Select Activities1 
		Select act6=new Select(MTALocators.MTAComplex_CreateMTA_Activities6);
		act6.selectByVisibleText(Activities6);

		//Select Activities1 
		Select act7=new Select(MTALocators.MTAComplex_CreateMTA_Activities7);
		act7.selectByVisibleText(Activities7);

		//EnterIndicate Percentage
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_CreateMTA_Activities8, "Enter Indicate Percentage", "Able to enter indicate percentage", "Unable to enter indicate percentage", Activities8);

		//Click on Calculate button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_CreateMTA_Calculatebtn, "Click on calculate button in Policy View Screen", "User able to click on calculate button", "User not able to click on calculate button Policy View Screen");
		Thread.sleep(5000);

		//When user creates MTA on a Single Payment Term Policy in the GenASys client module, then the system should allow saving of the MTA without a call to PSP integration (the "Save" button not replaced by "Save & Pay" button) provided other MTA rules are met
		if(Implementation.isobjDisplayed(driver.findElement(AllGeneralTabs.MTA_Calculation_Savebtn))){
			NextGenUtilities.appendPass("Verify the Save button not replaced by Save & Pay button for GenASys client module", "User seeing save button,when MTA is not integrating with PSP for GenASys client module");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Save button not replaced by Save & Pay button for GenASys client module", "User seeing Save & Pay Button,when MTA is not integrating with PSP for GenASys client module"); 
		}

		//Click on save button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.MTA_Calculation_Savebtn), "Verify the save button is cliackable", "User able to click on save button", "Save button is not clickable");
		Thread.sleep(5000);

	} 


	//*****************Create Policy for MTA Complex Validation*********************
	public void keyToCreateQuote_PolicyMTAComplexPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreatePolicyMTAComplexPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String ProducName = "";
		String ExpiryDate = "";
		String BusinessDes = "";
		String InterestedParty = "";
		String State = "";
		String LiabilityLimit = "";
		String Category ="";
		String Year ="";
		String Make ="";
		String Model ="";
		String SerialNo ="";
		String PinNo ="";
		String SumInsured ="";
		String RoadUsed ="";
		String GPSTracking ="";
		String QuoteType = "";
		String Activities1 = "";
		String Activities2 = "";
		String Activities3 = "";
		String Activities4 = "";
		String Activities5 = "";
		String Activities6 = "";
		String Activities7 = "";
		String Activities8 = "";
		String Customer = "";
		String NetPremium = "";
		String PD = "";
		String TPL = "";


		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			ProducName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ProducName");
			ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ExpiryDate");
			BusinessDes = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "BusinessDes");
			InterestedParty = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "InterestedParty");
			State = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "State");
			LiabilityLimit = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "LiabilityLimit");
			Category = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Category");
			Year = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Year");
			Make = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Make");
			Model = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Model");
			SerialNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SerialNo");
			PinNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "PinNo");
			SumInsured = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SumInsured");
			RoadUsed = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "RoadUsed");
			GPSTracking = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "GPSTracking");
			QuoteType = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "QuoteType");
			Activities1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities1");
			Activities2 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities2");
			Activities3 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities3");
			Activities4 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities4");
			Activities5 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities5");
			Activities6 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities6");
			Activities7 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities7");
			Activities8 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Activities8");
			Customer = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Customer");
			NetPremium = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "NetPremium");
			PD = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "PD");
			TPL = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "TPL");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Select a Product, input is given by Excel
		Thread.sleep(9000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='"+ProducName+"']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select start date 
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Business Description
		Thread.sleep(5000);
		Select Business = new Select(MTALocators.MTAComplex_Quote_Business);
		Business.selectByVisibleText(BusinessDes);

		//Enter Interested Party
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_InterestedParty, "Enter Interested Party", "Able to Enter Interested Party", "Unable to Enter Interested Party", InterestedParty);

		//Select State
		Select state = new Select(MTALocators.MTAComplex_Quote_State);
		state.selectByVisibleText(State);

		//Select 3rd Party Liability Limit
		Select liability = new Select(MTALocators.MTAComplex_Quote_TPLLimit); 
		liability.selectByVisibleText(LiabilityLimit);  

		//Select Category
		Select category = new Select(MTALocators.MTAComplex_Quote_Category);
		category.selectByVisibleText(Category);

		//Enter Year
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Year, "Enter Year", "Able to Enter Year", "Unable to Enter Year", Year);

		//Enter Make
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Make, "Enter Make", "Able to Enter Make", "Unable to Enter Make", Make);

		//Enter Model
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Model, "Enter Model", "Able to Enter Model", "Unable to Enter Model", Model);

		//Enter Serial No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Serial, "Enter serial Number", "ABLE TO Enter Serial Number", "Unable to Enter Serial Number", SerialNo);

		//Enter Pin No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Pin, "Enter Pin Number", "Able to Enter Pin Number", "Unable to Enter Pin Number", PinNo);

		//Enter Sum Insured
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_SumInsured, "Enter Sum Insured", "Able to Enter Sum Insured", "Unable to Enter Sum Insured", SumInsured);

		//Select Reg Road Used
		Select roadused = new Select(MTALocators.MTAComplex_Quote_RegRoadUsed);
		roadused.selectByVisibleText(RoadUsed);

		//Select GPS Tracking
		Select gps = new Select(MTALocators.MTAComplex_Quote_GPSTracking);
		gps.selectByVisibleText(GPSTracking);

		//Select the Quote Type
		//Select Quote Type
		Select quotetype=new Select(MTALocators.MTAComplex_CreateMTA_QuoteType);
		quotetype.selectByVisibleText(QuoteType);

		//Select Activities1 
		Select act1=new Select(MTALocators.MTAComplex_CreateMTA_Activities1);
		act1.selectByVisibleText(Activities1);

		//Select Activities1 
		Select act2=new Select(MTALocators.MTAComplex_CreateMTA_Activities2);
		act2.selectByVisibleText(Activities2);

		//Select Activities1 
		Select act3=new Select(MTALocators.MTAComplex_CreateMTA_Activities3);
		act3.selectByVisibleText(Activities3);

		//Select Activities1 
		Select act4=new Select(MTALocators.MTAComplex_CreateMTA_Activities4);
		act4.selectByVisibleText(Activities4);

		//Select Activities1 
		Select act5=new Select(MTALocators.MTAComplex_CreateMTA_Activities5);
		act5.selectByVisibleText(Activities5);

		//Select Activities1 
		Select act6=new Select(MTALocators.MTAComplex_CreateMTA_Activities6);
		act6.selectByVisibleText(Activities6);

		//Select Activities1 
		Select act7=new Select(MTALocators.MTAComplex_CreateMTA_Activities7);
		act7.selectByVisibleText(Activities7);

		//EnterIndicate Percentage
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_CreateMTA_Activities8, "Enter Indicate Percentage", "Able to enter indicate percentage", "Unable to enter indicate percentage", Activities8);

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextButton), "Click on Next Button", "Able to Click on Next Button", "Unable to Click on Next Button");

		//Click on Next Button in Quote Summary page
		Thread.sleep(9000); 
		Implementation.DoubleClick(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button in Quote Summary page", "Able to Click on Next Button in Quote Summary page", "Unable to Click on Next Button in Quote Summary page");

		//Search the customer
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_CreateQuote_TextSearch, "Enter Customer Name", "Able to enter customer name in text box", "Unable to enter customer name in text box", Customer);

		//Click on Search box
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_CreateQuote_Search, "Click on search button", "Search button is clickable", "Search button is not clickable");

		//Click on 1st customer link
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_SearchCustomer_1stCustomer, "Click on 1st customer", "Able to click on 1st customer", "Unable to click on 1st customer");

		//Click on Save Quote Button
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_SearchCustomer_SaveQuote, "Click on Save Quote Button", "Able to click on Click on Save Quote Button", "Save quote is not clickable");

		//Click on Yes Button on Pop up
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_SearchCustomer_YesBtn, "Click on Yes Button on Save Quote Popup", "Able to Click on Yes Button on Save Quote Popup", "Unable to click on Yes Button on Save Quote Popup");

		//Click on OK button
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_SearchCustomer_OkBtn, "Click on OK button on popup", "Able to Click on OK button on popup", "Unable to Click on OK button on popup");

		//Fetch Quote number
		String QuoteNumber=MTALocators.MTAComplex_SearchCustomer_QuoteNumber.getText();
		System.out.println("Quote number is created "+QuoteNumber);

		//Mouse over on search tab
		Thread.sleep(5000);
		Implementation.MouseOver(driver, AllGeneralTabs.Tab_Search, "Verify mouse over on search tab", "Able to mouse over on search tab", "Unable to mouse over on search tab");

		//Click on Quote
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.SubMenu_Quote), "Verify Click on Quote", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Enter Quote Refn
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, MTALocators.Quote_Ref, "Enter policy in ref text box", "Enter Quote number into text box area", "Unable to Enter Quote number into text box area",QuoteNumber);

		//Click on search button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.Policy_Ref_Search, "Click on search button", "Able to click on search button", "Unable to click on search button");

		//Click on search Quote number
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.Quote_Ref_QuoteNumber, "Click on hyperlink of the Quote number", "Able to click on search Quote number", "Unable to click on search Quote number");

		//Click on Buy button in Quote View Screen
		Implementation.ClickFeild(driver, MTALocators.Quote_ViewScreen_Buy, "Click on Buy button in Quote View Screen", "Able to Click on Buy button in Quote View Screen", "Unable to Click on Buy button in Quote View Screen");

		//Verify the Quote Referral Action Box
		if(Implementation.isobjDisplayed(MTALocators.Quote_Referellel_ActionBox)){
			NextGenUtilities.appendPass("Verify the Quote Referellel action box", "User able to see Quote referellel action box is craeted after clicking on calculate button");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Quote Referellel action box", "Quote referellel action box is not craeted after clicking on calculate button");
		}

		//Verify and Click Assign button
		if(Implementation.isobjDisplayed(AllGeneralTabs.MTA_Referral_Action_AssignBtn)){
			NextGenUtilities.appendPass("Verify the Assign Button", "Assign button is getting displayed in Quote Referral Action Box");
			Implementation.ClickFeild(driver, AllGeneralTabs.MTA_Referral_Action_AssignBtn, "Click on Assign Button in Quote Referral Action Box", "Able to click on Assign button in Quote Referral Action Box", "Unbale to click on Assign Button in Quote Referral Action Box");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Assign Button in Quote Referral Action Box", "Assign button is not getting displayed in Quote Referral Action Box");
		}

		//Enter the Net Premium
		Implementation.EnterTextFeild(driver, MTALocators.QuoteSummary_NetPremium, "Enter the Net Premium", "Able to Enter the Net Premium", "Unable to Enter the Net Premium", NetPremium);

		//Expand the Net Premium tab
		Implementation.ClickFeild(driver, MTALocators.QuoteSummary_NetPremium_Expand, "Expand the Net Premium tab", "Ableto expand the Net Premium tab", "Unable to expand the Net Premium tab");

		//Enter Premium PD 
		Implementation.EnterTextFeild(driver, MTALocators.QuoteSummary_NetPremium_PD, "Enter Premium PD", "Able to enter Premium PD", "Unable to enter Premium PD", PD);

		//Enter Premium TPL
		Implementation.EnterTextFeild(driver, MTALocators.QuoteSummary_NetPremium_TPL, "Enter Premium TPL", "Able to enter Premium TPL", "Unable to enter Premium TPL", TPL);

		//Click on Recalculate Tax
		Implementation.ClickFeild(driver, MTALocators.QuoteSummary_Recalculate_Taxes, "Click on Recalculate Tax", "Able to click on Recalculate Tax", "Unbale to click on Recalculate Tax");

		//Verify the Total tax in referred status
		if(Implementation.isobjDisplayed(MTALocators.QuoteSummary_Recalculate_Total_Taxes)){
			NextGenUtilities.appendPass("Verify the Total tax in referred status", "User seeing total tax in referred status");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Total tax in referred status", "Total tax is not reflected as refrrer"); 
		}

		//Accept the Quote
		Implementation.ClickFeild(driver, MTALocators.QuoteSummary_Accept_Quote, "Click on accept button", "Able to click on accept button", "Unable to click on accept button");

		//Click Address Save Button
		Implementation.ClickFeild(driver, GenCustCreation.AddressSaveButton, "Verify Address Save Button is clicke", "Address Save button is clicke", "Address Save button is NOT Enabled/Clicked");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on Create Policy button", "Able to click", "Unable to click");
		Thread.sleep(5000);

		//Select Yes Button
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_CreatePolicy_Yes, "Select Yes Button", "Able to select yes button", "Unable to select yse button");


		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click", "Unable to click");
		Thread.sleep(7000);

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click next button in summary", "Unable to click next button in summary");
		Thread.sleep(7000);

		//Click on Create Policy Button
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on craete policy Button", "Able to click on create policy button in policy summary screen", "Unable to click create policy in policy summary page");
		Thread.sleep(7000);

		//Fetch Policy/Plan number
		String planNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+planNumber);

	}


	//*************************************Client Login For PS-MTA Integrations***********************************************

	public void keyToLoginClient_PSPMTAPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginClient_PSPMTAPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name =  "Product";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "DropDownValue");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username in client application", "Unable to Enter Username in client application",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password in client application", "Unable to Enter Password in client application",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully in client application", "Unable to click on Login button in client application");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button in client application", "Select button is not clickable in client application");

	}

	
	public void keyToLoginClient_BAU1_ST_Application() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginClient_BAU1_ST_Application*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password =""; 
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username= DataWorkBook.readCellString(pc_sheet_name_B2CSale, "GDPR_B2C", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "GDPR_B2C", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "GDPR", "Sponsor");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username in client application", "Unable to Enter Username in client application",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password in client application", "Unable to Enter Password in client application",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully in client application", "Unable to click on Login button in client application");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button in client application", "Select button is not clickable in client application");

	}
	public void keyToLoginClient_ComplexTaxPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginClient_ComplexTaxPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name =  "Product";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name, "ComplexTax_MS4", "DropDownValue");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username in client application", "Unable to Enter Username in client application",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password in client application", "Unable to Enter Password in client application",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully in client application", "Unable to click on Login button in client application");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button in client application", "Select button is not clickable in client application");

	}

	//*************************************Client Login For PS-MTA Integrations***********************************************

	public void keyToLoginB2CSalesPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginB2CSalesPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name =  "Product";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password= "";
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "Password");
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name, "MTA_PSP", "DropDownValue");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}


	public void keyToCreateMTA_RenewalPolicyPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateMTA_RenewalPolicyPage*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path"); 
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String LiabilityLimit1 = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			LiabilityLimit1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "LiabilityLimit1");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Create MTA button
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_CreateMTA, "Verify the Create MTA in policy view section", "Able to click on Create MTA in policy view section", "Unable to click on Create MTA in policy view section");

		//Select Quote Type
		Select dropdown=new Select(MTALocators.MTAComplex_Quote_TPLLimit);
		dropdown.selectByVisibleText(LiabilityLimit1);

		//Click on Calculate button
		Implementation.ClickFeild(driver, AllGeneralTabs.MTA_CreateMTA_Calculatebtn, "Click on calculate button in Policy View Screen", "User able to click on calculate button", "User not able to click on calculate button Policy View Screen");

		//Click on save button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.MTA_Calculation_Savebtn), "Click on save button is cliackable", "User able to click on save button", "Save button is not clickable");

		//Verify the Pop-up message box with warning message regarding the impact of the MTA
		if(Implementation.isobjDisplayed(MTALocators.Policy_Renewal_Warning_Msg)){
			NextGenUtilities.appendPass("Verify the Pop-up message box with warning message regarding the impact of the MTA", "User seeing pop-up message box with warning message regarding the impact of the MTA after click on save button");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the Pop-up message box with warning message regarding the impact of the MTA", "User not seeing pop-up message box with warning message regarding the impact of the MTA after click on save button"); 
		}

		//Click on continue button
		Implementation.ClickFeild(driver, MTALocators.Policy_Renewal_Warning_Msg, "Click on continue button", "User able to click on continue button", "continue button is not clickable");


	} 

	public void keyToLoginB2CSalesApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginB2CSalesApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "Product";
		DataSheetRead DataWorkBook = null;
		String B2CSalesURL = "";
		String username =""; 
		String password="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			B2CSalesURL= DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "BaseUrl");
			username = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "ComplexTax_MS4", "Username");
			password = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "ComplexTax_MS4", "Password");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		//Launch B2C Sales URL
		driver.get(B2CSalesURL);

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on the login button 
		Implementation.ClickFeild(driver,driver.findElement(GenB2CSales.B2CSales_loginregister) , "Click on the Login Button", "User able to click the Login Button", "User unable to click on the Login button");

		//Enter the User Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_username), "Enter the Username", "User able to enter the Username", "User unable to enter the ", username);

		//Enter Password
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_Password), "Enter the Password", "User able to enter the Password", "User unable to enter the Password", password);

		//Click on the Login Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Login), "Click on the Login button after entering the Username and Password", "User able to click the Login button", "User unable to click the Login button");

		Thread.sleep(10000); 
	}

	public void keyToLoginB2CSales_BAU1_STApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginB2CSales_BAU1_STApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String B2CSalesURL = "";
		String username =""; 
		String password="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			B2CSalesURL= DataWorkBook.readCellString(pc_sheet_name_B2CSale, "GDPR_B2C", "BaseUrl");
			username = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "GDPR_B2C", "Username");
			password = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "GDPR_B2C", "Password");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		//Launch B2C Sales URL
		driver.get(B2CSalesURL);

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on the login button 
		Implementation.ClickFeild(driver,driver.findElement(GenB2CSales.B2CSales_loginregister) , "Click on the Login Button", "User able to click the Login Button", "User unable to click on the Login button");

		//Enter the User Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_username), "Enter the Username", "User able to enter the Username", "User unable to enter the ", username);

		//Enter Password
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_Password), "Enter the Password", "User able to enter the Password", "User unable to enter the Password", password);

		//Click on the Login Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Login), "Click on the Login button after entering the Username and Password", "User able to click the Login button", "User unable to click the Login button");

		Thread.sleep(10000); 
	}

	public void createRenewalPolicyB2CSalesApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - createRenewalPolicyB2CSalesApplicationPage*******************");

		//Click on my policies tab
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.subtab_Mypolicies), "Click on my policies in B2C sales site", "User able to click on my policies in B2C sales site", "Unable to click on my policies in B2C sales site");

		String policyNumber = driver.findElement(By.xpath("//div//a[starts-with(@id,'link')]")).getText();

		String renewalsPolicyButton = "//a[text()='"+policyNumber+"']//following::div[4]/button";

		//Click on Renewal policy
		Implementation.ClickFeild(driver, driver.findElement(By.xpath(renewalsPolicyButton)), "Click on renewals policy button", "User able to Click on renewals policy button", "Unable to Click on renewals policy button");

		//click on the Get a Quote Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton11), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Buy Now button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_CartIcon), "Click on Buy now Button", "User able to Click on Buy Now button", "User unable to click on the Buy Now button");
		Thread.sleep(9000);

	}


	public void keyToCreateOrderB2CSalesApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateOrderB2CSalesApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "Product";
		DataSheetRead DataWorkBook = null;
		String inceptionDate = "";
		String InsuranceCovered = "";
		String goodStanding = "";
		String previousInsurace = "";
		String enOLimits_0__EAOLimit = "";
		String practice="";
		String insuredDetails_0__InsName = "";
		String memebershipNumber= "";
		String employmentType = "";
		String homeInspector="";
		String locationActivites = "";
		String specialtyCheckHeader = "";
		String cGLLimit = "";
		String insuredHoldDesignat ="";
		String insuredOperationschg = "";
		String operationDescription = "";
		String annualSales ="";
		String percentageCanada ="";
		String percentageUS ="";
		String percentageOtherCountries ="";
		String purchaseResell = "";
		String construction="";
		String distribution ="";
		String gasSector="";
		String designBuild = "";
		String constBuild ="";
		String contractors =""; 
		String declInsuranceCancel ="";
		String declPreviousClaim = "";
		String declPreviousAct = "";
		String declClaimPrevious = "";
		String entity = "";
		String insuredName = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "inceptionDate");
			InsuranceCovered = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "InsuranceCovered");
			goodStanding = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "goodStanding");
			previousInsurace = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "previousInsurace");
			enOLimits_0__EAOLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "EnOLimits_0__EAOLimit");
			practice = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "practice");
			insuredDetails_0__InsName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredDetails_0__InsName");
			memebershipNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "memebershipNumber");
			employmentType = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "EmploymentType");
			homeInspector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "homeInspector");
			locationActivites = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "locationActivites");
			specialtyCheckHeader = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "specialtyCheckHeader");
			cGLLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "cGLLimit");
			insuredHoldDesignat = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredHoldDesignat");
			insuredOperationschg = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredOperationschg");
			operationDescription = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "operationDescription");
			annualSales = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "annualSales");
			percentageCanada = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageCanada");
			percentageUS = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageUS");
			percentageOtherCountries = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageOtherCountries");
			purchaseResell = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "purchaseResell");
			construction = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "construction");
			distribution = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "distribution");
			gasSector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "gasSector");
			designBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "designBuild");
			constBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "constBuild");		
			contractors = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "contractors");
			declInsuranceCancel = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declInsuranceCancel");
			declPreviousClaim = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declPreviousClaim");
			declPreviousAct = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declPreviousAct");
			declClaimPrevious = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declClaimPrevious");
			entity = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "entity");
			insuredName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredName");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on Product tab
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_products), "Clikc on the Product Tab", "User able to create the product tab", "User unable to click on the product tab");
		System.out.println("Product tab is clicked"); 

		//click on the Get quote for a particular product
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GetaQuoteASTTBC_B2C), "Click on the Required product", "User able to click on the particular Product", "User unable to click on the particular product");

		//Enter the Inception date
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.txt_QuestionsInceptionDate), "Enter the Incpetion Date", "User able to enter the inception Date", "User Unable to enter the Inception date", inceptionDate);
		driver.findElement(GenB2CSales.txt_QuestionsInceptionDate).sendKeys(Keys.TAB);

		//Select Value from Insurance Covered
		//		Thread.sleep(5000); 
		//		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.txt_InsurenceCovered), "Select Value from Insurance covered field", "User able to select value from Insurance covered field", "Unable to select value from Insurance covered field", InsuranceCovered);

		//Select Value from the drop down "Are you a Member in good standing with the ASTTBC?*"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_MemberInGoodStanding), "Select Value from Member in Good standing with ASTTBC", "User able to Select Value from Member in Good standing with ASTTBC", "User unable to Select Value from Member in Good standing with ASTTBC", goodStanding);

		//Select value from the drop down Have you previously purchased Professional Liability insurance to cover your ASTTBC related professional practice you are currently applying for?
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PreviousInsurance), "Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", previousInsurace);

		//Select Value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EnOLimits), "Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User abel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User unabel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.",enOLimits_0__EAOLimit);

		//Select Value from the filed Are you applying as an individual for coverage in your own name and are employed by a firm or organization that is not applying for insurance?
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Practice), "Select Value from the dropdown", "user to able to select value from the drop down", "user to able to select value from the drop down",practice);

		//Enter the Value in the field ASTTBC Member Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_InsName), "Enter the ASTTBC Memeber Name ", "User able to Enter the ASTTBC Memeber Name ", "user unbale to Enter the ASTTBC Memeber Name ",insuredDetails_0__InsName );

		//Enter value in the Membership Number field
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_MembershipNo), "Enter value in the Membership Number field", "user able to Enter value in the Membership Number field", "User unable to Enter value in the Membership Number field", memebershipNumber);

		//Select value in the "Your individual revenue amount is" field
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EmploymentType), "Select value in the Your individual revenue amount is field", "User able to Select value in the Your individual revenue amount is field", "User unable to Select value in the Your individual revenue amount is field", employmentType);

		//Select value in the field "Are you a Home Inspector?"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_HomeInspector), "Select value in the field Are you a Home Inspector?", "User able to Select value in the field Are you a Home Inspector?", "User unable to Select value in the field Are you a Home Inspector?", homeInspector);

		//Select Value from the field "Do you perform underground Utility Location activities?*"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_UndLocator), "Select Value from the field Do you perform underground Utility Location activities?*", "User able to Select Value from the field Do you perform underground Utility Location activities?*", "User unable to Select Value from the field Do you perform underground Utility Location activities?*", locationActivites);

		//Select Value from the filed Do you hold a Technical Speciality designation?, if Yes, select all the certifications this applicant holds *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_SpecialtyCheckHeader), "Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "user able to Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "User unable to select Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", specialtyCheckHeader);

		//Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term. *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_CGLLimit), "Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User able to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User unable to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", cGLLimit);

		//Select the value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredHoldDesignat), "Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User able to Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User unable to Are you (or any of the applicants listed before) an AScT or Ctech? *", insuredHoldDesignat);

		//Select the value from the field Have your current activities changed since last renewal?. *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredOperationschg), "Select value from the field Have your current activities changed since last renewal?. *", "User able to Select value from the field Have your current activities changed since last renewal?.", "User unable to Select value from the field Have your current activities changed since last renewal?.", insuredOperationschg);

		//Enter Text value in the Operation Description field
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_OperationDescription), "Enter Text value in the Operation Description field", "User able to Enter Text value in the Operation Description field", "User unable to Enter Text value in the Operation Description field", operationDescription);

		//Enter the Value in the field Annual Sales (in CAD) *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_AnnualSales), "Enter the Value in the field Annual Sales (in CAD) *", "User able to enter the Value in the field Annual Sales (in CAD) *", "User unable to Enter the Value in the field Annual Sales (in CAD) *", annualSales);

		//Enter value in the field Percentage of sales in Canada *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageCanada), "Enter value in the field Percentage of sales in Canada *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Canada *", percentageCanada);

		//Enter value in the field Percentage of sales in US *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageUS), "Enter value in the field Percentage of sales in US *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in US *", percentageUS);

		//Enter value in the field Percentage of sales in Other Countries *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageinOther), "Enter value in the field Percentage of sales in Other Countries *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Other Countries *", percentageOtherCountries);

		//Select Value from the field Do you or any related company purchase and/or resell products? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PurchaseResel), "Select Value from the field Do you or any related company purchase and/or resell products? *", "User able to Select Value from the field Do you or any related company purchase and/or resell products? *", "User unable to Select Value from the field Do you or any related company purchase and/or resell products? *", purchaseResell);

		//Select value from the field Your operations include hands-on work in the areas of construction (including blasting, demolition, underpinning, pile driving, shoring, welding, excavation), installation, maintenance or repairs? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Construction), "Select Value from the Construction field", "User able to Select Value from the Construction field", "User able to Select Value from the Construction field", construction);

		//Select value from the field Your operations include manufacturing, distribution or sale of products *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Distribution), "Select value from the field Your operations include manufacturing, distribution or sale of products *", "User able to Select value from the field Your operations include manufacturing, distribution or sale of products *", "User unable to Select value from the field Your operations include manufacturing, distribution or sale of products *", distribution);

		//Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_GasSector), "Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User able to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User unable to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", gasSector);

		//Select value from the field Do you undertake design-build activities? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DesignBuild), "Select value from the field Do you undertake design-build activities? *", "User able to Select value from the field Do you undertake design-build activities? *", "User unable to Select value from the field Do you undertake design-build activities? *", designBuild);

		//Select value from the field Do you undertake construction-building activities? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_ConstBuild), "Select value from the field Do you undertake construction-building activities? *", "User able to Select value from the field Do you undertake construction-building activities? *", "User unable to Select value from the field Do you undertake construction-building activities? *", constBuild);

		//Select value from the field Do you employ sub contractors or independent contractors? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Contractors), "Select value from the field Do you employ subcontractors or independent contractors? *", "User able to Select value from the field Do you employ subcontractors or independent contractors? *", "User unable to Select value from the field Do you employ subcontractors or independent contractors? *", contractors);

		//Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclInsuranceCancel), "Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User able to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User unable to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", declInsuranceCancel);

		//Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousClaim), "Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User able to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User unable to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", declPreviousClaim);

		//Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousAct), "Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "user able to Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "User unable toSelect Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? * ", declPreviousAct);

		//Select value from the field Have you ever suffered any General Liability claim in the past? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclClaimPrevious), "Select value from the field Have you ever suffered any General Liability claim in the past? *", "User able to Select value from the field Have you ever suffered any General Liability claim in the past? *", "User unable to Select value from the field Have you ever suffered any General Liability claim in the past? * ", declClaimPrevious);

		//click on the Get a Quote Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton11), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//Select value from the field Indicate the legal entity type under which you are operating: *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Entity), "Select value from the field Indicate the legal entity type under which you are operating: *", "User able to Select value from the field Indicate the legal entity type under which you are operating: *", "User unable to Select value from the field Indicate the legal entity type under which you are operating: *", entity);

		//Enter the Insured Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_EntityInsuredName), "Enter the Insured Name", "User able to Enter the Insured Name", "user unable Enter the Insured Name", insuredName);

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//		//Click on the accept check box
		//		Thread.sleep(3000);
		//		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Terms), "Click on the accept check box", "User able to Click on the accept check box", "User unable to Click on the accept check box");
		//				
		//		//click on Proceed Button
		//		Thread.sleep(3000);
		//		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton13), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Buy Now button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_CartIcon), "Click on Buy now Button", "User able to Click on Buy Now button", "User unable to click on the Buy Now button");
		Thread.sleep(9000);

	}



	public void keyToProceedB2CSalesApplicationForTacitPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateOrderB2CSalesApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "Product";
		DataSheetRead DataWorkBook = null;
		String entity = "";
		String insuredName = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			entity = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "entity");
			insuredName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredName");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//click on Proceed Button
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton11), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//Select value from the field Indicate the legal entity type under which you are operating: *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Entity), "Select value from the field Indicate the legal entity type under which you are operating: *", "User able to Select value from the field Indicate the legal entity type under which you are operating: *", "User unable to Select value from the field Indicate the legal entity type under which you are operating: *", entity);

		//Enter the Insured Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_EntityInsuredName), "Enter the Insured Name", "User able to Enter the Insured Name", "user unable Enter the Insured Name", insuredName);

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//Click on the accept check box
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Terms), "Click on the accept check box", "User able to Click on the accept check box", "User unable to Click on the accept check box");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Buy Now button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_CartIcon), "Click on Buy now Button", "User able to Click on Buy Now button", "User unable to click on the Buy Now button");
		Thread.sleep(9000);
	}


	public void keyToPaymentB2CSalesApplicationForTacitPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateOrderB2CSalesApplicationPage*******************");
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "Product";
		DataSheetRead DataWorkBook = null;
		String cardNumber="";
		String cVV=""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			cardNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "cardNumber");
			cVV = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "cVV");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close(); 
		}

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Enter card number in Payment Page
		Thread.sleep(8000); 
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='paymentGateway']")));

		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_CardNumber), "Verify that the User is able to enter the Card Details", "User is able to enter the Card Number", "Unable to Enter the Card Number", cardNumber);

		System.out.println("Able to enter card no");
		Thread.sleep(9000);
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_CvvNumber), "Verify that the User is able to enter the Card Details", "User is able to enter the CVV Number", "Unable to Enter the CVV Number", cVV);

		WebElement Month= driver.findElement(By.xpath("//*[@id='UPPFormCardFormExMonth']/option[6]"));
		Month.click();

		WebElement Year= driver.findElement(By.xpath("//*[@id='UPPFormCardFormExYear']/option[5]"));
		Year.click();

		WebElement PayNow = driver.findElement(By.xpath("//*[@id='UPPFormButtonPay']"));
		PayNow.submit();

		//Fetch the Order ID
		String orderID=driver.findElement(GenB2CSales.txt_OrderID).getAttribute("value");
		System.out.println("orderID"+orderID);
	}


	public void keyToCreateOrderB2CSalesApplicationForTacitPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateOrderB2CSalesApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "Product";
		DataSheetRead DataWorkBook = null;
		String inceptionDate = "";
		String goodStanding = "";
		String previousInsurace = "";
		String enOLimits_0__EAOLimit = "";
		String practice="";
		String insuredDetails_0__InsName = "";
		String memebershipNumber= "";
		String employmentType = "";
		String homeInspector="";
		String locationActivites = "";
		String specialtyCheckHeader = "";
		String cGLLimit = "";
		String insuredHoldDesignat ="";
		String insuredOperationschg = "";
		String operationDescription = "";
		String annualSales ="";
		String percentageCanada ="";
		String percentageUS ="";
		String percentageOtherCountries ="";
		String purchaseResell = "";
		String construction="";
		String distribution ="";
		String gasSector="";
		String designBuild = "";
		String constBuild ="";
		String contractors ="";
		String declInsuranceCancel ="";
		String declPreviousClaim = "";
		String declPreviousAct = "";
		String declClaimPrevious = "";
		String entity = "";
		String insuredName = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "inceptionDate");
			goodStanding = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "goodStanding");
			previousInsurace = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "previousInsurace");
			enOLimits_0__EAOLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "EnOLimits_0__EAOLimit");
			practice = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "practice");
			insuredDetails_0__InsName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredDetails_0__InsName");
			memebershipNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "memebershipNumber");
			employmentType = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "EmploymentType");
			homeInspector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "homeInspector");
			locationActivites = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "locationActivites");
			specialtyCheckHeader = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "specialtyCheckHeader");
			cGLLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "cGLLimit");
			insuredHoldDesignat = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredHoldDesignat");
			insuredOperationschg = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredOperationschg");
			operationDescription = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "operationDescription");
			annualSales = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "annualSales");
			percentageCanada = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageCanada");
			percentageUS = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageUS");
			percentageOtherCountries = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageOtherCountries");
			purchaseResell = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "purchaseResell");
			construction = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "construction");
			distribution = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "distribution");
			gasSector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "gasSector");
			designBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "designBuild");
			constBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "constBuild");		
			contractors = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "contractors");
			declInsuranceCancel = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declInsuranceCancel");
			declPreviousClaim = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declPreviousClaim");
			declPreviousAct = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declPreviousAct");
			declClaimPrevious = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declClaimPrevious");
			entity = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "entity");
			insuredName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredName");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on Product tab
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_products), "Clikc on the Product Tab", "User able to create the product tab", "User unable to click on the product tab");
		System.out.println("Product tab is clicked");

		//click on the Get quote for a particular product
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ASTTBCInsurancePackageRenewal_GetaQuote2), "Click on the Required product", "User able to click on the particular Product", "User unable to click on the particular product");

		//Enter the Inception date
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.txt_QuestionsInceptionDate), "Enter the Incpetion Date", "User able to enter the inception Date", "User Unable to enter the Inception date", inceptionDate);
		driver.findElement(GenB2CSales.txt_QuestionsInceptionDate).sendKeys(Keys.TAB);

		//Select Value from the drop down "Are you a Member in good standing with the ASTTBC?*"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_MemberInGoodStanding), "Select Value from Member in Good standing with ASTTBC", "User able to Select Value from Member in Good standing with ASTTBC", "User unable to Select Value from Member in Good standing with ASTTBC", goodStanding);

		//Select value from the drop down Have you previously purchased Professional Liability insurance to cover your ASTTBC related professional practice you are currently applying for?
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PreviousInsurance), "Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", previousInsurace);

		//Select Value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EnOLimits), "Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User abel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User unabel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.",enOLimits_0__EAOLimit);

		//Select Value from the filed Are you applying as an individual for coverage in your own name and are employed by a firm or organization that is not applying for insurance?
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Practice), "Select Value from the dropdown", "user to able to select value from the drop down", "user to able to select value from the drop down",practice);

		//Enter the Value in the field ASTTBC Member Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_InsName), "Enter the ASTTBC Memeber Name ", "User able to Enter the ASTTBC Memeber Name ", "user unbale to Enter the ASTTBC Memeber Name ",insuredDetails_0__InsName );

		//Enter value in the Membership Number field
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_MembershipNo), "Enter value in the Membership Number field", "user able to Enter value in the Membership Number field", "User unable to Enter value in the Membership Number field", memebershipNumber);

		//Select value in the "Your individual revenue amount is" field
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EmploymentType), "Select value in the Your individual revenue amount is field", "User able to Select value in the Your individual revenue amount is field", "User unable to Select value in the Your individual revenue amount is field", employmentType);

		//Select value in the field "Are you a Home Inspector?"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_HomeInspector), "Select value in the field Are you a Home Inspector?", "User able to Select value in the field Are you a Home Inspector?", "User unable to Select value in the field Are you a Home Inspector?", homeInspector);

		//Select Value from the field "Do you perform underground Utility Location activities?*"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_UndLocator), "Select Value from the field Do you perform underground Utility Location activities?*", "User able to Select Value from the field Do you perform underground Utility Location activities?*", "User unable to Select Value from the field Do you perform underground Utility Location activities?*", locationActivites);

		//Select Value from the filed Do you hold a Technical Speciality designation?, if Yes, select all the certifications this applicant holds *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_SpecialtyCheckHeader), "Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "user able to Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "User unable to select Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", specialtyCheckHeader);

		//Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term. *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_CGLLimit), "Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User able to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User unable to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", cGLLimit);

		//Select the value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredHoldDesignat), "Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User able to Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User unable to Are you (or any of the applicants listed before) an AScT or Ctech? *", insuredHoldDesignat);

		//Select the value from the field Have your current activities changed since last renewal?. *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredOperationschg), "Select value from the field Have your current activities changed since last renewal?. *", "User able to Select value from the field Have your current activities changed since last renewal?.", "User unable to Select value from the field Have your current activities changed since last renewal?.", insuredOperationschg);

		//Enter Text value in the Operation Description field
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_OperationDescription), "Enter Text value in the Operation Description field", "User able to Enter Text value in the Operation Description field", "User unable to Enter Text value in the Operation Description field", operationDescription);

		//Enter the Value in the field Annual Sales (in CAD) *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_AnnualSales), "Enter the Value in the field Annual Sales (in CAD) *", "User able to enter the Value in the field Annual Sales (in CAD) *", "User unable to Enter the Value in the field Annual Sales (in CAD) *", annualSales);

		//Enter value in the field Percentage of sales in Canada *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageCanada), "Enter value in the field Percentage of sales in Canada *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Canada *", percentageCanada);

		//Enter value in the field Percentage of sales in US *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageUS), "Enter value in the field Percentage of sales in US *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in US *", percentageUS);

		//Enter value in the field Percentage of sales in Other Countries *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageinOther), "Enter value in the field Percentage of sales in Other Countries *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Other Countries *", percentageOtherCountries);

		//Select Value from the field Do you or any related company purchase and/or resell products? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PurchaseResel), "Select Value from the field Do you or any related company purchase and/or resell products? *", "User able to Select Value from the field Do you or any related company purchase and/or resell products? *", "User unable to Select Value from the field Do you or any related company purchase and/or resell products? *", purchaseResell);

		//Select value from the field Your operations include hands-on work in the areas of construction (including blasting, demolition, underpinning, pile driving, shoring, welding, excavation), installation, maintenance or repairs? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Construction), "Select Value from the Construction field", "User able to Select Value from the Construction field", "User able to Select Value from the Construction field", construction);

		//Select value from the field Your operations include manufacturing, distribution or sale of products *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Distribution), "Select value from the field Your operations include manufacturing, distribution or sale of products *", "User able to Select value from the field Your operations include manufacturing, distribution or sale of products *", "User unable to Select value from the field Your operations include manufacturing, distribution or sale of products *", distribution);

		//Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_GasSector), "Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User able to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User unable to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", gasSector);

		//Select value from the field Do you undertake design-build activities? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DesignBuild), "Select value from the field Do you undertake design-build activities? *", "User able to Select value from the field Do you undertake design-build activities? *", "User unable to Select value from the field Do you undertake design-build activities? *", designBuild);

		//Select value from the field Do you undertake construction-building activities? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_ConstBuild), "Select value from the field Do you undertake construction-building activities? *", "User able to Select value from the field Do you undertake construction-building activities? *", "User unable to Select value from the field Do you undertake construction-building activities? *", constBuild);

		//Select value from the field Do you employ sub contractors or independent contractors? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Contractors), "Select value from the field Do you employ subcontractors or independent contractors? *", "User able to Select value from the field Do you employ subcontractors or independent contractors? *", "User unable to Select value from the field Do you employ subcontractors or independent contractors? *", contractors);

		//Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclInsuranceCancel), "Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User able to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User unable to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", declInsuranceCancel);

		//Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousClaim), "Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User able to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User unable to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", declPreviousClaim);

		//Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousAct), "Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "user able to Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "User unable toSelect Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? * ", declPreviousAct);

		//Select value from the field Have you ever suffered any General Liability claim in the past? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclClaimPrevious), "Select value from the field Have you ever suffered any General Liability claim in the past? *", "User able to Select value from the field Have you ever suffered any General Liability claim in the past? *", "User unable to Select value from the field Have you ever suffered any General Liability claim in the past? * ", declClaimPrevious);

		//click on the Get a Quote Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton11), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//Select value from the field Indicate the legal entity type under which you are operating: *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Entity), "Select value from the field Indicate the legal entity type under which you are operating: *", "User able to Select value from the field Indicate the legal entity type under which you are operating: *", "User unable to Select value from the field Indicate the legal entity type under which you are operating: *", entity);

		//Enter the Insured Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_EntityInsuredName), "Enter the Insured Name", "User able to Enter the Insured Name", "user unable Enter the Insured Name", insuredName);

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton12), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//Click on the accept check box
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Terms), "Click on the accept check box", "User able to Click on the accept check box", "User unable to Click on the accept check box");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton13), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Buy Now button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_CartIcon), "Click on Buy now Button", "User able to Click on Buy Now button", "User unable to click on the Buy Now button");
		Thread.sleep(9000);
	}


	public void keyToBuyB2CSalesApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateOrderB2CSalesApplicationPage*******************");

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on Renewal tab
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_RenewalTab), "Clikc on the Renewal Tab", "User able to click on Renewal tab", "User unable to click on the Renewal tab");
		System.out.println("Renewal tab is clicked");

		//Click on Buy Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Renewal_Buy), "Clikc on the buy button in B2C sales", "User able to click on buy button in B2C sales button", "User not able to click on buy button in B2C sales button");

		//Verify that the user is able to create a Renewal policy for a renewal quote generated bu clicking on 'Buy' button
		if(Implementation.isobjDisplayed(driver.findElement(GenB2CSales.B2CSales_GenerateQuote))){
			NextGenUtilities.appendPass("Verify user able to create renewal policy for a renewal quote generated by clicking Buy button", "user able to create renewal policy for a renewal quote generated by clicking Buy button");
		}else{
			NextGenUtilities.logFailure(driver, "user not able to create renewal policy for a renewal quote generated by clicking Buy button", "user not able to create renewal policy for a renewal quote generated by clicking Buy button");
		}


	}


	public void keyToCreateOrder_ASTTBCInsurancePackageRenewal() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateOrder_ASTTBCInsurancePackageRenewal*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "Product";
		DataSheetRead DataWorkBook = null;
		String inceptionDate = "";
		String goodStanding = "";
		String previousInsurace = "";
		String enOLimits_0__EAOLimit = "";
		String practice="";
		String insuredDetails_0__InsName = "";
		String memebershipNumber= "";
		String employmentType = "";
		String homeInspector="";
		String locationActivites = "";
		String specialtyCheckHeader = "";
		String cGLLimit = "";
		String insuredHoldDesignat ="";
		String insuredOperationschg = "";
		String operationDescription = "";
		String annualSales ="";
		String percentageCanada ="";
		String percentageUS ="";
		String percentageOtherCountries ="";
		String purchaseResell = "";
		String construction="";
		String distribution ="";
		String gasSector="";
		String designBuild = "";
		String constBuild ="";
		String contractors ="";
		String declInsuranceCancel ="";
		String declPreviousClaim = "";
		String declPreviousAct = "";
		String declClaimPrevious = "";
		String entity = "";
		String insuredName = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "inceptionDate");
			goodStanding = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "goodStanding");
			previousInsurace = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "previousInsurace");
			enOLimits_0__EAOLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "EnOLimits_0__EAOLimit");
			practice = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "practice");
			insuredDetails_0__InsName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredDetails_0__InsName");
			memebershipNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "memebershipNumber");
			employmentType = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "EmploymentType");
			homeInspector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "homeInspector");
			locationActivites = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "locationActivites");
			specialtyCheckHeader = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "specialtyCheckHeader");
			cGLLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "cGLLimit");
			insuredHoldDesignat = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredHoldDesignat");
			insuredOperationschg = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredOperationschg");
			operationDescription = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "operationDescription");
			annualSales = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "annualSales");
			percentageCanada = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageCanada");
			percentageUS = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageUS");
			percentageOtherCountries = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "percentageOtherCountries");
			purchaseResell = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "purchaseResell");
			construction = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "construction");
			distribution = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "distribution");
			gasSector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "gasSector");
			designBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "designBuild");
			constBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "constBuild");		
			contractors = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "contractors");
			declInsuranceCancel = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declInsuranceCancel");
			declPreviousClaim = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declPreviousClaim");
			declPreviousAct = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declPreviousAct");
			declClaimPrevious = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "declClaimPrevious");
			entity = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "entity");
			insuredName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "MTA_PSP", "insuredName");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on Product tab
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_products), "Clikc on the Product Tab", "User able to create the product tab", "User unable to click on the product tab");
		System.out.println("Product tab is clicked");

		//click on the Get quote for a particular product
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ASTTBCInsurancePackageRenewal_GetaQuote), "Click on the Required product", "User able to click on the particular Product", "User unable to click on the particular product");

		//Enter the Inception date
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.txt_QuestionsInceptionDate), "Enter the Incpetion Date", "User able to enter the inception Date", "User Unable to enter the Inception date", inceptionDate);
		driver.findElement(GenB2CSales.txt_QuestionsInceptionDate).sendKeys(Keys.TAB);

		//Select Value from the drop down "Are you a Member in good standing with the ASTTBC?*"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_MemberInGoodStanding), "Select Value from Member in Good standing with ASTTBC", "User able to Select Value from Member in Good standing with ASTTBC", "User unable to Select Value from Member in Good standing with ASTTBC", goodStanding);

		//Select value from the drop down Have you previously purchased Professional Liability insurance to cover your ASTTBC related professional practice you are currently applying for?
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PreviousInsurance), "Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", previousInsurace);

		//Select Value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EnOLimits), "Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User abel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User unabel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.",enOLimits_0__EAOLimit);

		//Select Value from the filed Are you applying as an individual for coverage in your own name and are employed by a firm or organization that is not applying for insurance?
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Practice), "Select Value from the dropdown", "user to able to select value from the drop down", "user to able to select value from the drop down",practice);

		//Enter the Value in the field ASTTBC Member Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_InsName), "Enter the ASTTBC Memeber Name ", "User able to Enter the ASTTBC Memeber Name ", "user unbale to Enter the ASTTBC Memeber Name ",insuredDetails_0__InsName );

		//Enter value in the Membership Number field
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_MembershipNo), "Enter value in the Membership Number field", "user able to Enter value in the Membership Number field", "User unable to Enter value in the Membership Number field", memebershipNumber);

		//Select value in the "Your individual revenue amount is" field
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EmploymentType), "Select value in the Your individual revenue amount is field", "User able to Select value in the Your individual revenue amount is field", "User unable to Select value in the Your individual revenue amount is field", employmentType);

		//Select value in the field "Are you a Home Inspector?"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_HomeInspector), "Select value in the field Are you a Home Inspector?", "User able to Select value in the field Are you a Home Inspector?", "User unable to Select value in the field Are you a Home Inspector?", homeInspector);

		//Select Value from the field "Do you perform underground Utility Location activities?*"
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_UndLocator), "Select Value from the field Do you perform underground Utility Location activities?*", "User able to Select Value from the field Do you perform underground Utility Location activities?*", "User unable to Select Value from the field Do you perform underground Utility Location activities?*", locationActivites);

		//Select Value from the filed Do you hold a Technical Speciality designation?, if Yes, select all the certifications this applicant holds *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_SpecialtyCheckHeader), "Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "user able to Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "User unable to select Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", specialtyCheckHeader);

		//Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term. *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_CGLLimit), "Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User able to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User unable to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", cGLLimit);

		//Select the value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredHoldDesignat), "Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User able to Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User unable to Are you (or any of the applicants listed before) an AScT or Ctech? *", insuredHoldDesignat);

		//Select the value from the field Have your current activities changed since last renewal?. *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredOperationschg), "Select value from the field Have your current activities changed since last renewal?. *", "User able to Select value from the field Have your current activities changed since last renewal?.", "User unable to Select value from the field Have your current activities changed since last renewal?.", insuredOperationschg);

		//Enter Text value in the Operation Description field
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_OperationDescription), "Enter Text value in the Operation Description field", "User able to Enter Text value in the Operation Description field", "User unable to Enter Text value in the Operation Description field", operationDescription);

		//Enter the Value in the field Annual Sales (in CAD) *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_AnnualSales), "Enter the Value in the field Annual Sales (in CAD) *", "User able to enter the Value in the field Annual Sales (in CAD) *", "User unable to Enter the Value in the field Annual Sales (in CAD) *", annualSales);

		//Enter value in the field Percentage of sales in Canada *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageCanada), "Enter value in the field Percentage of sales in Canada *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Canada *", percentageCanada);

		//Enter value in the field Percentage of sales in US *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageUS), "Enter value in the field Percentage of sales in US *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in US *", percentageUS);

		//Enter value in the field Percentage of sales in Other Countries *
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageinOther), "Enter value in the field Percentage of sales in Other Countries *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Other Countries *", percentageOtherCountries);

		//Select Value from the field Do you or any related company purchase and/or resell products? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PurchaseResel), "Select Value from the field Do you or any related company purchase and/or resell products? *", "User able to Select Value from the field Do you or any related company purchase and/or resell products? *", "User unable to Select Value from the field Do you or any related company purchase and/or resell products? *", purchaseResell);

		//Select value from the field Your operations include hands-on work in the areas of construction (including blasting, demolition, underpinning, pile driving, shoring, welding, excavation), installation, maintenance or repairs? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Construction), "Select Value from the Construction field", "User able to Select Value from the Construction field", "User able to Select Value from the Construction field", construction);

		//Select value from the field Your operations include manufacturing, distribution or sale of products *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Distribution), "Select value from the field Your operations include manufacturing, distribution or sale of products *", "User able to Select value from the field Your operations include manufacturing, distribution or sale of products *", "User unable to Select value from the field Your operations include manufacturing, distribution or sale of products *", distribution);

		//Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_GasSector), "Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User able to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User unable to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", gasSector);

		//Select value from the field Do you undertake design-build activities? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DesignBuild), "Select value from the field Do you undertake design-build activities? *", "User able to Select value from the field Do you undertake design-build activities? *", "User unable to Select value from the field Do you undertake design-build activities? *", designBuild);

		//Select value from the field Do you undertake construction-building activities? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_ConstBuild), "Select value from the field Do you undertake construction-building activities? *", "User able to Select value from the field Do you undertake construction-building activities? *", "User unable to Select value from the field Do you undertake construction-building activities? *", constBuild);

		//Select value from the field Do you employ sub contractors or independent contractors? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Contractors), "Select value from the field Do you employ subcontractors or independent contractors? *", "User able to Select value from the field Do you employ subcontractors or independent contractors? *", "User unable to Select value from the field Do you employ subcontractors or independent contractors? *", contractors);

		//Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclInsuranceCancel), "Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User able to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User unable to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", declInsuranceCancel);

		//Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousClaim), "Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User able to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User unable to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", declPreviousClaim);

		//Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousAct), "Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "user able to Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "User unable toSelect Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? * ", declPreviousAct);

		//Select value from the field Have you ever suffered any General Liability claim in the past? *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclClaimPrevious), "Select value from the field Have you ever suffered any General Liability claim in the past? *", "User able to Select value from the field Have you ever suffered any General Liability claim in the past? *", "User unable to Select value from the field Have you ever suffered any General Liability claim in the past? * ", declClaimPrevious);

		//click on the Get a Quote Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ProceedButton), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_PolicyInfo_Continue), "Click on continue button Button in policy information screen", "User able to Click on continue button Button in policy information screen", "User unable to click on the Proceed button");

		//Select value from the field Indicate the legal entity type under which you are operating: *
		Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Entity), "Select value from the field Indicate the legal entity type under which you are operating: *", "User able to Select value from the field Indicate the legal entity type under which you are operating: *", "User unable to Select value from the field Indicate the legal entity type under which you are operating: *", entity);

		//Enter the Insured Name
		Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_EntityInsuredName), "Enter the Insured Name", "User able to Enter the Insured Name", "user unable Enter the Insured Name", insuredName);

		//click on Proceed Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_PolicyInfo_Continue), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on the Proceed button");

		//Click on the accept check box
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Terms), "Click on the accept check box", "User able to Click on the accept check box", "User unable to Click on the accept check box");

		//click on Proceed Button
		Thread.sleep(4000);
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Order_Continue), "Click on Proceed Button", "User able to Click on Proceed button", "User unable to click on continue button Button in policy information screen");

		//click on Buy Now button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_CartIcon), "Click on Buy now Button", "User able to Click on Buy Now button", "User unable to click on the Buy Now button");
		Thread.sleep(9000);
	}



	public void keyToBuyB2CSalesApplicationPage1() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateOrderB2CSalesApplicationPage*******************");

		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		//Click on Renewal tab
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_RenewalTab), "Clikc on the Renewal Tab", "User able to click on Renewal tab", "User unable to click on the Renewal tab");
		System.out.println("Renewal tab is clicked");

		//Click on Buy Button
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Renewal_Buy), "Clikc on the buy button in B2C sales", "User able to click on buy button in B2C sales button", "User not able to click on buy button in B2C sales button");

		//Verify that the user is able to create a Renewal policy for a renewal quote generated bu clicking on 'Buy' button
		if(Implementation.isobjDisplayed(driver.findElement(GenB2CSales.B2CSales_GenerateQuote))){
			NextGenUtilities.appendPass("Verify user able to create renewal policy for a renewal quote generated by clicking Buy button", "user able to create renewal policy for a renewal quote generated by clicking Buy button");
		}else{
			NextGenUtilities.logFailure(driver, "user not able to create renewal policy for a renewal quote generated by clicking Buy button", "user not able to create renewal policy for a renewal quote generated by clicking Buy button");
		}


	}

	public void keyToSearchPolicyBulkUploadPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToMAPage*******************");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	

		//Fetch Policy/Plan number
		String policyRefNumber="STDTQA0033";

		//Mouse over on search tab
		Thread.sleep(5000);
		Implementation.MouseOver(driver, AllGeneralTabs.Tab_Search, "Verify mouse over on search tab", "Able to mouse over on search tab", "Unable to mouse over on search tab");

		//Click on Policy
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.SubMenu_Policy), "Verify Click on policy", "Clicked on policy Tab", "Unable to Click on policy Tab");

		//Enter Policy Ref 
		Thread.sleep(5000);
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Policy_ExternalRef, "Enter policy in external ref text box", "Enter policy number into text box area", "Unable to Enter policy number into external ref text box area",policyRefNumber);

		//Click on search button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.Policy_Ref_Search, "Click on search button", "Able to click on search button", "Unable to click on search button");

		//Click on search policy number
		//    			Thread.sleep(3000);
		//    			Implementation.ClickFeild(driver, AllGeneralTabs.Policy_Number, "Click on hyperlink of the policy number", "Able to click on search policy number", "Unable to click on search policy number");

	} 




	public void keyToNBBulkUpoad_MTACustomerCreationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToNBBulkUpoad_MTACustomerCreationPage*******************");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);	
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		String UploadName = ""; 
		String ProcessingType1 = "";


		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			UploadName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "Bulk_Upload", "UploadName");
			ProcessingType1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "Bulk_Upload", "ProcessingType1");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Click on Upload tab
		Implementation.ClickFeild(driver, MTALocators.MTA_BulkUpload_Upload,"Click on Upload tab", "Able to Click on Upload tab","Unable to Click on Upload tab");

		//Click on New upload button
		Implementation.ClickFeild(driver, MTALocators.MTA_BulkUpload_NewUpload, "Click on New Upload button", "Able to Click on New Upload button", "Unable to Click on New Upload button");

		//Select upload name-Customer and Policy
		Thread.sleep(5000);
		Select name2 = new Select(MTALocators.MTA_BulkUpload_UploadName);
		name2.selectByVisibleText(UploadName);

		//Select the processing type-Commit Transaction
		Thread.sleep(5000);
		Select type2 = new Select(MTALocators.MTA_BulkUpload_ProcessingType);
		type2.selectByVisibleText(ProcessingType1);

		//Select the file
		Thread.sleep(3000);
		Implementation.test("C:\\Automation_Suite\\Core_Reg_Suite\\GenAsys\\data\\docstore\\CAT_Aus_CWP_File_TC49.xls"); 

		//Click on Choose File
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTA_BulkUpload_UploadFile), "Click on Choose File", "Able to select the customer and policy file", "Unable to select the customer and policy file");

		//Click on upload button
		Implementation.ClickFeild(driver, MTALocators.MTA_BulkUpload_UploadBtn, "Click on upload button", "Able to click on Click on upload button", "Unable to Click on upload button");
		Thread.sleep(8000); 

		//Verify that the user is able to see the (Status stays with) "Hourglass" icon immediately after uploading bulk upload sheet
		if(Implementation.isobjDisplayed(MTALocators.MTA_BulkUpload_StatusPassed)){
			NextGenUtilities.appendPass("Verify that the user is able to see the (Status stays with) Hourglass icon", "User able to see the Status stays with Hourglass icon after upoading the document");
		}else{
			NextGenUtilities.logFailure(driver, "Verify that the user is not able to see the (Status stays with) Hourglass icon", "User not seeing the Status stays with Hourglass icon after upoading the document");
		}

		//Refresh the page
		driver.navigate().refresh();

		//Verify that the status icon is changed to Tick Mark (Green) after the successful upload
		Thread.sleep(8000); 
		if(Implementation.isobjDisplayed(MTALocators.MTA_BulkUpload_StatusPassed)){
			NextGenUtilities.appendPass("Verify the status icon is changed to tick mark (Green) after the successful upload", "User able to see the status icon is changed to tick mark (Green) after the successful upload");
		}else{
			NextGenUtilities.logFailure(driver, "Verify the status icon is not changed to tick mark (Green) after the successful upload", "status icon is not changing from hourglass to tick mark (Green) after the successful upload doc");
		}

		//Selected file should be uploaded for Customer and Policy Creation action and the new entry should be added under "Upload History" grid
		if(Implementation.isobjDisplayed(MTALocators.NB_BU_CreateNewGrid)){
			NextGenUtilities.appendPass("Validate new entry created under upload history grid", "User able to see newly entry created under upload history grid");
		}else{
			NextGenUtilities.logFailure(driver, "Validate new entry created under upload history grid", "Newly entry is not created under upload history grid after uploading the doc");
		}

		//Validate the status
		if(Implementation.isobjDisplayed(MTALocators.MTA_BulkUpload_StatusPassed)){
			NextGenUtilities.appendPass("Validate the uploaded status", "User able to upload the doc through bulk upload");
		}else{
			NextGenUtilities.logFailure(driver, "Validate the uploaded status", "User not able to upload the doc through bulk upload");
		}

	}


	public void keytoCreatePolicyCATAdminMultiple() throws IOException, InterruptedException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		DataWorkBook = new DataSheetRead(pc_sheet_path);
		String Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Username");
		String Password = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Password");
		String Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "DropDownValue");
		String ProducName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ProducName");
		String ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ExpiryDate");
		String BusinessDes = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "BusinessDes");
		String InterestedParty = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "InterestedParty");
		String State = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "State");
		String LiabilityLimit = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "LiabilityLimit");
		String Category = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Category");
		String Year = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Year");
		String Make = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Make");
		String Model = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Model");
		String SerialNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SerialNo");
		String PinNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "PinNo");
		String SumInsured = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SumInsured");
		String RoadUsed = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "RoadUsed");
		String GPSTracking = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "GPSTracking");
		String CompanyID = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "CompanyID");
		String CompanyName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ComapnyName");
		String Department = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "DepartMent");
		String Addresstype = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressType");
		String AddressLine1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressLine1");
		String City = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "City");
		String Zipcode = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ZipCode");
		String Country = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Country");
		String inceptionDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "inceptionDate");

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

		//Click on Quote Tab
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Select a Product, input is given by Excel
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='"+ProducName+"']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select start date 
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Business Description
		Select Business = new Select(MTALocators.MTAComplex_Quote_Business);
		Business.selectByVisibleText(BusinessDes);

		//Enter Interested Party
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_InterestedParty, "Enter Interested Party", "Able to Enter Interested Party", "Unable to Enter Interested Party", InterestedParty);

		//Select State
		Select state = new Select(MTALocators.MTAComplex_Quote_State);
		state.selectByVisibleText(State);

		//Select 3rd Party Liability Limit
		Select liability = new Select(MTALocators.MTAComplex_Quote_TPLLimit); 
		liability.selectByVisibleText(LiabilityLimit);  

		//Select Category
		Select category = new Select(MTALocators.MTAComplex_Quote_Category);
		category.selectByVisibleText(Category);

		//Enter Year
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Year, "Enter Year", "Able to Enter Year", "Unable to Enter Year", Year);

		//Enter Make
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Make, "Enter Make", "Able to Enter Make", "Unable to Enter Make", Make);

		//Enter Model
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Model, "Enter Model", "Able to Enter Model", "Unable to Enter Model", Model);

		//Enter Serial No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Serial, "Enter serial Number", "ABLE TO Enter Serial Number", "Unable to Enter Serial Number", SerialNo);

		//Enter Pin No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Pin, "Enter Pin Number", "Able to Enter Pin Number", "Unable to Enter Pin Number", PinNo);

		//Enter Sum Insured
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_SumInsured, "Enter Sum Insured", "Able to Enter Sum Insured", "Unable to Enter Sum Insured", SumInsured);

		//Select Reg Road Used
		Select roadused = new Select(MTALocators.MTAComplex_Quote_RegRoadUsed);
		roadused.selectByVisibleText(RoadUsed);

		//Select GPS Tracking
		Select gps = new Select(MTALocators.MTAComplex_Quote_GPSTracking);
		gps.selectByVisibleText(GPSTracking);

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextButton), "Click on Next Button", "Able to Click on Next Button", "Unable to Click on Next Button");

		//Click on Next Button in Quote Summary page
		Implementation.DoubleClick(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button in Quote Summary page", "Able to Click on Next Button in Quote Summary page", "Unable to Click on Next Button in Quote Summary page");

		//Create Customer
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_Quote_CreateCustomer, "Click on Create customer", "Able to click on create customer button in custimer screen", "Not able to click on create customer screen");

		//Input First Name
		Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyName1, "Verify FirstName is entered", "FirstName is entered", "Not able to Input FirstName", CompanyName);

		//Input Family Name
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Department1, "Verify FamilyName is entered", "FamilyName is entered", "FamilyName is NOT entered", Department);
		AllGeneralTabs.Department1.sendKeys(Keys.TAB);

		//Input EmailAddress1
		Implementation.EnterTextFeild(driver, AllGeneralTabs.EmailAddress1, "Verify EmailAddress1 is entered", "Email Address1 is entered", "Email Address1 is NOT entered", Username);
		AllGeneralTabs.EmailAddress1.sendKeys(Keys.TAB);

		//Select the default check
		Implementation.ClickFeild(driver, AllGeneralTabs.EmailAddress_Defualt1, "Verify default check box is present", "User able to select default check box", "User not able to select default check box");

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(GenCustCreation.nextCButton), "Verify Next button is clicked", "Next button is clicked successfully", "Next button is NOT enabled/Clicked");

		//Click on new address
		Implementation.ClickFeild(driver, AllGeneralTabs.NewAddress, "Verify New address tab", "Usr able to click on new address tab", "New address tab is not clickable");

		//Select Address Type
		Select AddressTypeDD=new Select(driver.findElement(GenCustCreation.AddressType1));
		AddressTypeDD.selectByVisibleText(Addresstype);

		//Enter Address Line1
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.AddressLine11), "Verify AddressLine1 is entered", "Address Line1 is entered", "Address Line1 is NOT entered", AddressLine1);

		//Enter City
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.City1), "Verify City is Entered", "City is Entered", "City is NOT entered", City);

		//Enter ZIP Code
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.ZIPCode1), "Verify ZIPCode is entered", "ZIPCode is Entered", "ZIPCode is NOT Entered", Zipcode);

		//Enter Country
		Select CountryDD=new Select(driver.findElement(GenCustCreation.Country1));
		CountryDD.selectByVisibleText(Country);

		//Click Address Save Button
		Implementation.ClickFeild(driver,driver.findElement(GenCustCreation.AddressSaveButton1), "Verify Address Save Button is clicke", "Address Save button is clicke", "Address Save button is NOT Enabled/Clicked");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on Create Policy button", "Able to click", "Unable to click");

		//Select Yes Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_CreatePolicy_Yes1), "Select Yes Button", "Able to select yes button", "Unable to select yse button");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click", "Unable to click");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.btn_createPolicy1),"Click on Next Button", "Able to click next button in summary", "Unable to click next button in summary");

		//Fetch Policy/Plan number s
		String policyNumberCAT=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+policyNumberCAT);
	}

	public void keyToCreatePolicyCAT() throws IOException, InterruptedException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		DataWorkBook = new DataSheetRead(pc_sheet_path);
		String Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Username");
		String ProducName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ProducName");
		String ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ExpiryDate");
		String BusinessDes = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "BusinessDes");
		String InterestedParty = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "InterestedParty");
		String State = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "State");
		String LiabilityLimit = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "LiabilityLimit");
		String Category = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Category");
		String Year = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Year");
		String Make = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Make");
		String Model = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Model");
		String SerialNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SerialNo");
		String PinNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "PinNo");
		String SumInsured = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SumInsured");
		String RoadUsed = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "RoadUsed");
		String GPSTracking = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "GPSTracking");
		String CompanyID = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "CompanyID");
		String CompanyName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ComapnyName");
		String Department = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "DepartMent");
		String Addresstype = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressType");
		String AddressLine1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressLine1");
		String City = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "City");
		String Zipcode = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ZipCode");
		String Country = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Country");
		String inceptionDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "inceptionDate");

		//Click on Quote Tab
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Select a Product, input is given by Excel
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='"+ProducName+"']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select start date 
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Business Description
		Select Business = new Select(MTALocators.MTAComplex_Quote_Business);
		Business.selectByVisibleText(BusinessDes);

		//Enter Interested Party 
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_InterestedParty, "Enter Interested Party", "Able to Enter Interested Party", "Unable to Enter Interested Party", InterestedParty);

		//Select State
		Select state = new Select(MTALocators.MTAComplex_Quote_State);
		state.selectByVisibleText(State);

		//Select 3rd Party Liability Limit
		Select liability = new Select(MTALocators.MTAComplex_Quote_TPLLimit); 
		liability.selectByVisibleText(LiabilityLimit);  

		//Select Category
		Select category = new Select(MTALocators.MTAComplex_Quote_Category);
		category.selectByVisibleText(Category);

		//Enter Year
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Year, "Enter Year", "Able to Enter Year", "Unable to Enter Year", Year);

		//Enter Make
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Make, "Enter Make", "Able to Enter Make", "Unable to Enter Make", Make);

		//Enter Model
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Model, "Enter Model", "Able to Enter Model", "Unable to Enter Model", Model);

		//Enter Serial No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Serial, "Enter serial Number", "ABLE TO Enter Serial Number", "Unable to Enter Serial Number", SerialNo);

		//Enter Pin No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Pin, "Enter Pin Number", "Able to Enter Pin Number", "Unable to Enter Pin Number", PinNo);

		//Enter Sum Insured
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_SumInsured, "Enter Sum Insured", "Able to Enter Sum Insured", "Unable to Enter Sum Insured", SumInsured);

		//Select Reg Road Used
		Select roadused = new Select(MTALocators.MTAComplex_Quote_RegRoadUsed);
		roadused.selectByVisibleText(RoadUsed);

		//Select GPS Tracking
		Select gps = new Select(MTALocators.MTAComplex_Quote_GPSTracking);
		gps.selectByVisibleText(GPSTracking);

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextButton), "Click on Next Button", "Able to Click on Next Button", "Unable to Click on Next Button");

		//Click on Next Button in Quote Summary page
		Implementation.DoubleClick(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button in Quote Summary page", "Able to Click on Next Button in Quote Summary page", "Unable to Click on Next Button in Quote Summary page");

		//Create Customer
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_Quote_CreateCustomer, "Click on Create customer", "Able to click on create customer button in custimer screen", "Not able to click on create customer screen");

		//Input First Name
		Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyName1, "Verify FirstName is entered", "FirstName is entered", "Not able to Input FirstName", CompanyName);

		//Input Family Name
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Department1, "Verify FamilyName is entered", "FamilyName is entered", "FamilyName is NOT entered", Department);
		AllGeneralTabs.Department1.sendKeys(Keys.TAB);

		//Input EmailAddress1
		Implementation.EnterTextFeild(driver, AllGeneralTabs.EmailAddress1, "Verify EmailAddress1 is entered", "Email Address1 is entered", "Email Address1 is NOT entered", Username);
		AllGeneralTabs.EmailAddress1.sendKeys(Keys.TAB);

		//Select the default check
		Implementation.ClickFeild(driver, AllGeneralTabs.EmailAddress_Defualt1, "Verify default check box is present", "User able to select default check box", "User not able to select default check box");

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(GenCustCreation.nextCButton), "Verify Next button is clicked", "Next button is clicked successfully", "Next button is NOT enabled/Clicked");

		//Click on new address
		Implementation.ClickFeild(driver, AllGeneralTabs.NewAddress, "Verify New address tab", "Usr able to click on new address tab", "New address tab is not clickable");

		//Select Address Type
		Select AddressTypeDD=new Select(driver.findElement(GenCustCreation.AddressType1));
		AddressTypeDD.selectByVisibleText(Addresstype);

		//Enter Address Line1
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.AddressLine11), "Verify AddressLine1 is entered", "Address Line1 is entered", "Address Line1 is NOT entered", AddressLine1);

		//Enter City
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.City1), "Verify City is Entered", "City is Entered", "City is NOT entered", City);

		//Enter ZIP Code
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.ZIPCode1), "Verify ZIPCode is entered", "ZIPCode is Entered", "ZIPCode is NOT Entered", Zipcode);

		//Enter Country
		//Select CountryDD=new Select(driver.findElement(GenCustCreation.Country1));
		//CountryDD.selectByVisibleText(Country);

		//Click Address Save Button
		Implementation.ClickFeild(driver,driver.findElement(GenCustCreation.AddressSaveButton1), "Verify Address Save Button is clicke", "Address Save button is clicke", "Address Save button is NOT Enabled/Clicked");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on Create Policy button", "Able to click", "Unable to click");

		//Select Yes Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_CreatePolicy_Yes1), "Select Yes Button", "Able to select yes button", "Unable to select yse button");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click", "Unable to click");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.btn_createPolicy1),"Click on Next Button", "Able to click next button in summary", "Unable to click next button in summary");

		//Fetch Policy/Plan number s
		String policyNumberCAT=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+policyNumberCAT);
	}


	public void keytoCreatePolicyCATB2Bsingle() throws IOException, InterruptedException

	{
		try{


			Properties name = loadPropertyFile("PC_Path");
			String pc_sheet_path =  name.getProperty("pc_sheet_path");
			String pc_sheet_name_ShakeDown =  "Product";
			DataSheetRead DataWorkBook = null;
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			String Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "Username");
			String Password = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "Password");
			String Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "DropDownValue");
			String ProducName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "ProducName");
			String ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "ExpiryDate");
			String BusinessDes = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "BusinessDes");
			String InterestedParty = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "InterestedParty");
			String State = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "State");
			String LiabilityLimit = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "LiabilityLimit");
			String Category = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "Category");
			String Year = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "Year");
			String Make = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "Make");
			String Model = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "Model");
			String SerialNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "SerialNo");
			String PinNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "PinNo");
			String SumInsured = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "SumInsured");
			String RoadUsed = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "RoadUsed");
			String GPSTracking = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "GPSTracking");
			String CompanyID = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "CompanyID");
			String CompanyName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "ComapnyName");
			String Department = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "DepartMent");
			String Addresstype = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "AddressType");
			String AddressLine1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "AddressLine1");
			String City = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "City");
			String Zipcode = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "ZipCode");
			String Country = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "Country");
			String inceptionDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complexb2b", "inceptionDate");

			//Enter User name in Login page
			//driver.get(clientName);

			Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Enter username in text box","User able to enter username in client module", "Unable to enter username in client module",Username);

			//Enter Password in Login Page 
			Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Enter password in text box","User able to enter password", "Unable to enter password in client module",Password);

			//click on login Page
			Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Click on login button","User able to clicked on Login button successfully", "Unable to click on Login button");

			//Select drop down sponsor
			Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
			dropdown.selectByVisibleText(Sponsordropdownvalue);

			//Click on select button after selecting as new sponsor
			Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Select sponsor from drop down", "User able select sponsor from drop down", "User not able select sponsor from drop down in client module");

			//Click on Quote Tab
			Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Click on Quote Tab", "User able to click on quote tab", "Unable to click on quote tab");

			//enter Inception Date
			Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_inception), "Enter Inception Date", "User able to enter inception Date", "User unable to enter the inception date", inceptionDate);
			driver.findElement(AllGeneralTabs.date_inception).sendKeys(Keys.ENTER);
			Thread.sleep(3000);

			//Select a Product, input is given by Excel
			Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='"+ProducName+"']")), "Click on Product in product screen", "User able to click on Product in product screen", "User not able to click on Product in product screen");

			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("scroll(0, 1000);");

			Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Click on next button", "User able to click on next button", "User not able to click on next button");

			//Select Expiry Date
			Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Select expiry date date", "User able to click on expiry date field as expected","Expiry date field is not clickable");

			//Select start date 
			Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to select on start date pick box", "Start date picke box is not clickable", ExpiryDate);
			MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

			//Select Business Description
			Select Business = new Select(MTALocators.MTAComplex_Quote_Business);
			Business.selectByVisibleText(BusinessDes);

			//Enter Interested Party
			Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_InterestedParty, "Enter Interested Party", "Able to enter interested party", "Unable to enter interested party", InterestedParty);

			//Select State
			Select state = new Select(MTALocators.MTAComplex_Quote_State);
			state.selectByVisibleText(State);

			//Select 3rd Party Liability Limit
			Select liability = new Select(MTALocators.MTAComplex_Quote_TPLLimit); 
			liability.selectByVisibleText(LiabilityLimit);  

			//Select Category
			Select category = new Select(MTALocators.MTAComplex_Quote_Category);
			category.selectByVisibleText(Category);

			//Enter Year
			Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Year, "Enter quote year for first group", "User able to enter quote year for first group", "Unable to enter year for first group", Year);

			//Enter Make
			Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Make, "Enter quote make for first group", "Able to enter Make for first group", "Unable to enter Make for first group", Make);

			//Enter Model
			Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Model, "Enter quote model", "User able to enter Model for first group", "Unable to enter Model for first group", Model);

			//Enter Serial No
			Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Serial, "Enter serial Number", "User able to enter Serial Number for first group", "Unable to enter serial number for first group", SerialNo);

			//Enter Pin No
			Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Pin, "Enter pin number", "User able to enter pin number for first group", "Unable to enter pin number for first group", PinNo);

			//Enter Sum Insured
			Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_SumInsured, "Enter Sum Insured", "User able to enter sum insured", "Unable to enter sum insured", SumInsured);

			//Select Reg Road Used
			Select roadused = new Select(MTALocators.MTAComplex_Quote_RegRoadUsed);
			roadused.selectByVisibleText(RoadUsed);

			//Select GPS Tracking
			Select gps = new Select(MTALocators.MTAComplex_Quote_GPSTracking);
			gps.selectByVisibleText(GPSTracking);

			//Click on Next Button
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextButton), "Click on Next Button", "Able to Click on Next Button", "Unable to Click on Next Button");

			Implementation.DoubleClick(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button in Quote Summary page", "Able to Click on Next Button in Quote Summary page", "Unable to Click on Next Button in Quote Summary page");

			//Create Customer
			Implementation.ClickFeild(driver, MTALocators.MTAComplex_Quote_CreateCustomer, "Click on Create customer", "Able to click on create customer button in custimer screen", "Not able to click on create customer screen");

			//Input First Name
			Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyName1, "Enter first name in text field", "User able to enter first name", "Not able to Input FirstName", CompanyName);

			//Input Family Name
			Implementation.EnterTextFeild(driver, AllGeneralTabs.Department1, "Enter family name", "User able to enter family name", "Uanble to enterd family name", Department);
			AllGeneralTabs.Department1.sendKeys(Keys.TAB);

			//Input EmailAddress1
			Implementation.EnterTextFeild(driver, AllGeneralTabs.EmailAddress1, "Enter email address", "Email address is entered", "Email address is not entered", Username);
			AllGeneralTabs.EmailAddress1.sendKeys(Keys.TAB);

			//Select the default check
			Implementation.ClickFeild(driver, AllGeneralTabs.EmailAddress_Defualt1, "Verify default check box is present", "User able to select default check box", "User not able to select default check box");

			//Click on Next Button
			Implementation.ClickFeild(driver, driver.findElement(GenCustCreation.nextCButton), "Verify Next button is clicked", "Next button is clicked successfully", "Next button is not enabled/Clicked");

			//Click on new address
			Implementation.ClickFeild(driver, AllGeneralTabs.NewAddress, "Verify New address tab", "Usr able to click on new address tab", "New address tab is not clickable");

			//Select Address Type
			Select AddressTypeDD=new Select(driver.findElement(GenCustCreation.AddressType1)); 
			AddressTypeDD.selectByVisibleText(Addresstype);

			//Enter Address Line1
			Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.AddressLine11), "Enter address line 1", "Address Line 1 is entered", "Address line 1 is not entered as expected", AddressLine1);

			//Enter City
			Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.City1), "Enter city", "User able to enter city name", "Uanble to enter city in text field area", City);

			//Enter ZIP Code
			Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.ZIPCode1), "Enter zip code", "User able to enter zipcode in text field area", "Uanble to enter zipcode in text field area", Zipcode);

			//			//Enter Country
			//			Select CountryDD=new Select(driver.findElement(GenCustCreation.Country1));
			//			CountryDD.selectByVisibleText(Country);

			//Click Address Save Button
			Implementation.ClickFeild(driver,driver.findElement(GenCustCreation.AddressSaveButton1), "Address Save Button is clicke", "Address Save button is clicke", "Address Save button is NOT Enabled/Clicked");

			//Click on Create Policy
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on create policy button", "Able to click create policy button", "Unable to click on create policy button");

			//Select Yes Button 
			Thread.sleep(5000);
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_CreatePolicy_Yes1), "Select yes button", "Able to select yes button", "Unable to select yse button");

			//Click on Create Policy
			Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on next button", "Able to click on next button", "Unable to click on next button");

			//Click on Create Policy
			Implementation.ClickFeild(driver,driver.findElement(MTALocators.btn_createPolicy1),"Click on Next Button", "Able to click on next button in summary", "Unable to click next button in summary");

			//Fetch Policy/Plan number
			policyNumberCAT=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
			System.out.println("Plan/Plocy number is created "+policyNumberCAT);

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}


	public void keyToCreatePolicyFactoring() throws InterruptedException, IOException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "JDChina";
		DataSheetRead DataWorkBook = null;
		DataWorkBook = new DataSheetRead(pc_sheet_path);
		String username = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "username");
		String password = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "password");
		String sponsor = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "Sponsor");
		String expiryDate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "expiryDate");
		String dealerName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "dealerName");
		String modelNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "modelNumber");
		String pinNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "pinNumber");
		String insuredAmount = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "insuredAmount");
		String equipmentInfo = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "equipmentInfo");
		String parRate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "parRate");
		String tplAmount = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "tplAmount");
		String tplResponse = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "tplResponse");
		String customerIdentifier = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "customerIdentifier");
		String inceptionDate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "PolicyCreateFactor", "inceptionDate");

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver,driver.findElement(AllGeneralTabs.txt_UsernameClient1),"Verify user name text box","User able to Enter Username", "Unable to Enter Username",username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver,driver.findElement(AllGeneralTabs.txt_PasswordClient1),"Verify the password text box","User able to Enter Password", "Unable to Enter Password",password);

		//click on login Page
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btn_LoginClient1),"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");
		Thread.sleep(5000);

		//Select drop down sponsor
		Implementation.selectDropdown(driver, driver.findElement(AllGeneralTabs.cmb_select_sponsorClient1), "Select Sponsor", "User able to select the sponsor", "User unable to select the sponsor", sponsor);

		//Click on select button after selecting as new sponsor
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btn_selectClient1),"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

		//click on Quote tab
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify mouse over on search tab", "Able to mouse over on search tab", "Unable to mouse over on search tab");

		//enter Inception Date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_inception), "Enter Inception Date", "User able to enter inception Date", "User unable to enter the inception date", inceptionDate);
		driver.findElement(AllGeneralTabs.date_inception).sendKeys(Keys.ENTER);
		Thread.sleep(3000);

		//Select the product and click next
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.product_factoring), "Click on the Financing Product", "User able to click on the Financing Product", "User unable to click on the financing product");

		//Click on next button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next),"Click on the next button" , "User able to click on the Next button	", "User unable to click on the next button");

		//Enter expiry Date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_expiry), "Enter Policy expiry date", "User able to enter the Policy Expiry date", "User unable to enter the Policy Expiry date", expiryDate);
		Thread.sleep(3000);

		//Enter Dealer Name
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.txt_dealerNamefact), "Enter the Dealer Name", "User able to enter the dealer name", "User unable to enter the dealer name", dealerName);

		//Select Product name from the Drop down
		Select dropdown = new Select(driver.findElement(AllGeneralTabs.dd_productNamefact));
		dropdown.selectByIndex(2);

		//Enter Model Number
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.dd_modelNumberfact), "Enter Model Number", "User able to enter the Model Number", "User unable to enter the Model number", modelNumber);

		//Enter Pin number
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.txt_pinNumberfact), "Enter Pin Number", "User able to enter the Pin Number", "User unable to enter the Pin number", pinNumber);

		//Enter the Insured Amount 
		Implementation.EnterTextFeild(driver,  driver.findElement(AllGeneralTabs.txt_InsuredAmountfact), "Enter Insured amount", "User able to enter the Insured amount", "User unable to enter the Insured amount", insuredAmount);

		//Enter the Equipment Information
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.txt_locofMachinefact), "Enter Equipment information", "User able to enter the euqipment information", "User unable to enter the equipment information", equipmentInfo);

		//Select PAR Rate from the Drop down
		Implementation.selectDropdown(driver, driver.findElement(AllGeneralTabs.dd_parRatefact), "Select the PAR Rate value", "User able to select the PAR Rate value", "User unable to select the PAR Rate value", parRate);

		//Choose value from the Driver Liability drop down
		Select dropdown1 = new Select(driver.findElement(AllGeneralTabs.dd_driverLiabilityfact));
		dropdown1.selectByValue("1");;

		//Select Value from the TPL amount drop down
		Implementation.selectDropdown(driver, driver.findElement(AllGeneralTabs.dd_tplAmountfact), "Select Value from the TPL amount drop down", "User able to Select Value from the TPL amount drop down", "User unable to Select Value from the TPL amount drop down", tplAmount);
		Thread.sleep(3000);

		//Select Value from the drop down
		Implementation.selectDropdown(driver, driver.findElement(AllGeneralTabs.dd_tplAmount100000fact), "Select Value from the TPL amount resposne drop down", "User able to Select Value from the TPL amount response drop down", "User unable to Select Value from the TPL amount response drop down", tplResponse);
		Thread.sleep(3000);

		//Click on the next button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btn_next), "Click on next Button", "User able to click on the next button", "User unable to click on the next button");
		Thread.sleep(5000);

		WebDriverWait wait = new WebDriverWait(driver, 20);

		WebElement element = wait.until(ExpectedConditions.visibilityOf(driver.findElement(AllGeneralTabs.txt_totalGrossPremium)));

		//Click on the next button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btn_next1), "Click on next Button", "User able to click on the next button", "User unable to click on the next button");

		//Enter Value in the search text box
		Implementation.EnterTextFeild(driver,driver.findElement(AllGeneralTabs.txt_search), "Enter Value in the Customer Search text box ", "User able to enter value in the Customer Search text box", "User unable to enter value in the Customer Search text box",customerIdentifier);

		//Click on Search Button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btn_search), "Click on the Search button", "User able to click on the search button", "User unable to click on the search button");

		//Click on the first search result 
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.lnk_customerSearch), "Click on the First Search result link", "User able to Click on the First Search result link", "User unable to Click on the First Search result link");

		//Click on Create Policy Button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btn_createPolicy), "Click on Create Policy Button", "User able to click on the Create Policy button", "User unable to click on the Create Policy button");
		Thread.sleep(5000);

		//Click on Create Policy Button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btn_createPolicy), "Click on Create Policy Button", "User able to click on the Create Policy button", "User unable to click on the Create Policy button");
		Thread.sleep(5000);

		//Get Policy Number  and display
		policyNumberFact = driver.findElement(AllGeneralTabs.txt_policyNumber).getAttribute("value");
		System.out.println("The Policy Number is "+policyNumberFact);
	}


	public  void changeRefferedToQuoteTacitConfig() throws InterruptedException, IOException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "B2CSale";
		DataSheetRead DataWorkBook = null;
		String homeInspector="";


		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			homeInspector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalreferral", "homeInspector");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}
		finally{
			DataWorkBook.close();

			//Select value in the field "Are you a Home Inspector?"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_HomeInspector), "Select value in the field Are you a Home Inspector?", "User able to Select value in the field Are you a Home Inspector?", "User unable to Select value in the field Are you a Home Inspector?", homeInspector);

			//click on the Get a Quote Button
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");
			Thread.sleep(8000);

			//Click on save button
			Thread.sleep(5000); 
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Save_QuoteBtn), "Click on save quote button", "User able to Click on save quote button in B2C", "User not able to Click on save quote button in B2C");

			//Click on close the pop up 
			Thread.sleep(5000); 
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2C_Closed_Popup), "Click on closed symbol", "User able to Click on closed symbol in B2C", "User not able to Click on closed symbol in B2C");

			//Verify the Status as Quote
			Thread.sleep(9200); 
			if(Implementation.isobjDisplayed(MTALocators.Policy_Renewal_Status_Quote)){
				NextGenUtilities.appendPass("Verify renewal quote is generated automatically for a B2C sales parent Policy", "User able to renewal quote is generated automatically for a B2C sales parent Policy in policy renewal screen");
			}else{
				NextGenUtilities.logFailure(driver, "Renewal quote is not generated automatically for a B2C sales parent Policy in policy renewal screen", "Renewal quote is not generated automatically for a B2C sales parent Policy in policy renewal screen");
			}


		}

	}



	public  void createPolicyASTTBCRenewalQuoteTacitConfig() throws InterruptedException, IOException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "B2CSale";
		DataSheetRead DataWorkBook = null;
		String username ="";
		String password="";
		String inceptionDate = "";
		String goodStanding = "";
		String previousInsurace = ""; 
		String enOLimits_0__EAOLimit = "";
		String practice="";
		String insuredDetails_0__InsName = "";
		String memebershipNumber= "";
		String employmentType = "";
		String homeInspector="";
		String locationActivites = "";
		String specialtyCheckHeader = "";
		String cGLLimit = "";
		String insuredHoldDesignat ="";
		String insuredOperationschg = "";
		String operationDescription = "";
		String annualSales ="";
		String percentageCanada ="";
		String percentageUS ="";
		String percentageOtherCountries ="";
		String purchaseResell = "";
		String construction="";
		String distribution ="";
		String gasSector="";
		String designBuild = "";
		String constBuild ="";
		String contractors ="";
		String declInsuranceCancel ="";
		String declPreviousClaim = "";
		String declPreviousAct = "";
		String declClaimPrevious = "";
		String entity = "";
		String insuredName = "";
		String cardNumber="";
		String cVV="";
		String specialityOthers = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			username = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "username");
			password = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "password");
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "inceptionDate");
			goodStanding = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "goodStanding");
			previousInsurace = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "previousInsurace");
			enOLimits_0__EAOLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "EnOLimits_0__EAOLimit");
			practice = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "practice");
			insuredDetails_0__InsName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "insuredDetails_0__InsName");
			memebershipNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "memebershipNumber");
			employmentType = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "EmploymentType");
			homeInspector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalreferral", "homeInspector");
			locationActivites = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "locationActivites");
			specialtyCheckHeader = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "specialtyCheckHeader");
			cGLLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "cGLLimit");
			insuredHoldDesignat = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "insuredHoldDesignat");
			insuredOperationschg = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "insuredOperationschg");
			operationDescription = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "operationDescription");
			annualSales = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "annualSales");
			percentageCanada = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "percentageCanada");
			percentageUS = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "percentageUS");
			percentageOtherCountries = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "percentageOtherCountries");
			purchaseResell = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "purchaseResell");
			construction = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "construction");
			distribution = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "distribution");
			gasSector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "gasSector");
			designBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "designBuild");
			constBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "constBuild");              
			contractors = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "contractors");
			declInsuranceCancel = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declInsuranceCancel");
			declPreviousClaim = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declPreviousClaim");
			declPreviousAct = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declPreviousAct");
			declClaimPrevious = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declClaimPrevious");
			entity = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "entity");
			insuredName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "insuredName");
			cardNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "cardNumber");
			cVV = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "cVV");
			specialityOthers = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "specialityOthers");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}
		finally{
			DataWorkBook.close();

			//Click on Product tab
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_products), "Clikc on the Product Tab", "User able to create the product tab", "User unable to click on the product tab");
			System.out.println("Product tab is clicked");

			//click on the Get quote for a particular product
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_ASTTBCInsurancePackageRenewal_GetaQuote), "Click on the Required product", "User able to click on the particular Product", "User unable to click on the particular product");
			System.out.println("Product is clicked");

			//Select Value from the drop down "Are you a Member in good standing with the ASTTBC?*"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_MemberInGoodStanding), "Select Value from Member in Good standing with ASTTBC", "User able to Select Value from Member in Good standing with ASTTBC", "User unable to Select Value from Member in Good standing with ASTTBC", goodStanding);

			//Select value from the drop down Have you previously purchased Professional Liability insurance to cover your ASTTBC related professional practice you are currently applying for?
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PreviousInsurance), "Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", previousInsurace);

			//Select Value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EnOLimits), "Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User abel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User unabel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.",enOLimits_0__EAOLimit);

			//Select Value from the filed Are you applying as an individual for coverage in your own name and are employed by a firm or organization that is not applying for insurance?
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Practice), "Select Value from the dropdown", "user to able to select value from the drop down", "user to able to select value from the drop down",practice);

			//Enter the Value in the field ASTTBC Member Name
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_InsName), "Enter the ASTTBC Memeber Name ", "User able to Enter the ASTTBC Memeber Name ", "user unbale to Enter the ASTTBC Memeber Name ",insuredDetails_0__InsName );

			//Enter value in the Membership Number field
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_MembershipNo), "Enter value in the Membership Number field", "user able to Enter value in the Membership Number field", "User unable to Enter value in the Membership Number field", memebershipNumber);

			//Select value in the "Your individual revenue amount is" field
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EmploymentType), "Select value in the Your individual revenue amount is field", "User able to Select value in the Your individual revenue amount is field", "User unable to Select value in the Your individual revenue amount is field", employmentType);

			//Select value in the field "Are you a Home Inspector?"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_HomeInspector), "Select value in the field Are you a Home Inspector?", "User able to Select value in the field Are you a Home Inspector?", "User unable to Select value in the field Are you a Home Inspector?", homeInspector);

			//Select Value from the field "Do you perform underground Utility Location activities?*"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_UndLocator), "Select Value from the field Do you perform underground Utility Location activities?*", "User able to Select Value from the field Do you perform underground Utility Location activities?*", "User unable to Select Value from the field Do you perform underground Utility Location activities?*", locationActivites);

			//Select Value from the filed Do you hold a Technical Speciality designation?, if Yes, select all the certifications this applicant holds *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_SpecialtyCheckHeader), "Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "user able to Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "User unable to select Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", specialtyCheckHeader);

			//Click on the Others Check box for speciality check 
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.chkBox_SpecialityOthers), "Click on the Others Check box for speciality check ", "User able to Click on the Others Check box for speciality check ", "User unable to Click on the Others Check box for speciality check ");

			//Enter details in the field Describe other ASTTBC designations speciality
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.txt_SpecialityOthers), "Enter details in the field Describe other ASTTBC designations speciality", "User able to Enter details in the field Describe other ASTTBC designations speciality", "User unable to enter details in the field Describe other ASTTBC designations speciality", specialityOthers);

			//Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term. *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_CGLLimit), "Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User able to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User unable to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", cGLLimit);

			//Select the value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredHoldDesignat), "Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User able to Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User unable to Are you (or any of the applicants listed before) an AScT or Ctech? *", insuredHoldDesignat);

			//Select the value from the field Have your current activities changed since last renewal?. *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredOperationschg), "Select value from the field Have your current activities changed since last renewal?. *", "User able to Select value from the field Have your current activities changed since last renewal?.", "User unable to Select value from the field Have your current activities changed since last renewal?.", insuredOperationschg);

			//Enter Text value in the Operation Description field
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_OperationDescription), "Enter Text value in the Operation Description field", "User able to Enter Text value in the Operation Description field", "User unable to Enter Text value in the Operation Description field", operationDescription);

			//Enter the Value in the field Annual Sales (in CAD) *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_AnnualSales), "Enter the Value in the field Annual Sales (in CAD) *", "User able to enter the Value in the field Annual Sales (in CAD) *", "User unable to Enter the Value in the field Annual Sales (in CAD) *", annualSales);

			//Enter value in the field Percentage of sales in Canada *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageCanada), "Enter value in the field Percentage of sales in Canada *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Canada *", percentageCanada);

			//Enter value in the field Percentage of sales in US *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageUS), "Enter value in the field Percentage of sales in US *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in US *", percentageUS);

			//Enter value in the field Percentage of sales in Other Countries *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageinOther), "Enter value in the field Percentage of sales in Other Countries *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Other Countries *", percentageOtherCountries);

			//Select Value from the field Do you or any related company purchase and/or resell products? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PurchaseResel), "Select Value from the field Do you or any related company purchase and/or resell products? *", "User able to Select Value from the field Do you or any related company purchase and/or resell products? *", "User unable to Select Value from the field Do you or any related company purchase and/or resell products? *", purchaseResell);

			//Select value from the field Your operations include hands-on work in the areas of construction (including blasting, demolition, underpinning, pile driving, shoring, welding, excavation), installation, maintenance or repairs? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Construction), "Select Value from the Construction field", "User able to Select Value from the Construction field", "User able to Select Value from the Construction field", construction);

			//Select value from the field Your operations include manufacturing, distribution or sale of products *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Distribution), "Select value from the field Your operations include manufacturing, distribution or sale of products *", "User able to Select value from the field Your operations include manufacturing, distribution or sale of products *", "User unable to Select value from the field Your operations include manufacturing, distribution or sale of products *", distribution);

			//Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_GasSector), "Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User able to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User unable to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", gasSector);

			//Select value from the field Do you undertake design-build activities? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DesignBuild), "Select value from the field Do you undertake design-build activities? *", "User able to Select value from the field Do you undertake design-build activities? *", "User unable to Select value from the field Do you undertake design-build activities? *", designBuild);

			//Select value from the field Do you undertake construction-building activities? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_ConstBuild), "Select value from the field Do you undertake construction-building activities? *", "User able to Select value from the field Do you undertake construction-building activities? *", "User unable to Select value from the field Do you undertake construction-building activities? *", constBuild);

			//Select value from the field Do you employ subcontractors or independent contractors? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Contractors), "Select value from the field Do you employ subcontractors or independent contractors? *", "User able to Select value from the field Do you employ subcontractors or independent contractors? *", "User unable to Select value from the field Do you employ subcontractors or independent contractors? *", contractors);

			//Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclInsuranceCancel), "Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User able to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User unable to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", declInsuranceCancel);

			//Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousClaim), "Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User able to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User unable to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", declPreviousClaim);

			//Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousAct), "Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "user able to Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "User unable toSelect Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? * ", declPreviousAct);

			//Select value from the field Have you ever suffered any General Liability claim in the past? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclClaimPrevious), "Select value from the field Have you ever suffered any General Liability claim in the past? *", "User able to Select value from the field Have you ever suffered any General Liability claim in the past? *", "User unable to Select value from the field Have you ever suffered any General Liability claim in the past? * ", declClaimPrevious);

			//click on the Get a Quote Button
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");
			Thread.sleep(8000);
		}
	}



	public  void createPolicyASTTBCRenewalQuote() throws InterruptedException, IOException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "B2CSale";
		DataSheetRead DataWorkBook = null;
		String username ="";
		String password="";
		String inceptionDate = "";
		String goodStanding = "";
		String previousInsurace = ""; 
		String enOLimits_0__EAOLimit = "";
		String practice="";
		String insuredDetails_0__InsName = "";
		String memebershipNumber= "";
		String employmentType = "";
		String homeInspector="";
		String locationActivites = "";
		String specialtyCheckHeader = "";
		String cGLLimit = "";
		String insuredHoldDesignat ="";
		String insuredOperationschg = "";
		String operationDescription = "";
		String annualSales ="";
		String percentageCanada ="";
		String percentageUS ="";
		String percentageOtherCountries ="";
		String purchaseResell = "";
		String construction="";
		String distribution ="";
		String gasSector="";
		String designBuild = "";
		String constBuild ="";
		String contractors ="";
		String declInsuranceCancel ="";
		String declPreviousClaim = "";
		String declPreviousAct = "";
		String declClaimPrevious = "";
		String specialityOthers = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			username = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "username");
			password = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "password");
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "inceptionDate");
			goodStanding = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "goodStanding");
			previousInsurace = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "previousInsurace");
			enOLimits_0__EAOLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "EnOLimits_0__EAOLimit");
			practice = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "practice");
			insuredDetails_0__InsName = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "insuredDetails_0__InsName");
			memebershipNumber = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "memebershipNumber");
			employmentType = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "EmploymentType");
			homeInspector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "homeInspector");
			locationActivites = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "locationActivites");
			specialtyCheckHeader = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "specialtyCheckHeader");
			cGLLimit = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "cGLLimit");
			insuredHoldDesignat = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "insuredHoldDesignat");
			insuredOperationschg = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "insuredOperationschg");
			operationDescription = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "operationDescription");
			annualSales = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "annualSales");
			percentageCanada = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "percentageCanada");
			percentageUS = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "percentageUS");
			percentageOtherCountries = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "percentageOtherCountries");
			purchaseResell = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "purchaseResell");
			construction = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "construction");
			distribution = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "distribution");
			gasSector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "gasSector");
			designBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "designBuild");
			constBuild = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "constBuild");              
			contractors = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "contractors");
			declInsuranceCancel = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declInsuranceCancel");
			declPreviousClaim = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declPreviousClaim");
			declPreviousAct = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declPreviousAct");
			declClaimPrevious = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "declClaimPrevious");
			specialityOthers = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "specialityOthers");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}
		finally{
			DataWorkBook.close();

			//Click on Product tab
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_products), "Clikc on the Product Tab", "User able to create the product tab", "User unable to click on the product tab");
			System.out.println("Product tab is clicked");

			//click on the Get quote for a particular product
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GetaQuoteASTTBC_B2C), "Click on the Required product", "User able to click on the particular Product", "User unable to click on the particular product");
			System.out.println("Product is clicked");

			//Enter the Inception date
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.txt_QuestionsInceptionDate), "Enter the Incpetion Date", "User able to enter the inception Date", "User Unable to enter the Inception date", inceptionDate);
			driver.findElement(GenB2CSales.txt_QuestionsInceptionDate).sendKeys(Keys.TAB);

			//Select Value from the drop down "Are you a Member in good standing with the ASTTBC?*"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_MemberInGoodStanding), "Select Value from Member in Good standing with ASTTBC", "User able to Select Value from Member in Good standing with ASTTBC", "User unable to Select Value from Member in Good standing with ASTTBC", goodStanding);

			//Select value from the drop down Have you previously purchased Professional Liability insurance to cover your ASTTBC related professional practice you are currently applying for?
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PreviousInsurance), "Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", "User able to Select Value from the drop down Previous Insurance", previousInsurace);

			//Select Value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EnOLimits), "Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User abel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.", "User unabel to Select value from the drop down Select the required Professional Liability Limit per claim for the upcoming policy term.",enOLimits_0__EAOLimit);

			//Select Value from the filed Are you applying as an individual for coverage in your own name and are employed by a firm or organization that is not applying for insurance?
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Practice), "Select Value from the dropdown", "user to able to select value from the drop down", "user to able to select value from the drop down",practice);

			//Enter the Value in the field ASTTBC Member Name
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_InsName), "Enter the ASTTBC Memeber Name ", "User able to Enter the ASTTBC Memeber Name ", "user unbale to Enter the ASTTBC Memeber Name ",insuredDetails_0__InsName );

			//Enter value in the Membership Number field
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_MembershipNo), "Enter value in the Membership Number field", "user able to Enter value in the Membership Number field", "User unable to Enter value in the Membership Number field", memebershipNumber);

			//Select value in the "Your individual revenue amount is" field
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_EmploymentType), "Select value in the Your individual revenue amount is field", "User able to Select value in the Your individual revenue amount is field", "User unable to Select value in the Your individual revenue amount is field", employmentType);

			//Select value in the field "Are you a Home Inspector?"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_HomeInspector), "Select value in the field Are you a Home Inspector?", "User able to Select value in the field Are you a Home Inspector?", "User unable to Select value in the field Are you a Home Inspector?", homeInspector);

			//Select Value from the field "Do you perform underground Utility Location activities?*"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_UndLocator), "Select Value from the field Do you perform underground Utility Location activities?*", "User able to Select Value from the field Do you perform underground Utility Location activities?*", "User unable to Select Value from the field Do you perform underground Utility Location activities?*", locationActivites);

			//Select Value from the filed Do you hold a Technical Speciality designation?, if Yes, select all the certifications this applicant holds *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_SpecialtyCheckHeader), "Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "user able to Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "User unable to select Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", specialtyCheckHeader);

			//Click on the Others Check box for speciality check 
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.chkBox_SpecialityOthers), "Click on the Others Check box for speciality check ", "User able to Click on the Others Check box for speciality check ", "User unable to Click on the Others Check box for speciality check ");

			//Enter details in the field Describe other ASTTBC designations speciality
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.txt_SpecialityOthers), "Enter details in the field Describe other ASTTBC designations speciality", "User able to Enter details in the field Describe other ASTTBC designations speciality", "User unable to enter details in the field Describe other ASTTBC designations speciality", specialityOthers);

			//Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term. *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_CGLLimit), "Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User able to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", "User unable to Select the value from the field Select the required Commercial General Liability Limit per occurrence for the upcoming policy term", cGLLimit);

			//Select the value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredHoldDesignat), "Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User able to Select value from the field Are you (or any of the applicants listed before) an AScT or Ctech? *", "User unable to Are you (or any of the applicants listed before) an AScT or Ctech? *", insuredHoldDesignat);

			//Select the value from the field Have your current activities changed since last renewal?. *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_InsuredOperationschg), "Select value from the field Have your current activities changed since last renewal?. *", "User able to Select value from the field Have your current activities changed since last renewal?.", "User unable to Select value from the field Have your current activities changed since last renewal?.", insuredOperationschg);

			//Enter Text value in the Operation Description field
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_OperationDescription), "Enter Text value in the Operation Description field", "User able to Enter Text value in the Operation Description field", "User unable to Enter Text value in the Operation Description field", operationDescription);

			//Enter the Value in the field Annual Sales (in CAD) *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_AnnualSales), "Enter the Value in the field Annual Sales (in CAD) *", "User able to enter the Value in the field Annual Sales (in CAD) *", "User unable to Enter the Value in the field Annual Sales (in CAD) *", annualSales);

			//Enter value in the field Percentage of sales in Canada *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageCanada), "Enter value in the field Percentage of sales in Canada *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Canada *", percentageCanada);

			//Enter value in the field Percentage of sales in US *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageUS), "Enter value in the field Percentage of sales in US *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in US *", percentageUS);

			//Enter value in the field Percentage of sales in Other Countries *
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.B2CSales_PercentageinOther), "Enter value in the field Percentage of sales in Other Countries *", "User able to Enter value in the field Percentage of sales in Canada *", "User unable to Enter value in the field Percentage of sales in Other Countries *", percentageOtherCountries);

			//Select Value from the field Do you or any related company purchase and/or resell products? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_PurchaseResel), "Select Value from the field Do you or any related company purchase and/or resell products? *", "User able to Select Value from the field Do you or any related company purchase and/or resell products? *", "User unable to Select Value from the field Do you or any related company purchase and/or resell products? *", purchaseResell);

			//Select value from the field Your operations include hands-on work in the areas of construction (including blasting, demolition, underpinning, pile driving, shoring, welding, excavation), installation, maintenance or repairs? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Construction), "Select Value from the Construction field", "User able to Select Value from the Construction field", "User able to Select Value from the Construction field", construction);

			//Select value from the field Your operations include manufacturing, distribution or sale of products *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Distribution), "Select value from the field Your operations include manufacturing, distribution or sale of products *", "User able to Select value from the field Your operations include manufacturing, distribution or sale of products *", "User unable to Select value from the field Your operations include manufacturing, distribution or sale of products *", distribution);

			//Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_GasSector), "Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User able to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", "User unable to Select value from the field Your operations include work in the oil and gas sector, specifically hot taps, down hall and blow out prevention work *", gasSector);

			//Select value from the field Do you undertake design-build activities? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DesignBuild), "Select value from the field Do you undertake design-build activities? *", "User able to Select value from the field Do you undertake design-build activities? *", "User unable to Select value from the field Do you undertake design-build activities? *", designBuild);

			//Select value from the field Do you undertake construction-building activities? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_ConstBuild), "Select value from the field Do you undertake construction-building activities? *", "User able to Select value from the field Do you undertake construction-building activities? *", "User unable to Select value from the field Do you undertake construction-building activities? *", constBuild);

			//Select value from the field Do you employ subcontractors or independent contractors? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_Contractors), "Select value from the field Do you employ subcontractors or independent contractors? *", "User able to Select value from the field Do you employ subcontractors or independent contractors? *", "User unable to Select value from the field Do you employ subcontractors or independent contractors? *", contractors);

			//Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclInsuranceCancel), "Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User able to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", "User unable to Select value from the field Has your Professional Liability Insurance coverage ever been declined or cancelled or renewal refused? *", declInsuranceCancel);

			//Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousClaim), "Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User able to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", "User unable to Select Value from the field Has any Professional Liability claim, complaints and/or suit been brought against you on account of any actual or alleged error or mistake? *", declPreviousClaim);

			//Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclPreviousAct), "Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "user able to Select Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? *", "User unable toSelect Value from the field Do you have any knowledge of any act which might give rise to a future Professional Liability claim under this policy or do you anticipate any claims being brought against you? * ", declPreviousAct);

			//Select value from the field Have you ever suffered any General Liability claim in the past? *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_DeclClaimPrevious), "Select value from the field Have you ever suffered any General Liability claim in the past? *", "User able to Select value from the field Have you ever suffered any General Liability claim in the past? *", "User unable to Select value from the field Have you ever suffered any General Liability claim in the past? * ", declClaimPrevious);

			//click on the Get a Quote Button
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");
			Thread.sleep(8000);
		}
	}


	public  void createDeclinedQuoteRenewal() throws InterruptedException, IOException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "B2CSale";
		DataSheetRead DataWorkBook = null;
		String specialtyCheckHeader = "";
		String specialityOthers = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			specialtyCheckHeader = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "specialtyCheckHeader");
			specialityOthers = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalQuote", "specialityOthers");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}
		finally{
			DataWorkBook.close();


			//Select Value from the filed Do you hold a Technical Speciality designation?, if Yes, select all the certifications this applicant holds *
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_SpecialtyCheckHeader), "Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "user able to Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", "User unable to select Select Value from the filed Do you hold a Technical Specialty designation?, if Yes, select all the certifications this applicant holds *", specialtyCheckHeader);

			//Click on the Others Check box for speciality check 
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.chkBox_SpecialityOthers), "Click on the Others Check box for speciality check ", "User able to Click on the Others Check box for speciality check ", "User unable to Click on the Others Check box for speciality check ");

			//Enter details in the field Describe other ASTTBC designations speciality-Yes
			Implementation.EnterTextFeild(driver, driver.findElement(GenB2CSales.txt_SpecialityOthers), "Enter details in the field Describe other ASTTBC designations speciality", "User able to Enter details in the field Describe other ASTTBC designations speciality", "User unable to enter details in the field Describe other ASTTBC designations speciality", specialityOthers);

			//click on the Get a Quote Button
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");
			Thread.sleep(3000);

			//click on the Get a Quote Button
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");
			Thread.sleep(3000);

			//Click on assign button
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_AssignButton), "Click on assign button in B2C sales", "User able to Click on assign button in B2C sales", "User not able to Click on assign button in B2C sales");

			//Click on Decline button
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_DeclineButton), "Click on accept button in B2C sales", "User able to Click on decline button in B2C sales", "User not able to Click on decline button in B2C sales");

			//Select the check box on pop up
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_Decline_SelectChechbox), "Click on yes button in B2C sales", "User able to select chechk box in B2C sales", "User not able to select chechk box in B2C sales");

			//Enter the comment on decline pop up
			Implementation.EnterTextFeild(driver, driver.findElement(MTALocators.B2C_Decline_Comment), "", "", "", specialityOthers);

			//Click on yes button
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_Decline_Comment_Yesbtn), "Click on yes button in B2C sales", "User able to Click on yes button in B2C sales", "User not able to Click on yes button in B2C sales");

			//Verify a Quote is reflected as Decline
			if(Implementation.isobjDisplayed(driver.findElement(GenB2CSales.B2CSales_Quote_Status_Decline))){
				NextGenUtilities.appendPass("Verify a B2C Policy (parent Policy) is initially as Decline", "User able to see parent policy is in Decline status");
			}else{
				NextGenUtilities.logFailure(driver, "User not seeing parent policy is in Decline status", "User not seeing parent policy is in Decline status"); 
			}

			//Verify the No Premium should be calculated
			//Click on Premium Summary button
			Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_QuoteSummary_Premium), "Click on premium breakdown button in B2C sales", "User able to Click on premium breakdown button in B2C sales", "User not able to Click on premium breakdown button in B2C sales");

			//Verify the cannot override the net premium
			if(Implementation.isobjDisplayed(driver.findElement(MTALocators.B2C_QuoteSummary_NetPremium))){
				NextGenUtilities.logFailure(driver, "Verify the No Premium should be calculated after decline", "User able to see gross premium is still calculated after decline");
			}else{ 
				NextGenUtilities.appendPass("Verify the No Premium should be calculated after decline", "User not seeing any gross premium is calculated after decline");
			}
		}
	}



	public  void referredRenewalPolicyTacitConfig() throws InterruptedException, IOException

	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_B2CSale =  "B2CSale";
		DataSheetRead DataWorkBook = null;
		String homeInspector="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			homeInspector = DataWorkBook.readCellString(pc_sheet_name_B2CSale, "createPolicyASTTBCRenewalreferral", "homeInspector");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********(Exception while reading Data sheet)*********");
		}
		finally{
			DataWorkBook.close();

			//Select value in the field "Are you a Home Inspector?"
			Implementation.selectDropdown(driver, driver.findElement(GenB2CSales.B2CSales_HomeInspector), "Select value in the field Are you a Home Inspector?", "User able to Select value in the field Are you a Home Inspector?", "User unable to Select value in the field Are you a Home Inspector?", homeInspector);

			//click on the Get a Quote Button
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");
			Thread.sleep(3000);

			//click on the Get a Quote Button
			Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_GenerateQuote), "Click on the Get a Quote Button", "User able to Click on the Get a Quote Button", "User unable to Click on the Get a Quote Button");
			Thread.sleep(5000);


		}
	}

	public  void Assign_UploaddocRenewalPolicyTacitConfig() throws InterruptedException, IOException

	{
		//Click on save button
		Thread.sleep(5000); 
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2CSales_Save_QuoteBtn), "Click on save quote button", "User able to Click on save quote button in B2C", "User not able to Click on save quote button in B2C");

		//Click on close the pop up 
		Thread.sleep(5000); 
		Implementation.ClickFeild(driver, driver.findElement(GenB2CSales.B2C_Closed_Popup), "Click on closed symbol", "User able to Click on closed symbol in B2C", "User not able to Click on closed symbol in B2C");

		//Click on assign button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_AssignButton), "Click on assign button in B2C sales", "User able to Click on assign button in B2C sales", "User not able to Click on assign button in B2C sales");

		//Upload Document
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_UploadDocButton), "Click on upload document button in B2C sales", "User able to Click on upload document button in B2C sales", "User not able to Click on upload document sbutton in B2C sales");

		//Click on choose file button
		Thread.sleep(2000);
		Implementation.test("C:\\Automation_Suite\\Core_Reg_Suite\\GenAsys\\data\\docstore\\General.doc");

		Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_UploadDoc_ChooseFile), "Click on choose file button in B2C sales", "User able to Click on choose file button in B2C sales", "User not able to Click on choose file button in B2C sales");

		//Click on upload button after uploading document
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.B2C_ChooseFile_Upload), "Click on upload button after uploading the doc in B2C sales", "User able to Click on upload button after uploading the doc button in B2C sales", "User not able to Click on upload button after uploading the doc in B2C sales");

	}


	public void keytoCreatePolicyCATAdminsingle() throws IOException, InterruptedException
	{
		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "Product";
		DataSheetRead DataWorkBook = null;
		DataWorkBook = new DataSheetRead(pc_sheet_path);
		String Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Username");
		String Password = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Password");
		String Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "DropDownValue");
		String ProducName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ProducName");
		String ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ExpiryDate");
		String BusinessDes = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "BusinessDes");
		String InterestedParty = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "InterestedParty");
		String State = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "State");
		String LiabilityLimit = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "LiabilityLimit");
		String Category = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Category");
		String Year = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Year");
		String Make = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Make");
		String Model = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Model");
		String SerialNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SerialNo");
		String PinNo = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "PinNo");
		String SumInsured = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "SumInsured");
		String RoadUsed = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "RoadUsed");
		String GPSTracking = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "GPSTracking");
		String CompanyID = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "CompanyID");
		String CompanyName = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ComapnyName");
		String Department = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "DepartMent");
		String Addresstype = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressType");
		String AddressLine1 = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "AddressLine1");
		String City = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "City");
		String Zipcode = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "ZipCode");
		String Country = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "Country");
		String inceptionDate = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "MTA_Complex", "inceptionDate");

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

		//Select drop down sponsor
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

		//Click on Quote Tab
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//enter Inception Date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_inception), "Enter Inception Date", "User able to enter inception Date", "User unable to enter the inception date", inceptionDate);
		driver.findElement(AllGeneralTabs.date_inception).sendKeys(Keys.ENTER);
		Thread.sleep(3000);

		//Select a Product, input is given by Excel
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='"+ProducName+"']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select start date 
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Business Description
		Select Business = new Select(MTALocators.MTAComplex_Quote_Business);
		Business.selectByVisibleText(BusinessDes);

		//Enter Interested Party
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_InterestedParty, "Enter Interested Party", "Able to Enter Interested Party", "Unable to Enter Interested Party", InterestedParty);

		//Select State
		Select state = new Select(MTALocators.MTAComplex_Quote_State);
		state.selectByVisibleText(State);

		//Select 3rd Party Liability Limit
		Select liability = new Select(MTALocators.MTAComplex_Quote_TPLLimit); 
		liability.selectByVisibleText(LiabilityLimit);  

		//Select Category
		Select category = new Select(MTALocators.MTAComplex_Quote_Category);
		category.selectByVisibleText(Category);

		//Enter Year
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Year, "Enter Year", "Able to Enter Year", "Unable to Enter Year", Year);

		//Enter Make
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Make, "Enter Make", "Able to Enter Make", "Unable to Enter Make", Make);

		//Enter Model
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Model, "Enter Model", "Able to Enter Model", "Unable to Enter Model", Model);

		//Enter Serial No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Serial, "Enter serial Number", "ABLE TO Enter Serial Number", "Unable to Enter Serial Number", SerialNo);

		//Enter Pin No
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_Pin, "Enter Pin Number", "Able to Enter Pin Number", "Unable to Enter Pin Number", PinNo);

		//Enter Sum Insured
		Implementation.EnterTextFeild(driver, MTALocators.MTAComplex_Quote_SumInsured, "Enter Sum Insured", "Able to Enter Sum Insured", "Unable to Enter Sum Insured", SumInsured);

		//Select Reg Road Used
		Select roadused = new Select(MTALocators.MTAComplex_Quote_RegRoadUsed);
		roadused.selectByVisibleText(RoadUsed);

		//Select GPS Tracking
		Select gps = new Select(MTALocators.MTAComplex_Quote_GPSTracking);
		gps.selectByVisibleText(GPSTracking);

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextButton), "Click on Next Button", "Able to Click on Next Button", "Unable to Click on Next Button");

		//Click on Next Button in Quote Summary page
		Implementation.DoubleClick(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button in Quote Summary page", "Able to Click on Next Button in Quote Summary page", "Unable to Click on Next Button in Quote Summary page");

		//Create Customer
		Implementation.ClickFeild(driver, MTALocators.MTAComplex_Quote_CreateCustomer, "Click on Create customer", "Able to click on create customer button in custimer screen", "Not able to click on create customer screen");

		//Input First Name
		Implementation.EnterTextFeild(driver, AllGeneralTabs.CompanyName1, "Verify FirstName is entered", "FirstName is entered", "Not able to Input FirstName", CompanyName);

		//Input Family Name
		Implementation.EnterTextFeild(driver, AllGeneralTabs.Department1, "Verify FamilyName is entered", "FamilyName is entered", "FamilyName is NOT entered", Department);
		AllGeneralTabs.Department1.sendKeys(Keys.TAB);

		//Input EmailAddress1
		Implementation.EnterTextFeild(driver, AllGeneralTabs.EmailAddress1, "Verify EmailAddress1 is entered", "Email Address1 is entered", "Email Address1 is NOT entered", Username);
		AllGeneralTabs.EmailAddress1.sendKeys(Keys.TAB);

		//Select the default check
		Implementation.ClickFeild(driver, AllGeneralTabs.EmailAddress_Defualt1, "Verify default check box is present", "User able to select default check box", "User not able to select default check box");

		//Click on Next Button
		Implementation.ClickFeild(driver, driver.findElement(GenCustCreation.nextCButton), "Verify Next button is clicked", "Next button is clicked successfully", "Next button is NOT enabled/Clicked");

		//Click on new address
		Implementation.ClickFeild(driver, AllGeneralTabs.NewAddress, "Verify New address tab", "Usr able to click on new address tab", "New address tab is not clickable");

		//Select Address Type
		Select AddressTypeDD=new Select(driver.findElement(GenCustCreation.AddressType1));
		AddressTypeDD.selectByVisibleText(Addresstype);

		//Enter Address Line1
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.AddressLine11), "Verify AddressLine1 is entered", "Address Line1 is entered", "Address Line1 is NOT entered", AddressLine1);

		//Enter City
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.City1), "Verify City is Entered", "City is Entered", "City is NOT entered", City);

		//Enter ZIP Code
		Implementation.EnterTextFeild(driver, driver.findElement(GenCustCreation.ZIPCode1), "Verify ZIPCode is entered", "ZIPCode is Entered", "ZIPCode is NOT Entered", Zipcode);

		//		//Enter Country
		//		Select CountryDD=new Select(driver.findElement(GenCustCreation.Country1));
		//		CountryDD.selectByVisibleText(Country);

		//Click Address Save Button
		Implementation.ClickFeild(driver,driver.findElement(GenCustCreation.AddressSaveButton1), "Verify Address Save Button is clicke", "Address Save button is clicke", "Address Save button is NOT Enabled/Clicked");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on Create Policy button", "Able to click", "Unable to click");

		//Select Yes Button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_CreatePolicy_Yes1), "Select Yes Button", "Able to select yes button", "Unable to select yse button");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click", "Unable to click");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.MTAComplex_Quote_NextBtn),"Click on Next Button", "Able to click", "Unable to click");

		//Click on Create Policy
		Implementation.ClickFeild(driver,driver.findElement(MTALocators.btn_createPolicy1),"Click on Next Button", "Able to click next button in summary", "Unable to click next button in summary");

		//Fetch Policy/Plan number
		policyNumberCAT=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+policyNumberCAT);
	}


	//**********************************************R17 Scenario Validation*******************************************//

	public void keyToLoginClientApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String Username = "";
		String Password= "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Username = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "SpotCheck_Error_Validation", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "SpotCheck_Error_Validation", "Password");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameClient,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordClient,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginClient,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

	}

	public void keyToSelect_Sponsor_JyskEnergi_ClientApp() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "SpotCheck_Error_Validation", "Sponsor");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}

	public void keyToSelect_Sponsor_3Mobile_ClientApp() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToSelect_Sponsor_3Mobile_ClientApp*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "3MobileValidation", "Sponsor");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}
	
	public void keyToSelect_Sponsor_NEWMNO_ClientApp() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToSelect_Sponsor_NEWMNO_ClientApp*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_ShakeDown =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name_ShakeDown, "GenericMNOSponsor", "Sponsor");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_select_sponsorClient);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_selectClient,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}

	public void keyToLoginR17Admin_ApplicationPage() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToLoginAdminApplicationPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String AdminUrl = "";
		String Username = "";
		String Password= "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			AdminUrl = DataWorkBook.readCellString(pc_sheet_name, "SpotCheck_Error_Validation", "BaseUrl");
			Username = DataWorkBook.readCellString(pc_sheet_name, "SpotCheck_Error_Validation", "Username");
			Password = DataWorkBook.readCellString(pc_sheet_name, "SpotCheck_Error_Validation", "Password");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Launch the browser as well application

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//*****************Login Application Validation*********************

		//Launch the application
		driver.get(AdminUrl); 
		//Enter User name in Login page
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_UsernameAdmin,"Verify user name text box","User able to Enter Username", "Unable to Enter Username",Username);

		//Enter Password in Login Page 
		Implementation.EnterTextFeild(driver, AllGeneralTabs.txt_PasswordAdmin,"Verify the password text box","User able to Enter Password", "Unable to Enter Password",Password);

		//click on login Page
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_LoginAdmin,"Verify the login button","User clicked on Login button successfully", "Unable to click on Login button");

	}

	public void keyToSelect_Sponsor_JyskEnergi_AdminApp() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToSelect_Sponsor_AdminApplication*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String Sponsordropdownvalue="";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			Sponsordropdownvalue = DataWorkBook.readCellString(pc_sheet_name, "SpotCheck_Error_Validation", "Sponsor");


		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		//Launch the browser as well application

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Select drop down sponsor
		Thread.sleep(5000);
		Select dropdown = new Select(AllGeneralTabs.cmb_SelectSpoAdmin);
		dropdown.selectByVisibleText(Sponsordropdownvalue);

		//Click on select button after selecting as new sponsor
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, AllGeneralTabs.btn_SelectAponsorAdmin,"Verify the select admin drop down", "User able to click on select button", "Select button is not clickable");

	}

	public void keyToCreatePolicyForBPCliams() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToMAPage*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String inceptionDate = "";
		String Product = "";
		String ExpiryDate = ""; 
		String CoverageType = ""; 
		String CustomerName = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "inceptionDate");
			Product = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "Product");
			ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ExpiryDate");
			CoverageType = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "CoverageType");
			CustomerName = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "CustomerName");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Enter Inception Date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_inception), "Enter Inception Date", "User able to enter inception Date", "User unable to enter the inception date", inceptionDate);
		driver.findElement(AllGeneralTabs.date_inception).sendKeys(Keys.ENTER);
		Thread.sleep(3000);

		//Select a Product, input is given by Excel 
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='Enter Card']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select date 
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Coverage Type
		Implementation.selectDropdown(driver, MTALocators.QuoteDetails_CoverageType, "Select Coverage type in quote details screen", "User able to select Coverage type in quote details screen", "Unable to select Coverage type in quote details screen", CoverageType);

		//Click on next button
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_Next, "Click on Next Button In Quote details screen", "User able to click on next button in quote details", "Next button is not clickable in Quote details screen");

		//Click on next button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button In Quote details screen", "User able to click on next button in quote details", "Next button is not clickable in Quote details screen");

		//Search Customer
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_Customer_SearchFld, "Enter Customer name", "User able to enter customer name", "Unable to enter customer name", CustomerName);

		//Click on Search button
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_Customer_Searchbtn, "Click on search button in customer screen", "User able to click on search button in customer screen", "Unale to click on search button in customer screen");

		//Click on Customer name hyper link
		Implementation.ClickFeild(driver, MTALocators.CustomerName_Hyperlink, "Click on customer name hyper link", "User able to click on customer hyper link", "Unable to click on customer name hyper link");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on create policy button", "Able to click create policy button", "Unable to click on create policy button");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on create policy button", "Able to click create policy button", "Unable to click on create policy button");

		Thread.sleep(7000);

		//Fetch Policy/Plan number
		String planNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+planNumber);

	}

	public void keyToCreatePolicyFor3MobileSponsor() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreatePolicyFor3MobileSponsor*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String inceptionDate = "";
		String ExpiryDate = "";
		String Payment_DueDate = "";
		String Purchage_Date = "";
		String DeviceMakebeinginsured = "";
		String DeviceModelbeinginsured = "";
		String DeviceSpecbeinginsured = "";
		String Product_ID = "";
		
		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "inceptionDate");
			ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "ExpiryDate");
			Payment_DueDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Payment_DueDate");
			Purchage_Date = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Purchage_Date");
			DeviceMakebeinginsured = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "DeviceMakebeinginsured");
			DeviceModelbeinginsured = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "DeviceModelbeinginsured");
			DeviceSpecbeinginsured = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "DeviceSpecbeinginsured");
			Product_ID = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Product_ID");
			
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Enter Inception Date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_inception), "Enter Inception Date", "User able to enter inception Date", "User unable to enter the inception date", inceptionDate);
		driver.findElement(AllGeneralTabs.date_inception).sendKeys(Keys.ENTER);
		Thread.sleep(3000);

		//Select a Product, input is given by Excel 
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='3 F�rs�kring']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select date 
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//enter payment due date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.firstPay), "Enter date", "User able to enter date", "User unable to enter date", Payment_DueDate);

		//enter purchase date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.pURCHASEDATE), "Enter Purchase date", "USer able to enter purchase date", "user unable to enter purchase date", Purchage_Date);

		//enter device modal , device name and spec
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.dEVICEMAKE), "Enter device make", "User able to enter device make", "User unable to enter device make", DeviceMakebeinginsured);
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.dEVICEMODEL), "Enter device modal ", "User able to enter device modal", "User unable to enter device modal", DeviceModelbeinginsured);
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.dEVICESPECIFICATION), "Enter device specification", "User able to enter device specification", "User unable to enter device specification", DeviceSpecbeinginsured);

		//Enter Product ID
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.pRODUCTid), "Enter product id", "Able to enter product id", "Unable to enter product id", Product_ID);

		//click next	
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnNext),"Click next" , "User able to click next", "User unable to click next");

		//click next again
		Implementation.ClickFeild(driver,driver.findElement(AllGeneralTabs.nextBt),"Click next" , "User able to click next", "User unable to click next");

		//enter cus id
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.searchTxt), "Enter customer ID", "User able to enter customer ID", "User able to enter customer ID", "CUS123");

		//click search
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnSearch), "Click search", "User able to click search", "User unable to click search");

		//click search result
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.searchResult),"Click search result" , "User able to click search result", "User unable to click search result");

		//click create policy
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnCreatePolicy), "Click create policy button", "User able to click create policy", "User unable to click create policy");

		//enter ext ref
		VEW_methods.currentTime();
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.txtExtRef), "Enter external reference number", "User able to enter external reference number", "User unable to enter external reference number", "Ext"+VEW_methods.time);

		//click next btn
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btNext),"Click next" , "User able to click next", "User unable to click next");

		//click create policy button
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnCreatePolicy),  "Click create policy button", "User able to click create policy", "User unable to click create policy");

		//Fetch Policy/Plan number
		String planNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+planNumber);

	}



	public void keyToCreatePolicyForBPCliams_ReverseCalculation() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreatePolicyForBPCliams_ReverseCalculation*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String inceptionDate2 = "";
		String Product = "";
		String ExpiryDate = ""; 
		String CoverageType = ""; 
		String CustomerName = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			inceptionDate2 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "inceptionDate2");
			Product = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "Product");
			ExpiryDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ExpiryDate");
			CoverageType = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "CoverageType");
			CustomerName = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "CustomerName");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Enter Inception Date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_inception), "Enter Inception Date", "User able to enter inception Date", "User unable to enter the inception date", inceptionDate2);
		driver.findElement(AllGeneralTabs.date_inception).sendKeys(Keys.ENTER);
		Thread.sleep(3000);

		//Select a Product, input is given by Excel 
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='Enter Card']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//Select Expiry Date
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_ExpiryDate, "Verify the Expiry date Field", "User able to click on expiry date field as expected","Expiry date field is not clickable");

		//Select date 
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_ExpiryDate,"Verify the Date picker", "User able to click on start date pick box", "Start date picke box is not clickable", ExpiryDate);
		MTALocators.MTA_Referellel_ExpiryDate.sendKeys(Keys.TAB);

		//Select Coverage Type
		Implementation.selectDropdown(driver, MTALocators.QuoteDetails_CoverageType, "Select Coverage type in quote details screen", "User able to select Coverage type in quote details screen", "Unable to select Coverage type in quote details screen", CoverageType);

		//Click on next button
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_Next, "Click on Next Button In Quote details screen", "User able to click on next button in quote details", "Next button is not clickable in Quote details screen");

		//Click on next button
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.MTAComplex_Quote_NextBtn), "Click on Next Button In Quote details screen", "User able to click on next button in quote details", "Next button is not clickable in Quote details screen");

		//Search Customer
		Implementation.EnterTextFeild(driver, MTALocators.MTA_Referellel_Customer_SearchFld, "Enter Customer name", "User able to enter customer name", "Unable to enter customer name", CustomerName);

		//Click on Search button
		Implementation.ClickFeild(driver, MTALocators.MTA_Referellel_Customer_Searchbtn, "Click on search button in customer screen", "User able to click on search button in customer screen", "Unale to click on search button in customer screen");

		//Click on Customer name hyper link
		Implementation.ClickFeild(driver, MTALocators.CustomerName_Hyperlink, "Click on customer name hyper link", "User able to click on customer hyper link", "Unable to click on customer name hyper link");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on create policy button", "Able to click create policy button", "Unable to click on create policy button");

		//Click on Create Policy
		Implementation.ClickFeild(driver, driver.findElement(MTALocators.btn_createPolicy), "Click on create policy button", "Able to click create policy button", "Unable to click on create policy button");

		Thread.sleep(7000);

		//Fetch Policy/Plan number
		String planNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+planNumber);

	}


	public void keyToCreateClaims() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaims*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss = "";
		String ClaimsReason = ""; 
		String NotificationDate = ""; 
		String DeclarationDate = ""; 
		String ClaimsDetails = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss");
			ClaimsReason = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason");
			NotificationDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate");
			DeclarationDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DeclarationDate");
			ClaimsDetails = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Select Declaration date
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_DeclarationDate, "Select the declaration date in new claims page", "Able to select loss of date in new claims page", "User not able to select declaration date in new claims page", DeclarationDate);
		MTALocators.PVS_PolicyClaims_DeclarationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);


	}


	public void keyToCreateClaimsForLODLessThanDeclaration() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForLODLessThanDeclaration*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss2 = "";
		String ClaimsReason2 = ""; 
		String NotificationDate2 = ""; 
		String DeclarationDate2 = ""; 
		String ClaimsDetails2 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss2 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss2");
			ClaimsReason2 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason2");
			NotificationDate2 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate2");
			DeclarationDate2 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DeclarationDate2");
			ClaimsDetails2 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails2");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss2);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason2);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate2);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Select Declaration date
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_DeclarationDate, "Select the declaration date in new claims page", "Able to select loss of date in new claims page", "User not able to select declaration date in new claims page", DeclarationDate2);
		MTALocators.PVS_PolicyClaims_DeclarationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails2);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}


	public void keyToCreateClaimsForExclusionValidation() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForExclusionValidation*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss3 = "";
		String ClaimsReason3 = ""; 
		String NotificationDate3 = ""; 
		String ClaimsDetails3 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss3 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss3");
			ClaimsReason3 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason3");
			NotificationDate3 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate3");
			ClaimsDetails3 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails3");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss3);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason3);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate3);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails3);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);


	}


	public void keyToCreateClaimsForExcessPeriod() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForExcessPeriod*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss4 = "";
		String ClaimsReason4 = ""; 
		String NotificationDate4 = ""; 
		String ClaimsDetails4 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss4");
			ClaimsReason4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason4");
			NotificationDate4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate4");
			ClaimsDetails4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails4");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss4);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason4);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate4);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails4);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}

	public void keyToCreateClaimsForExclusionrule_Elapsedrule() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForExclusionrule_Elapsedrule*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss5 = "";
		String ClaimsReason5 = ""; 
		String NotificationDate5 = ""; 
		String ClaimsDetails5 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss5 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss5");
			ClaimsReason5 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason5");
			NotificationDate5 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate5");
			ClaimsDetails5 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails5");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss5);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason5);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate5);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails5);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}


	public void keyToCreateClaimsForClaimRenewalDate_Validate() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForClaimRenewalDate_Validate*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss6 = "";
		String ClaimsReason6 = ""; 
		String NotificationDate6 = ""; 
		String ClaimsDetails6 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss6 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss6");
			ClaimsReason6 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason6");
			NotificationDate6 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate6");
			ClaimsDetails6 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails6");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss6);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason6);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate6);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails6);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}


	public void keyToCreateClaimsForReverseClaimPayment_Validate() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForReverseClaimPayment_Validate*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss7 = "";
		String ClaimsReason7 = ""; 
		String NotificationDate7 = ""; 
		String ClaimsDetails7 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss7 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss7");
			ClaimsReason7 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason7");
			NotificationDate7 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate7");
			ClaimsDetails7 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails7");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		//Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss7);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason7);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate7);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails7);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}

	public void keyToCreateAddAccountBalance() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateAddAccountBalance*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String BalanceDate = "";
		String ReceiveDate = ""; 
		String AccountBalance = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			BalanceDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "BalanceDate");
			ReceiveDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ReceiveDate");
			AccountBalance = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "AccountBalance");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Add account balance button
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimPayment_AddAccountBalance, "Click on add account balance button in claim payment view section", "Able to click on add account balance button in claim payment view section", "Unable to click on add account balance button in claim payment view section");

		//Enter Balance Data
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimPayment_AddAccount_BalanceDate, "Select the loss of date in new claims page", "Able to select balance date in claim payment view section", "User not able to select balance date in claim payment view section", BalanceDate);
		MTALocators.PVS_ClaimPayment_AddAccount_BalanceDate.sendKeys(Keys.TAB);

		//Select Receive Date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimPayment_AddAccount_ReceiveDate, "Select claims reason from drop down", "Able to select the receive date in claim payment view section", "User not able to select the receive date in claim payment view section", ReceiveDate);
		MTALocators.PVS_ClaimPayment_AddAccount_ReceiveDate.sendKeys(Keys.TAB);

		//Enter Account balance
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimPayment_AddAccount_AccountBalance, "Enter account balance data in claim payment view section", "Able to enter account balance data in claim payment view section", "User not able to enter account balance data in claim payment view section", AccountBalance);
		MTALocators.PVS_ClaimPayment_AddAccount_AccountBalance.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000); 
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimPayment_AddAccountBalance_SaveBtn, "Click on save button in claims payment view Screen", "User able to click on save button", "User not able to click on save button claims payment view Screen");
		Thread.sleep(3000);

	}

	
	public void keyToCreateAddAccountBalanceForMaximumBalanceLimit() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateAddAccountBalanceForMaximumBalanceLimit*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String BalanceDate = "";
		String ReceiveDate = ""; 
		String AccountBalance = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			BalanceDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "BalanceDateForMaximumLimit");
			ReceiveDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ReceiveDateForMaximumLimit");
			AccountBalance = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "AccountBalanceForMaximumLimit");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on Add account balance button
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimPayment_AddAccountBalance, "Click on add account balance button in claim payment view section", "Able to click on add account balance button in claim payment view section", "Unable to click on add account balance button in claim payment view section");

		//Enter Balance Data
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimPayment_AddAccount_BalanceDate, "Select the loss of date in new claims page", "Able to select balance date in claim payment view section", "User not able to select balance date in claim payment view section", BalanceDate);
		MTALocators.PVS_ClaimPayment_AddAccount_BalanceDate.sendKeys(Keys.TAB);

		//Select Receive Date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimPayment_AddAccount_ReceiveDate, "Select claims reason from drop down", "Able to select the receive date in claim payment view section", "User not able to select the receive date in claim payment view section", ReceiveDate);
		MTALocators.PVS_ClaimPayment_AddAccount_ReceiveDate.sendKeys(Keys.TAB);

		//Enter Account balance
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimPayment_AddAccount_AccountBalance, "Enter account balance data in claim payment view section", "Able to enter account balance data in claim payment view section", "User not able to enter account balance data in claim payment view section", AccountBalance);
		MTALocators.PVS_ClaimPayment_AddAccount_AccountBalance.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000); 
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimPayment_AddAccountBalance_SaveBtn, "Click on save button in claims payment view Screen", "User able to click on save button", "User not able to click on save button claims payment view Screen");
		Thread.sleep(3000);

	}
	
	public void keyToCreateClaimRenewal() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimRenewal*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DeclarationDate = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DeclarationDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DeclarationDate");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Select Claim Renewal flag
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimRenewal_FlagOff, "Select select claim renewal flag in claim payment view section", "Able to select claim renewal flag in claim payment view section", "Unable to select claim renewal flag in claim payment view section");

		//Enter Balance Data
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimRenewal_DeclarationDate, "Select the declaration date in new claims page", "Able to select declaration date in claim payment view section", "User not able to select declaration date in claim payment view section", DeclarationDate);
		MTALocators.PVS_ClaimRenewal_DeclarationDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000); 
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimRenewal_SaveButton, "Click on save button in claims payment view Screen", "User able to click on save button", "User not able to click on save button claims payment view Screen");
		Thread.sleep(3000);

	}

	public void keyToCreateNewPayment() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateNewPayment*******************");

		//Click on claim payment tab
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimPayment, "Click on claim payment in claim view screen", "User able to Click on claim payment in claim view screen", "unable to Click on claim payment in claim view screen");

		//Click on payment 
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimPayment_Paymentbtn, "Click on payment", "user able to click on payment button", "unable to click on payment button");

		//Calculate button
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimPaymentscreen_CalculateBtn, "Click on calculate button in new claim payment movement screen", "User able to Click on calculate button in new claim payment movement screen", "Unable to Click on calculate button in new claim payment movement screen");

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");

		//Click on No button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}

	public void keyToCreate2ndClaimRenewal() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimRenewal*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DeclarationDate2 = "";

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DeclarationDate2 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DeclarationDate2");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Select Claim Renewal flag
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimRenewal_FlagOff, "Select select claim renewal flag in claim payment view section", "Able to select claim renewal flag in claim payment view section", "Unable to select claim renewal flag in claim payment view section");

		//Enter Balance Data
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimRenewal_DeclarationDate, "Select the declaration date in new claims page", "Able to select declaration date in claim payment view section", "User not able to select declaration date in claim payment view section", DeclarationDate2);
		MTALocators.PVS_ClaimRenewal_DeclarationDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000); 
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimRenewal_SaveButton, "Click on save button in claims payment view Screen", "User able to click on save button", "User not able to click on save button claims payment view Screen");
		Thread.sleep(3000);

	}


	public void keyToCreateClaimsDeclarationDateGreaterThanLOD() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsDeclarationDateGreaterThanLOD*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss29 = "";
		String ClaimsReason29 = ""; 
		String NotificationDate29 = ""; 
		String DeclarationDate29 = ""; 
		String ClaimsDetails29 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss29 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss29");
			ClaimsReason29 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason29");
			NotificationDate29 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate29");
			DeclarationDate29 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DeclarationDate29");
			ClaimsDetails29 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails29");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		//Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss29);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason29);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate29);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Select Declaration date
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_DeclarationDate, "Select the declaration date in new claims page", "Able to select loss of date in new claims page", "User not able to select declaration date in new claims page", DeclarationDate29);
		MTALocators.PVS_PolicyClaims_DeclarationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails29);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_OkButton, "Click on ok button in claims View Screen", "User able to click on no button", "User not able to click on ok button claims View Screen");
		Thread.sleep(5000);

	}



	public void keyToCreateClaimsDeclarationDateFutureDate() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsDeclarationDateFutureDate*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DeclarationDate29 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DeclarationDate29 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DeclarationDate291");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Select Declaration date
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_DeclarationDate, "Select the declaration date in new claims page", "Able to select loss of date in new claims page", "User not able to select declaration date in new claims page", DeclarationDate29);
		MTALocators.PVS_PolicyClaims_DeclarationDate.sendKeys(Keys.TAB);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_OkButton, "Click on ok button in claims View Screen", "User able to click on no button", "User not able to click on ok button claims View Screen");
		Thread.sleep(5000);

	}


	public void keyToCreateClaimsDeclarationDatenotDisplayed() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsDeclarationDatenotDisplayed*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String ClaimsReason29 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			ClaimsReason29 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason29");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Select Claims reason
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason29);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);
	}


	public void keyToCreateClaimsExcessPeriodValidation() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsExcessPeriodValidation*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss31 = "";
		String ClaimsReason31 = ""; 
		String NotificationDate31 = ""; 
		String ClaimsDetails31 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "DateofLoss31");
			ClaimsReason31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsReason31");
			NotificationDate31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "NotificationDate31");
			ClaimsDetails31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "SpotCheck_Error_Validation", "ClaimsDetails31");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss31);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason31);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate31);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails31);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);


	}

	public void keyToCreateClaimsFor3Mobile_functionality() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsFor3Mobile_functionality*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss31 = "";
		String ClaimsReason31 = ""; 
		String NotificationDate31 = ""; 
		String ClaimsDetails31 = ""; 
		String Skadessted = ""; 
		String Stjalet = ""; 
		String Indruddet = ""; 
		String Indrud = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "DateofLoss");
			ClaimsReason31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "ClaimsReason");
			NotificationDate31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "NotificationDate");
			ClaimsDetails31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "ClaimsDetails");
			Skadessted = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Skadessted");
			Stjalet = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Stjalet");
			Indruddet = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Indruddet");
			Indrud = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Indrud");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss31);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason31);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate31);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Select Aware date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_AwareDate, "Select the aware date in new claims page", "Able to select aware date in new claims page", "User not able to select aware date in new claims page", NotificationDate31);
		MTALocators.PVS_PolicyClaims_AwareDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails31);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on Submit button
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Sumbit, "Click on submit button in claims View Screen", "User able to click on submit button", "User not able to click on submit button claims View Screen");
		Thread.sleep(5000);

		//Click on OK button
		Implementation.ClickFeild(driver, MTALocators.MTA_Decline_Popup_Oklbtn, "Click on ok button in claims View Screen", "User able to click on ok button", "User not able to click on ok button claims View Screen");
		Thread.sleep(5000);

		//Click on Claim question tab
		//Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestionTab, "Click on claim question tab", "User able to click claim question tab", "Unable to click claim question tab");

		//Enter Skadessted 
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimQuestion_Skadessted, "Enter the value in text box", "User able to pass some value in text box", "Unable to pass some value in text box", Skadessted);

		//Click Har du anmeldt skaden indenfor 48 time
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Timer_Yes, "Select yes check box", "User able to Select yes check box", "unable to Select yes check box");

		//Click on Har du sp�rret dit SIM-kort?
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Kort_Yes, "Select yes check box", "User able to Select yes check box", "Unable to Select yes check box");

		//Select Hvordan blev den mobile enhed stj�let
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Stjalet, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Stjalet);

		//Click on Har du anmeldt indbruddet til politiet
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Polititet_Yes, "Select yes check box", "User able to Select yes check box", "Unable to Select yes check box");

		//Select Hvor skete indbruddet?
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Indruddet, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Indruddet);

		//Select Var der synlige tegn p� indbrud
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Indrud, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Indrud);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on Submit button
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Sumbit, "Click on submit button in claims View Screen", "User able to click on submit button", "User not able to click on submit button claims View Screen");
		Thread.sleep(5000);

	}

	public void keyToCreateClaimsFor3Mobile_functionality2() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsFor3Mobile_functionality2*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss31 = "";
		String ClaimsReason31 = ""; 
		String NotificationDate31 = ""; 
		String ClaimsDetails31 = ""; 
		String Skadessted = ""; 
		String Enhed = ""; 
		String Occured = ""; 
		String DamageType = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "DateofLoss");
			ClaimsReason31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "ClaimsReason2");
			NotificationDate31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "NotificationDate");
			ClaimsDetails31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "ClaimsDetails");
			Skadessted = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Skadessted");
			Enhed = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Enhed");
			Occured = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "Occured");
			DamageType = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "3MobileValidation", "DamageType");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		//Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss31);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason31);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate31);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails31);
    	MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on Claim question tab
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestionTab, "Click on claim question tab", "User able to click claim question tab", "Unable to click claim question tab");

		//Enter Skadessted 
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimQuestion_Skadessted, "Enter the value in text box", "User able to pass some value in text box", "Unable to pass some value in text box", Skadessted);

		//Click Har du anmeldt skaden indenfor 48 time
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_brugem_Yes, "Select yes check box", "User able to Select yes check box", "unable to Select yes check box");

		//Click on Har du sp�rret dit SIM-kort?
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Enhe_Yes, "Select yes check box", "User able to Select yes check box", "Unable to Select yes check box");

		//Click on Har du anmeldt indbruddet til politiet
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Dage_Yes, "Select yes check box", "User able to Select yes check box", "Unable to Select yes check box");

		//Select Hvor skete indbruddet?
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Enhed, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Enhed);

		//Select Var der synlige tegn p� indbrud
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Occured, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Occured);

		//Select Var der synlige tegn p� indbrud
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_DamageType, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", DamageType);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

	}

	public void keyToCreatePolicyForNewMNOSponsor() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreatePolicyForNewMNOSponsor*******************");

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";
		DataSheetRead DataWorkBook = null;
		String inceptionDate = "";
		String Purchage_Date = "";
		String DeviceMakebeinginsured = "";
		String DeviceModelbeinginsured = "";
		String DeviceSpecbeinginsured = "";
		String Product_ID = "";
		
		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			inceptionDate = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "inceptionDate");
			Purchage_Date = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "Purchage_Date");
			DeviceMakebeinginsured = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "DeviceMakebeinginsured");
			DeviceModelbeinginsured = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "DeviceModelbeinginsured");
			DeviceSpecbeinginsured = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "DeviceSpecbeinginsured");
			Product_ID = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "Product_ID");
			
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet)*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		//Click on Quote Tab
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Quote), "Verify Click on Quote Tab", "Clicked on Quote Tab", "Unable to Click on Quote Tab");

		//Enter Inception Date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.date_inception), "Enter Inception Date", "User able to enter inception Date", "User unable to enter the inception date", inceptionDate);
		driver.findElement(AllGeneralTabs.date_inception).sendKeys(Keys.ENTER);
		Thread.sleep(3000);

		//Select a Product, input is given by Excel 
		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(By.xpath("//*[@id='producttemplate']/div[1]/h3[./text()='MNO PRODUCT']")), "Verify Click on Product", "Clicked on Product", "Not able to click on Product");

		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 1000);");

		Thread.sleep(5000);
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.Tab_Next), "Verify Click on Next Button", "Clicked on Next Button", "Not able to click next button");

		//enter purchase date
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.pURCHASEDATE), "Enter Purchase date", "USer able to enter purchase date", "user unable to enter purchase date", Purchage_Date);

		//enter device modal , device name and spec 
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.dEVICEMAKE), "Enter device make", "User able to enter device make", "User unable to enter device make", DeviceMakebeinginsured);
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.dEVICEMODEL), "Enter device modal ", "User able to enter device modal", "User unable to enter device modal", DeviceModelbeinginsured);
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.dEVICESPECIFICATION), "Enter device specification", "User able to enter device specification", "User unable to enter device specification", DeviceSpecbeinginsured);

		//Select policy term
		Implementation.selectDropdown(driver, driver.findElement(AllGeneralTabs.policyTermid), "Select policy term from drop down", "User able to Select policy term from drop down", "Unable to Select policy term from drop down", "24"); 
		
		//Enter Product ID
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.pRODUCTid), "Enter product id", "Able to enter product id", "Unable to enter product id", Product_ID);

		//click next	
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnNext),"Click next" , "User able to click next", "User unable to click next");

		//click next again
		Implementation.ClickFeild(driver,driver.findElement(AllGeneralTabs.nextBt),"Click next" , "User able to click next", "User unable to click next");

		//enter cus id
		Implementation.EnterTextFeild(driver, driver.findElement(AllGeneralTabs.searchTxt), "Enter customer ID", "User able to enter customer ID", "User able to enter customer ID", "%");

		//click search
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnSearch), "Click search", "User able to click search", "User unable to click search");

		//click search result
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.searchResult),"Click search result" , "User able to click search result", "User unable to click search result");

		//click create policy
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnCreatePolicy), "Click create policy button", "User able to click create policy", "User unable to click create policy");

		//click create policy
		Implementation.ClickFeild(driver, driver.findElement(AllGeneralTabs.btnCreatePolicy), "Click create policy button", "User able to click create policy", "User unable to click create policy");

		//Fetch Policy/Plan number
		String planNumber=driver.findElement(MTALocators.txt_policynumber).getAttribute("value");
		System.out.println("Plan/Plocy number is created "+planNumber);

	}


	public void keyToCreateClaimsForNewMNO_functionality() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForNewMNO_functionality*******************");

		//****************Create MTA Referral Validation*********************************

		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss31 = "";
		String ClaimsReason31 = ""; 
		String NotificationDate31 = ""; 
		String ClaimsDetails31 = ""; 
		String Skadessted = ""; 
		String Stjalet = ""; 
		String Indruddet = ""; 
		String Indrud = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "DateofLoss");
			ClaimsReason31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "ClaimsReason");
			NotificationDate31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "NotificationDate");
			ClaimsDetails31 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "ClaimsDetails");
			Skadessted = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "Skadessted");
			Stjalet = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "Stjalet");
			Indruddet = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "Indruddet");
			Indrud = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "GenericMNOSponsor", "Indrud");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss31);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason31);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate31);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails31);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);
		
		//Click on Claim question tab
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestionTab, "Click on claim question tab", "User able to click claim question tab", "Unable to click claim question tab");

		//Enter Skadessted 
		Implementation.EnterTextFeild(driver, MTALocators.PVS_ClaimQuestion_Skadessted, "Enter the value in text box", "User able to pass some value in text box", "Unable to pass some value in text box", Skadessted);

		//Click Har du anmeldt skaden indenfor 48 time
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Timer_Yes, "Select yes check box", "User able to Select yes check box", "unable to Select yes check box");

		//Click on Har du sp�rret dit SIM-kort?
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Kort_Yes, "Select yes check box", "User able to Select yes check box", "Unable to Select yes check box");

		//Select Hvordan blev den mobile enhed stj�let
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Stjalet, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Stjalet);

		//Click on Har du anmeldt indbruddet til politiet
		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Polititet_Yes, "Select yes check box", "User able to Select yes check box", "Unable to Select yes check box");

		//Select Hvor skete indbruddet?
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Indruddet, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Indruddet);

		//Select Var der synlige tegn p� indbrud
		Implementation.selectDropdown(driver, MTALocators.PVS_ClaimQuestion_Indrud, "Select the value from drop down", "User able to Select the value from drop down", "Unable to Select the value from drop down", Indrud);

		//Click on save button
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

//		//Click on Submit button
//		Implementation.ClickFeild(driver, MTALocators.PVS_ClaimQuestion_Sumbit, "Click on submit button in claims View Screen", "User able to click on submit button", "User not able to click on submit button claims View Screen");
//		Thread.sleep(5000);

	}

	
	public void keyToCreateClaimsForRelapse_Warningmsg() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForRelapse_Warningmsg*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss4 = "";
		String ClaimsReason4 = ""; 
		String NotificationDate4 = ""; 
		String ClaimsDetails4 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "DateofLoss2");
			ClaimsReason4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "ClaimsReason2");
			NotificationDate4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "NotificationDate2");
			ClaimsDetails4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "ClaimsDetails2");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		Thread.sleep(5000); 
		Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss4);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(2000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason4);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(2000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate4);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails4);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}


	public void keyToCreateClaimsForElapsedWarningmsg() throws InterruptedException, IOException{

		System.out.println("*********************Started Keyword - keyToCreateClaimsForElapsedWarningmsg*******************");


		Properties name = loadPropertyFile("PC_Path");
		String pc_sheet_path =  name.getProperty("pc_sheet_path");
		String pc_sheet_name_MTA_Client =  "BP_Claims";		

		DataSheetRead DataWorkBook = null;
		String DateofLoss4 = "";
		String ClaimsReason4 = ""; 
		String NotificationDate4 = ""; 
		String ClaimsDetails4 = ""; 

		try{
			DataWorkBook = new DataSheetRead(pc_sheet_path);
			DateofLoss4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "DateofLoss3");
			ClaimsReason4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "ClaimsReason3");
			NotificationDate4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "NotificationDate3");
			ClaimsDetails4 = DataWorkBook.readCellString(pc_sheet_name_MTA_Client, "PermittedRelapsePeriod", "ClaimsDetails3");

		}catch(Exception e){
			e.printStackTrace();
			System.out.println("***********Exception while reading Data sheet*********");
		}finally{
			DataWorkBook.close();
		}

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		//Click on policy number in breadcrumb
		Thread.sleep(5000); 
		Implementation.ClickFeild(driver, MTALocators.PVS_Investigation_PolicyNo, "Click on policy no in investigation screen", "User able to click on policy no in investigation screen", "Unable to click on policy no in investigation screen");

		//Click on policy claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims, "Click on policy claims button in policy view section", "Able to click on policy claims button in policy view section", "Unable to click on policy claims button in policy view section");

		//Click on new claims tab
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_NewClaimsTab, "Click on new claims button in policy view section", "Able to click on new claims button in policy view section", "Unable to click on new claims button in policy view section");

		//Enter Date of loss
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_LossDate, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", DateofLoss4);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Select Claims reason
		Thread.sleep(3000);
		Implementation.selectDropdown(driver, MTALocators.PVS_PolicyClaims_ClaimsReason, "Select claims reason from drop down", "Able to select claims reason from drop down", "User not able to select the claims reason from drop down", ClaimsReason4);
		MTALocators.PVS_PolicyClaims_ClaimsReason.sendKeys(Keys.TAB);

		//Select Notification date
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_NotificationDate, "Select the notification date in new claims page", "Able to select notification date in new claims page", "User not able to select notification date in new claims page", NotificationDate4);
		MTALocators.PVS_PolicyClaims_NotificationDate.sendKeys(Keys.TAB);

		//Enter claims details
		Thread.sleep(3000);
		Implementation.EnterTextFeild(driver, MTALocators.PVS_PolicyClaims_ClaimsDeatils, "Select the loss of date in new claims page", "Able to select loss of date in new claims page", "User not able to select loss of date in new claims page", ClaimsDetails4);
		MTALocators.PVS_PolicyClaims_LossDate.sendKeys(Keys.TAB);

		//Click on save button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton, "Click on save button in claims View Screen", "User able to click on save button", "User not able to click on save button claims View Screen");
		Thread.sleep(3000);

		//Click on No button
		Thread.sleep(3000);
		Implementation.ClickFeild(driver, MTALocators.PVS_PolicyClaims_SaveButton_NoButton, "Click on no button in claims View Screen", "User able to click on no button", "User not able to click on no button claims View Screen");
		Thread.sleep(5000);

	}





















}
